
import { Invoice, Client, WoodProduct, User, Expense, Post, MediaItem, Comment, Estimate, Payment, Credit } from '../types';

export const mockClients: Client[] = [
  { id: 'c1', name: 'John Doe', company: 'Build-It Ltd', email: 'john@buildit.com', vatNumber: 'NL123456789B01', address: 'Main St 1, Amsterdam', totalSpent: 15400, status: 'Active', phone: '+31 20 123 4567' },
  { id: 'c2', name: 'Sarah Miller', company: 'Miller Furniture', email: 'sarah@miller.com', vatNumber: 'NL987654321B01', address: 'Woodway 42, Rotterdam', totalSpent: 8200, status: 'Active', phone: '+31 10 987 6543' },
];

export const mockWoodProducts: WoodProduct[] = [
  { id: 'p1', name: 'Premium Teak Planks', woodType: 'Teak', thickness: 25, width: 150, length: 2400, unit: 'm³', pricePerUnit: 4500, stock: 12.5 },
  { id: 'p2', name: 'Oak Flooring Grade A', woodType: 'Oak', thickness: 20, width: 180, length: 2000, unit: 'm²', pricePerUnit: 85, stock: 450 },
  { id: 'p3', name: 'Mahogany Beams', woodType: 'Mahogany', thickness: 100, width: 100, length: 3000, unit: 'pcs', pricePerUnit: 120, stock: 45 },
];

export const mockInvoices: Invoice[] = [
  { 
    id: 'inv1', 
    invoiceNumber: 'INV-2024-001', 
    clientId: 'c1', 
    clientName: 'Build-It Ltd', 
    date: '2024-03-01', 
    dueDate: '2024-03-15', 
    subtotal: 1200, 
    taxRate: 21, 
    taxAmount: 252, 
    totalAmount: 1452, 
    status: 'Paid',
    items: []
  },
  { 
    id: 'inv2', 
    invoiceNumber: 'INV-2024-002', 
    clientId: 'c2', 
    clientName: 'Miller Furniture', 
    date: '2024-03-10', 
    dueDate: '2024-03-24', 
    subtotal: 3500, 
    taxRate: 21, 
    taxAmount: 735, 
    totalAmount: 4235, 
    status: 'Pending',
    items: []
  },
];

export const mockEstimates: Estimate[] = [
  { 
    id: 'e1', 
    estimateNumber: 'EST-8821', 
    clientId: 'c1', 
    clientName: 'Build-It Ltd', 
    date: '2024-03-12', 
    subtotal: 4000,
    taxRate: 21,
    taxAmount: 840,
    total: 4840, 
    status: 'Sent',
    items: [
      { id: 'i1', productId: 'p1', description: 'Teak Bulk Order', quantity: 1, unitPrice: 4000, total: 4000 }
    ]
  },
  { 
    id: 'e2', 
    estimateNumber: 'EST-8822', 
    clientId: 'c2', 
    clientName: 'Sarah Miller', 
    date: '2024-03-14', 
    subtotal: 1033.06,
    taxRate: 21,
    taxAmount: 216.94,
    total: 1250, 
    status: 'Accepted',
    items: [
      { id: 'i2', productId: 'p2', description: 'Oak Flooring', quantity: 12.15, unitPrice: 85, total: 1033.06 }
    ]
  },
];

export const mockPayments: Payment[] = [
  { id: 'pay1', clientId: 'c1', amount: 1452, date: '2024-03-05', method: 'Bank Transfer', reference: 'INV-2024-001 Settlement', status: 'Completed' },
];

export const mockCredits: Credit[] = [
  { id: 'cr1', clientId: 'c1', amount: 250, date: '2024-03-15', reason: 'Damaged planks refund', status: 'Available' },
];

export const mockUsers: User[] = [
  { id: '1', name: 'Alex Ramzon', email: 'alex@ramzon.nv', role: 'Admin', status: 'Active', avatar: 'https://picsum.photos/seed/alex/100/100', joinedDate: '2023-01-12' },
  { id: '2', name: 'Sesar Varma', email: 'sesar@ramzon.nv', role: 'Sales', status: 'Active', avatar: 'https://picsum.photos/seed/sesar/100/100', joinedDate: '2023-05-20' },
  { id: '3', name: 'Jenny Wilson', email: 'jenny@ramzon.nv', role: 'Accountant', status: 'Active', avatar: 'https://picsum.photos/seed/jenny/100/100', joinedDate: '2024-02-05' },
];

export const mockExpenses: Expense[] = [
  { id: 'e1', category: 'Logistics', amount: 450, date: '2024-03-12', description: 'Diesel for transport trucks', status: 'Paid' },
  { id: 'e2', category: 'Inventory', amount: 12000, date: '2024-03-15', description: 'Teak shipment from Brazil', status: 'Unpaid' },
];

export const mockPosts: Post[] = [
  { id: '1', title: 'Simplifying Payments for Growth', type: 'Article', category: 'Fintech', tags: ['payments', 'growth'], seoScore: 92, status: 'Published', author: 'Alex Ramzon', date: '2024-03-01', content: 'Content goes here...' },
  { id: '2', title: 'Home', type: 'Page', category: 'General', tags: [], seoScore: 85, status: 'Published', author: 'Alex Ramzon', date: '2024-01-10' },
  { id: '3', title: 'About Us', type: 'Page', category: 'General', tags: [], seoScore: 78, status: 'Published', author: 'Alex Ramzon', date: '2024-01-12' },
  { id: '4', title: 'New Metafi Dashboard Launch', type: 'Article', category: 'News', tags: ['dashboard', 'launch'], seoScore: 95, status: 'Published', author: 'Alex Ramzon', date: '2024-02-15' },
];

export const mockMedia: MediaItem[] = [
  { id: 'm1', name: 'warehouse-stock.jpg', url: 'https://picsum.photos/seed/wood1/800/600', size: '1.2 MB', type: 'image/jpeg', date: '2024-03-05' },
  { id: 'm2', name: 'delivery-truck.png', url: 'https://picsum.photos/seed/truck/800/600', size: '850 KB', type: 'image/png', date: '2024-03-08' },
  { id: 'm3', name: 'team-photo.jpg', url: 'https://picsum.photos/seed/team/800/600', size: '2.4 MB', type: 'image/jpeg', date: '2024-01-20' },
];

export const mockComments: Comment[] = [
  { id: 'c1', author: 'John Smith', avatar: 'https://picsum.photos/seed/john/100/100', content: 'Great insights on the wood market!', status: 'Approved', postTitle: 'Simplifying Payments for Growth', date: '2024-03-02' },
  { id: 'c2', author: 'Emily Davis', avatar: 'https://picsum.photos/seed/emily/100/100', content: 'Is there a discount for bulk orders?', status: 'Pending', postTitle: 'Simplifying Payments for Growth', date: '2024-03-05' },
  { id: 'c3', author: 'Michael Brown', avatar: 'https://picsum.photos/seed/michael/100/100', content: 'Love the new dashboard UI.', status: 'Approved', postTitle: 'New Metafi Dashboard Launch', date: '2024-02-16' },
];
