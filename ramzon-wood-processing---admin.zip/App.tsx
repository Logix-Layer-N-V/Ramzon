
import React, { useState, useEffect, createContext, useContext } from 'react';
import { HashRouter as Router, Routes, Route, Navigate, useLocation, useNavigate } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import UsersPage from './pages/UsersPage';
import SettingsPage from './pages/SettingsPage';
import InvoicesPage from './pages/InvoicesPage';
import CreateInvoicePage from './pages/CreateInvoicePage';
import QuotesPage from './pages/QuotesPage';
import CreateQuotePage from './pages/CreateQuotePage';
import ExpensesPage from './pages/ExpensesPage';
import CreateExpensePage from './pages/CreateExpensePage';
import ProductsPage from './pages/ProductsPage';
import CreateProductPage from './pages/CreateProductPage';
import ClientsPage from './pages/ClientsPage';
import CreateClientPage from './pages/CreateClientPage';
import ClientDetailPage from './pages/ClientDetailPage';
import EditClientPage from './pages/EditClientPage';
import PaymentsPage from './pages/PaymentsPage';
import CreditsPage from './pages/CreditsPage';
import RecurringBillingPage from './pages/RecurringBillingPage';
import ReportsPage from './pages/ReportsPage';
import FinanceReportsPage from './pages/FinanceReportsPage';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import ServicesPage from './pages/ServicesPage';
import AppearancePage from './pages/AppearancePage';
import MediaPage from './pages/MediaPage';
import MediaDetailPage from './pages/MediaDetailPage';
import GeminiAssistant from './components/GeminiAssistant';
import TrafficInsightsPage from './pages/TrafficInsightsPage';
import CurrencyManagementPage from './pages/CurrencyManagementPage';
import DocumentDetailPage from './pages/DocumentDetailPage';
import { Language, translations } from './lib/translations';

export interface Currency {
  id: string;
  code: string;
  name: string;
  symbol: string;
  status: string;
}

export interface TaxRate {
  id: string;
  name: string;
  percentage: number;
  isDefault: boolean;
}

export const LanguageContext = createContext<{
  lang: Language;
  setLang: (l: Language) => void;
  t: (key: keyof typeof translations.en) => string;
  theme: string;
  setTheme: (t: string) => void;
  multiCurrency: boolean;
  setMultiCurrency: (v: boolean) => void;
  availableCurrencies: Currency[];
  setAvailableCurrencies: (currencies: Currency[]) => void;
  companyName: string;
  setCompanyName: (name: string) => void;
  companyLogo: string | null;
  setCompanyLogo: (logo: string | null) => void;
  companyAddress: string;
  setCompanyAddress: (v: string) => void;
  companyPhone: string;
  setCompanyPhone: (v: string) => void;
  companyEmail: string;
  setCompanyEmail: (v: string) => void;
  companyWebsite: string;
  setCompanyWebsite: (v: string) => void;
  companyKKF: string;
  setCompanyKKF: (v: string) => void;
  companyBTW: string;
  setCompanyBTW: (v: string) => void;
  taxRates: TaxRate[];
  setTaxRates: (v: TaxRate[]) => void;
}>({
  lang: 'en',
  setLang: () => {},
  t: (key) => translations.en[key],
  theme: 'default',
  setTheme: () => {},
  multiCurrency: false,
  setMultiCurrency: () => {},
  availableCurrencies: [],
  setAvailableCurrencies: () => {},
  companyName: 'Ramzon Admin',
  setCompanyName: () => {},
  companyLogo: null,
  setCompanyLogo: () => {},
  companyAddress: '',
  setCompanyAddress: () => {},
  companyPhone: '',
  setCompanyPhone: () => {},
  companyEmail: '',
  setCompanyEmail: () => {},
  companyWebsite: '',
  setCompanyWebsite: () => {},
  companyKKF: '',
  setCompanyKKF: () => {},
  companyBTW: '',
  setCompanyBTW: () => {},
  taxRates: [],
  setTaxRates: () => {}
});

const Layout: React.FC<{ 
  children: React.ReactNode; 
  onLogout: () => void;
  isSidebarCollapsed: boolean;
  setIsSidebarCollapsed: (v: boolean) => void;
}> = ({ children, onLogout, isSidebarCollapsed, setIsSidebarCollapsed }) => {
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    if (window.innerWidth < 768) {
      setIsSidebarCollapsed(true);
    }
  }, [location.pathname, setIsSidebarCollapsed]);

  return (
    <div className="flex min-h-screen bg-slate-100 overflow-hidden text-slate-900 selection:bg-brand-accent/20">
      <Sidebar 
        currentPath={location.pathname} 
        onNavigate={(path) => navigate(path)} 
        isCollapsed={isSidebarCollapsed}
        onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
      />
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden relative">
        <Header 
          onLogout={onLogout} 
          onToggleSidebar={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
        />
        
        <main className="flex-1 overflow-y-auto w-full no-scrollbar relative z-0 pb-12">
          <div className="max-w-[1400px] mx-auto w-full p-4 md:p-10">
            <div className="bg-white rounded-[32px] shadow-[0_40px_150px_-20px_rgba(0,0,0,0.1)] border border-slate-200 min-h-[calc(100vh-180px)] p-6 md:p-12 animate-in fade-in zoom-in-[0.98] duration-700 overflow-visible">
              {children}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(() => localStorage.getItem('isLoggedIn') === 'true');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(window.innerWidth < 768);
  const [lang, setLang] = useState<Language>((localStorage.getItem('appLang') as Language) || 'en');
  const [theme, setTheme] = useState(() => localStorage.getItem('appTheme') || 'default');
  const [multiCurrency, setMultiCurrency] = useState(() => localStorage.getItem('multiCurrency') === 'true');
  
  const [availableCurrencies, setAvailableCurrencies] = useState<Currency[]>(() => {
    const saved = localStorage.getItem('availableCurrencies');
    return saved ? JSON.parse(saved) : [
      { id: '1', code: 'USD', name: 'US Dollar', symbol: '$', status: 'Active' },
      { id: '2', code: 'SRD', name: 'Surinamese Dollar', symbol: 'SRD', status: 'Active' },
      { id: '3', code: 'EUR', name: 'Euro', symbol: '€', status: 'Active' },
      { id: '4', code: 'USDT', name: 'Tether', symbol: '₮', status: 'Active' },
    ];
  });

  const [companyName, setCompanyName] = useState(() => localStorage.getItem('companyName') || 'Ramzon Wood Processing Company N.V.');
  const [companyLogo, setCompanyLogo] = useState<string | null>(() => localStorage.getItem('companyLogo'));
  
  const [companyAddress, setCompanyAddress] = useState(() => localStorage.getItem('companyAddress') || 'Industrieweg Zuid 12, Paramaribo, Suriname');
  const [companyPhone, setCompanyPhone] = useState(() => localStorage.getItem('companyPhone') || '+597 123-4567');
  const [companyEmail, setCompanyEmail] = useState(() => localStorage.getItem('companyEmail') || 'info@ramzon.sr');
  const [companyWebsite, setCompanyWebsite] = useState(() => localStorage.getItem('companyWebsite') || 'www.ramzon.sr');
  const [companyKKF, setCompanyKKF] = useState(() => localStorage.getItem('companyKKF') || '12345');
  const [companyBTW, setCompanyBTW] = useState(() => localStorage.getItem('companyBTW') || '101.202.303');
  
  const [taxRates, setTaxRates] = useState<TaxRate[]>(() => {
    const saved = localStorage.getItem('taxRates');
    return saved ? JSON.parse(saved) : [
      { id: 't1', name: 'BTW standard', percentage: 21, isDefault: true },
      { id: 't2', name: 'BTW export', percentage: 0, isDefault: false },
    ];
  });

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('appTheme', theme);
  }, [theme]);

  useEffect(() => {
    localStorage.setItem('multiCurrency', multiCurrency.toString());
  }, [multiCurrency]);

  useEffect(() => {
    localStorage.setItem('availableCurrencies', JSON.stringify(availableCurrencies));
  }, [availableCurrencies]);

  useEffect(() => {
    localStorage.setItem('companyName', companyName);
    localStorage.setItem('companyAddress', companyAddress);
    localStorage.setItem('companyPhone', companyPhone);
    localStorage.setItem('companyEmail', companyEmail);
    localStorage.setItem('companyWebsite', companyWebsite);
    localStorage.setItem('companyKKF', companyKKF);
    localStorage.setItem('companyBTW', companyBTW);
    localStorage.setItem('taxRates', JSON.stringify(taxRates));
  }, [companyName, companyAddress, companyPhone, companyEmail, companyWebsite, companyKKF, companyBTW, taxRates]);

  useEffect(() => {
    if (companyLogo) localStorage.setItem('companyLogo', companyLogo);
    else localStorage.removeItem('companyLogo');
  }, [companyLogo]);

  const t = (key: keyof typeof translations.en) => {
    return translations[lang][key] || translations.en[key];
  };

  const handleSetLang = (newLang: Language) => {
    setLang(newLang);
    localStorage.setItem('appLang', newLang);
  };

  const handleLogin = () => {
    setIsAuthenticated(true);
    localStorage.setItem('isLoggedIn', 'true');
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('isLoggedIn');
  };

  return (
    <LanguageContext.Provider value={{ 
      lang, setLang: handleSetLang, t, theme, setTheme, 
      multiCurrency, setMultiCurrency, availableCurrencies, setAvailableCurrencies,
      companyName, setCompanyName, companyLogo, setCompanyLogo,
      companyAddress, setCompanyAddress,
      companyPhone, setCompanyPhone,
      companyEmail, setCompanyEmail,
      companyWebsite, setCompanyWebsite,
      companyKKF, setCompanyKKF,
      companyBTW, setCompanyBTW,
      taxRates, setTaxRates
    }}>
      <Router>
        <Routes>
          <Route path="/login" element={isAuthenticated ? <Navigate to="/dashboard" replace /> : <LoginPage onLogin={handleLogin} />} />
          
          <Route path="/*" element={
            isAuthenticated ? (
              <Layout onLogout={handleLogout} isSidebarCollapsed={isSidebarCollapsed} setIsSidebarCollapsed={setIsSidebarCollapsed}>
                <Routes>
                  <Route path="/dashboard" element={<DashboardPage />} />
                  <Route path="/invoices" element={<InvoicesPage />} />
                  <Route path="/invoices/new" element={<CreateInvoicePage />} />
                  <Route path="/invoices/:id" element={<DocumentDetailPage type="invoices" />} />
                  <Route path="/estimates" element={<QuotesPage />} />
                  <Route path="/estimates/new" element={<CreateQuotePage />} />
                  <Route path="/estimates/:id" element={<DocumentDetailPage type="estimates" />} />
                  <Route path="/estimates/edit/:id" element={<CreateQuotePage />} /> {/* Hergebruik CreateQuotePage als placeholder voor Edit */}
                  <Route path="/payments" element={<PaymentsPage />} />
                  <Route path="/payments/:id" element={<DocumentDetailPage type="payments" />} />
                  <Route path="/credits" element={<CreditsPage />} />
                  <Route path="/credits/:id" element={<DocumentDetailPage type="credits" />} />
                   <Route path="/recurring" element={<RecurringBillingPage />} />
                  <Route path="/recurring/:id" element={<DocumentDetailPage type="recurring" />} />
                  <Route path="/currencies" element={<CurrencyManagementPage />} />
                  <Route path="/expenses" element={<ExpensesPage />} />
                  <Route path="/expenses/new" element={<CreateExpensePage />} />
                  <Route path="/expenses/:id" element={<DocumentDetailPage type="expenses" />} />
                  <Route path="/products" element={<ProductsPage />} />
                  <Route path="/products/new" element={<CreateProductPage />} />
                  <Route path="/services" element={<ServicesPage />} />
                  <Route path="/media" element={<MediaPage />} />
                  <Route path="/media/:id" element={<MediaDetailPage />} />
                  <Route path="/appearance" element={<AppearancePage />} />
                  <Route path="/reports/finance" element={<FinanceReportsPage />} />
                  <Route path="/reports/finance/print" element={<DocumentDetailPage type="reports" />} />
                  <Route path="/reports/health" element={<ReportsPage />} />
                  <Route path="/insights" element={<TrafficInsightsPage />} />
                  <Route path="/assistant" element={<GeminiAssistant />} />
                  <Route path="/users" element={<UsersPage />} />
                  <Route path="/clients" element={<ClientsPage />} />
                  <Route path="/clients/new" element={<CreateClientPage />} />
                  <Route path="/clients/:id" element={<ClientDetailPage />} />
                  <Route path="/clients/edit/:id" element={<EditClientPage />} />
                  <Route path="/settings" element={<SettingsPage viewMode="page" setViewMode={()=>{}} />} />
                  <Route path="*" element={<Navigate to="/dashboard" replace />} />
                </Routes>
              </Layout>
            ) : <Navigate to="/login" replace />
          } />
        </Routes>
      </Router>
    </LanguageContext.Provider>
  );
};

export default App;
