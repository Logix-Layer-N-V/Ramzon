
import React, { useState, useContext } from 'react';
import { 
  LayoutDashboard, 
  FileText, 
  Users, 
  Settings,
  ChevronDown,
  ChevronsLeft,
  ChevronsRight,
  Receipt,
  ClipboardList,
  CreditCard,
  PieChart,
  Wallet,
  Layers,
  Settings2,
  RefreshCw,
  Banknote,
  Coins,
  Globe2,
  LayoutTemplate,
  BarChart3,
  Activity,
  ShieldAlert
} from 'lucide-react';
import { LanguageContext } from '../App';

interface SidebarProps {
  currentPath: string;
  onNavigate: (path: string) => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentPath, onNavigate, isCollapsed, onToggleCollapse }) => {
  const { t, multiCurrency, companyName, companyLogo } = useContext(LanguageContext);
  const [openMenus, setOpenMenus] = useState<{ [key: string]: boolean }>({
    dashboard: true,
    billing: true,
    reports: true,
  });

  const NavItem = ({ label, icon: Icon, path, active, hasDropdown, menuKey }: { 
    label: string, 
    icon: any, 
    path?: string, 
    active: boolean, 
    hasDropdown?: boolean,
    menuKey?: string
  }) => {
    return (
      <div className="flex flex-col w-full px-3">
        <button
          onClick={() => {
            if (path) onNavigate(path);
            if (hasDropdown && menuKey && !isCollapsed) setOpenMenus(prev => ({ ...prev, [menuKey]: !prev[menuKey] }));
            if (isCollapsed && onToggleCollapse) onToggleCollapse();
          }}
          className={`group w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition-all duration-300 ${
            active && !hasDropdown
              ? 'bg-brand-primary text-white shadow-lg' 
              : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50'
          } ${isCollapsed ? 'md:justify-center md:px-0' : ''}`}
        >
          <Icon size={18} className={`shrink-0 ${active ? 'scale-110' : ''}`} />
          {(!isCollapsed || window.innerWidth < 768) && <span className="flex-1 text-left whitespace-nowrap overflow-hidden">{label}</span>}
          {hasDropdown && (!isCollapsed || window.innerWidth < 768) && (
            <ChevronDown size={14} className={`transition-transform ${openMenus[menuKey!] ? 'rotate-180' : ''}`} />
          )}
        </button>
      </div>
    );
  };

  const SubMenuItem = ({ label, icon: Icon, path, active }: { 
    label: string, 
    icon: any, 
    path: string, 
    active: boolean
  }) => {
    if (isCollapsed && window.innerWidth >= 768) return null;
    return (
      <button
        onClick={() => onNavigate(path)}
        className={`w-full flex items-center gap-3 pl-11 pr-3 py-2 rounded-lg text-xs font-bold transition-all ${
          active ? 'text-brand-accent bg-brand-accent-light/50' : 'text-slate-400 hover:text-slate-900 hover:bg-slate-50'
        }`}
      >
        <Icon size={14} />
        <span className="flex-1 text-left">{label}</span>
      </button>
    );
  };

  return (
    <>
      {!isCollapsed && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-[35] md:hidden" onClick={onToggleCollapse} />
      )}

      <div className={`
        ${isCollapsed ? 'md:w-20 -translate-x-full md:translate-x-0' : 'w-72 translate-x-0'} 
        fixed md:sticky top-0 left-0 border-r border-slate-200 h-screen flex flex-col bg-white transition-all duration-300 z-[40]
      `}>
        <div className={`p-6 flex items-center gap-3 ${isCollapsed ? 'md:justify-center md:px-0' : ''}`}>
          {/* Clean logo container - Geen fill, geen borderline, geen shadow */}
          <div className="w-10 h-10 flex items-center justify-center shrink-0 transition-transform active:scale-95 overflow-hidden">
            {companyLogo ? (
              <img src={companyLogo} alt="Logo" className="w-full h-full object-contain" />
            ) : (
              <span className="font-black text-xl italic tracking-tighter uppercase text-brand-primary">
                {companyName.substring(0, 2)}
              </span>
            )}
          </div>
          {(!isCollapsed || window.innerWidth < 768) && (
            <div className="flex-1 min-w-0">
              <span className="font-extrabold text-lg tracking-tight text-slate-900 block truncate">{companyName}</span>
              <span className="block text-[10px] font-bold text-brand-accent uppercase tracking-widest leading-none mt-1">Invoice Center</span>
            </div>
          )}
        </div>

        <div className="flex-1 space-y-1 mt-4 overflow-y-auto no-scrollbar pb-8">
          <NavItem label={t('overview')} icon={LayoutDashboard} path="/dashboard" active={currentPath === '/dashboard'} />
          <NavItem label={t('crm')} icon={Users} path="/clients" active={currentPath.startsWith('/clients')} />
          
          <div className="space-y-1">
            <NavItem label={t('billing')} icon={CreditCard} hasDropdown menuKey="billing" active={currentPath.startsWith('/invoices') || currentPath.startsWith('/estimates') || currentPath.startsWith('/payments') || currentPath.startsWith('/credits') || currentPath.startsWith('/recurring') || currentPath.startsWith('/currencies')} />
            {openMenus.billing && (
              <div className="overflow-hidden">
                <SubMenuItem label={t('estimates')} icon={ClipboardList} path="/estimates" active={currentPath === '/estimates'} />
                <SubMenuItem label={t('invoices')} icon={Receipt} path="/invoices" active={currentPath === '/invoices'} />
                <SubMenuItem label={t('payments')} icon={Banknote} path="/payments" active={currentPath === '/payments'} />
                <SubMenuItem label={t('credits')} icon={Coins} path="/credits" active={currentPath === '/credits'} />
                {multiCurrency && <SubMenuItem label="Multi-Currency" icon={Globe2} path="/currencies" active={currentPath === '/currencies'} />}
                <SubMenuItem label={t('recurring')} icon={RefreshCw} path="/recurring" active={currentPath === '/recurring'} />
                <SubMenuItem label={t('expenses')} icon={Wallet} path="/expenses" active={currentPath === '/expenses'} />
              </div>
            )}
          </div>

          <NavItem label={t('products')} icon={Layers} path="/products" active={currentPath === '/products'} />
          <NavItem label={t('services')} icon={Settings2} path="/services" active={currentPath === '/services'} />
          <NavItem label="Doc Styles" icon={LayoutTemplate} path="/appearance" active={currentPath === '/appearance'} />
          
          <div className="space-y-1">
            <NavItem label={t('reports')} icon={FileText} hasDropdown menuKey="reports" active={currentPath.startsWith('/reports')} />
            {openMenus.reports && (
              <div className="overflow-hidden">
                <SubMenuItem label="Finance Reports" icon={BarChart3} path="/reports/finance" active={currentPath === '/reports/finance'} />
                <SubMenuItem label="System Health" icon={Activity} path="/reports/health" active={currentPath === '/reports/health'} />
              </div>
            )}
          </div>
          
          <NavItem label={t('users')} icon={Users} path="/users" active={currentPath === '/users'} />
        </div>

        <div className={`px-3 py-4 border-t border-slate-100 bg-slate-50/50 flex items-center gap-2 ${isCollapsed ? 'justify-center' : ''}`}>
          {(!isCollapsed || window.innerWidth < 768) && (
            <button 
              onClick={() => onNavigate('/settings')} 
              className={`flex-1 flex items-center gap-3 px-3 py-2 rounded-xl text-sm font-bold transition-all ${
                currentPath === '/settings' 
                  ? 'bg-brand-primary text-white shadow-md' 
                  : 'text-slate-500 hover:text-slate-900 hover:bg-white'
              }`}
            >
              <Settings size={18} className="shrink-0" />
              <span className="flex-1 text-left truncate">{t('settings')}</span>
            </button>
          )}
          
          <button onClick={onToggleCollapse} className="hidden md:flex items-center justify-center p-2 rounded-xl text-slate-400 hover:text-slate-900 hover:bg-white transition-all">
            {isCollapsed ? <ChevronsRight size={18} /> : <ChevronsLeft size={18} />}
          </button>
        </div>
      </div>
    </>
  );
};

export default Sidebar;
