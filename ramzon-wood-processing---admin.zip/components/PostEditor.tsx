
import React, { useState, useRef } from 'react';
import { Save, Eye, Type, Globe, Sparkles, Hash, Calendar, User, Layout, ArrowLeft, Check, Plus, X, Tag, Columns, ChevronDown, Layers, FileText, Bold, Italic, List, Link, Image as ImageIcon, Code, Wand2 } from 'lucide-react';
import { Post } from '../types';

interface PostEditorProps {
  post: Post;
  onClose?: () => void;
  fullPage?: boolean;
}

const PostEditor: React.FC<PostEditorProps> = ({ post, onClose, fullPage }) => {
  const [title, setTitle] = useState(post.title);
  const [content, setContent] = useState(post.content || '');
  const [status, setStatus] = useState(post.status);
  const [category, setCategory] = useState(post.category);
  const [template, setTemplate] = useState(post.title === 'Home' ? 'Hero Layout' : 'Default Sidebar');
  const [tags, setTags] = useState<string[]>(post.tags);
  const [newTag, setNewTag] = useState('');
  const [isAddingCategory, setIsAddingCategory] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [saved, setSaved] = useState(false);
  const [seoDescription, setSeoDescription] = useState('');
  const [editMode, setEditMode] = useState<'text' | 'visual'>('text');
  
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const addTag = () => {
    if (newTag.trim() && !tags.includes(newTag.trim())) {
      setTags([...tags, newTag.trim()]);
      setNewTag('');
    }
  };

  const removeTag = (tagToRemove: string) => {
    setTags(tags.filter(t => t !== tagToRemove));
  };

  const handleAddCategory = () => {
    if (newCategoryName.trim()) {
      setCategory(newCategoryName.trim());
      setNewCategoryName('');
      setIsAddingCategory(false);
    }
  };

  const insertFormatting = (before: string, after: string = '') => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = content.substring(start, end);
    const newText = content.substring(0, start) + before + selectedText + after + content.substring(end);

    setContent(newText);

    // Reset cursor position after state update
    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(start + before.length, end + before.length);
    }, 0);
  };

  return (
    <div className={`space-y-6 ${fullPage ? 'animate-in fade-in slide-in-from-bottom-2 duration-500' : ''}`}>
      {fullPage && (
        <div className="flex items-center justify-between mb-8">
          <button 
            onClick={() => window.history.back()}
            className="flex items-center gap-2 text-slate-500 hover:text-slate-900 transition-colors font-bold text-sm"
          >
            <ArrowLeft size={16} />
            Back to List
          </button>
          <div className="flex gap-2">
            <button className="bg-white border border-slate-200 text-slate-600 px-4 py-2 rounded-lg text-sm font-bold hover:bg-slate-50 transition-all shadow-sm">
              Discard
            </button>
            <button 
              onClick={handleSave}
              className="bg-slate-900 text-white px-5 py-2.5 rounded-lg text-sm font-bold hover:bg-slate-800 transition-all flex items-center gap-2 shadow-sm active:scale-95"
            >
              {saved ? <Check size={16} /> : <Save size={16} />}
              {saved ? 'Published' : 'Save Changes'}
            </button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pb-12">
        {/* Main Editor Body */}
        <div className="lg:col-span-8 space-y-6">
          <div className="bg-white p-8 rounded-xl border border-slate-200 shadow-sm space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                <Type size={12} /> {post.type} Title
              </label>
              <input 
                type="text" 
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full text-2xl font-bold text-slate-900 border border-slate-200 rounded-lg px-4 py-3 bg-white focus:ring-4 focus:ring-blue-50 focus:border-blue-500 outline-none transition-all"
                placeholder="Enter title here..."
              />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center mb-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                  <Layout size={12} /> Content Area
                </label>
                <div className="flex bg-slate-100 p-1 rounded-lg">
                  <button 
                    onClick={() => setEditMode('text')}
                    className={`px-3 py-1 rounded-md text-[10px] font-black uppercase tracking-widest transition-all ${editMode === 'text' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                  >
                    Editor
                  </button>
                  <button 
                    onClick={() => setEditMode('visual')}
                    className={`px-3 py-1 rounded-md text-[10px] font-black uppercase tracking-widest transition-all ${editMode === 'visual' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                  >
                    Visual Help
                  </button>
                </div>
              </div>

              {editMode === 'text' ? (
                <div className="flex flex-col border border-slate-200 rounded-xl overflow-hidden focus-within:border-blue-500 focus-within:ring-4 focus-within:ring-blue-50 transition-all">
                  {/* Editor Toolbar */}
                  <div className="flex items-center gap-1 p-2 bg-slate-50 border-b border-slate-200 overflow-x-auto no-scrollbar">
                    <button 
                      type="button"
                      onClick={() => insertFormatting('**', '**')}
                      className="p-2 hover:bg-white rounded-lg text-slate-500 transition-colors focus:ring-2 focus:ring-slate-900 outline-none" 
                      title="Bold"
                    >
                      <Bold size={16} />
                    </button>
                    <button 
                      type="button"
                      onClick={() => insertFormatting('*', '*')}
                      className="p-2 hover:bg-white rounded-lg text-slate-500 transition-colors focus:ring-2 focus:ring-slate-900 outline-none" 
                      title="Italic"
                    >
                      <Italic size={16} />
                    </button>
                    <button 
                      type="button"
                      onClick={() => insertFormatting('\n- ')}
                      className="p-2 hover:bg-white rounded-lg text-slate-500 transition-colors focus:ring-2 focus:ring-slate-900 outline-none" 
                      title="Bullet List"
                    >
                      <List size={16} />
                    </button>
                    <div className="w-px h-6 bg-slate-200 mx-1"></div>
                    <button 
                      type="button"
                      onClick={() => insertFormatting('[', '](https://)')}
                      className="p-2 hover:bg-white rounded-lg text-slate-500 transition-colors focus:ring-2 focus:ring-slate-900 outline-none" 
                      title="Add Link"
                    >
                      <Link size={16} />
                    </button>
                    <button 
                      type="button"
                      onClick={() => insertFormatting('![alt text](', ')')}
                      className="p-2 hover:bg-white rounded-lg text-slate-500 transition-colors focus:ring-2 focus:ring-slate-900 outline-none" 
                      title="Add Image"
                    >
                      <ImageIcon size={16} />
                    </button>
                    <button 
                      type="button"
                      onClick={() => insertFormatting('```\n', '\n```')}
                      className="p-2 hover:bg-white rounded-lg text-slate-500 transition-colors focus:ring-2 focus:ring-slate-900 outline-none" 
                      title="Code Block"
                    >
                      <Code size={16} />
                    </button>
                    <div className="flex-1"></div>
                    <button 
                      type="button"
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 text-white rounded-lg text-[10px] font-black uppercase tracking-widest shadow-sm hover:bg-blue-700 transition-all"
                    >
                      <Sparkles size={12} /> AI Assist
                    </button>
                  </div>
                  {/* Textarea for actual editing */}
                  <textarea 
                    ref={textareaRef}
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    className="w-full min-h-[450px] p-6 bg-white text-slate-700 text-base font-medium leading-relaxed outline-none resize-none placeholder:text-slate-300 placeholder:italic"
                    placeholder="Once upon a time in a digital landscape..."
                  />
                  <div className="px-4 py-2 bg-slate-50 border-t border-slate-100 flex justify-between items-center text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                    <span>{content.length} characters</span>
                    <span>Markdown Enabled</span>
                  </div>
                </div>
              ) : (
                <div className="min-h-[450px] w-full bg-slate-50/50 rounded-lg border border-slate-200 border-dashed p-12 flex flex-col items-center justify-center text-slate-400 gap-6 group hover:border-blue-300 hover:bg-blue-50/10 transition-all cursor-text relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-full h-1 bg-slate-100 overflow-hidden">
                      <div className="h-full bg-blue-500 w-1/4 animate-[loading_3s_infinite]"></div>
                  </div>
                  <div className="w-16 h-16 bg-white rounded-2xl shadow-sm flex items-center justify-center text-blue-500 group-hover:scale-110 transition-transform">
                    <Sparkles size={32} />
                  </div>
                  <div className="text-center space-y-2">
                    <p className="text-base font-bold text-slate-600">Start writing your story...</p>
                    <p className="text-xs font-medium text-slate-400">Use the visual builder or our AI assistant to create engaging content.</p>
                  </div>
                  <div className="flex flex-wrap justify-center gap-3">
                      <button className="px-6 py-2.5 bg-white border border-slate-200 rounded-xl text-sm font-bold text-slate-900 shadow-sm hover:shadow-md transition-all flex items-center gap-2">
                        <Sparkles size={16} className="text-blue-500" /> Use AI Assistant
                      </button>
                      <button className="px-6 py-2.5 bg-slate-900 text-white rounded-xl text-sm font-bold shadow-lg hover:bg-slate-800 transition-all flex items-center gap-2">
                        <Layers size={16} /> Open Visual Builder
                      </button>
                  </div>
                  <button 
                    onClick={() => setEditMode('text')}
                    className="mt-4 text-xs font-bold text-slate-400 hover:text-blue-600 transition-colors"
                  >
                    Wait, I prefer the traditional editor
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* SEO Section */}
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-6">
            <h3 className="font-bold text-slate-900 flex items-center gap-2">
              <Globe size={16} className="text-blue-600" /> Search Engine Optimization
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">SEO Title</label>
                <input 
                  type="text" 
                  value={title} 
                  onChange={(e) => setTitle(e.target.value)} 
                  className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm font-medium focus:bg-white focus:ring-2 focus:ring-blue-50 outline-none transition-all" 
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">URL Slug</label>
                <div className="flex items-center px-4 py-2 bg-slate-100 border border-slate-200 rounded-lg text-sm text-slate-500 font-mono">
                  <span>/</span>
                  <input 
                    type="text" 
                    value={title.toLowerCase().replace(/\s+/g, '-')} 
                    readOnly 
                    className="bg-transparent border-none outline-none flex-1 ml-0.5 cursor-not-allowed" 
                  />
                </div>
              </div>
            </div>
            {/* Meta Description Field */}
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2">
                <FileText size={12} /> Meta Description
              </label>
              <textarea 
                rows={3}
                value={seoDescription}
                onChange={(e) => setSeoDescription(e.target.value)}
                placeholder="Enter a brief summary of the page for search results (recommended length: 150-160 characters)..."
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg text-sm font-medium focus:bg-white focus:ring-2 focus:ring-blue-50 outline-none transition-all resize-none"
              />
              <div className="flex justify-between items-center px-1">
                <p className="text-[10px] text-slate-400 font-medium">Search results snippet preview.</p>
                <span className={`text-[10px] font-bold ${seoDescription.length > 160 ? 'text-red-500' : 'text-slate-400'}`}>
                  {seoDescription.length} / 160
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar Controls */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-6">
            <h3 className="text-[10px] font-black uppercase tracking-widest text-slate-400">Publishing Controls</h3>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between text-sm">
                <span className="flex items-center gap-2 text-slate-500 font-bold"><Eye size={14} /> Visibility</span>
                <span className="text-blue-600 font-bold bg-blue-50 px-2 py-0.5 rounded text-[10px]">Public</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="flex items-center gap-2 text-slate-500 font-bold"><Calendar size={14} /> Last Modified</span>
                <span className="text-slate-900 font-bold">Today, 14:32</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="flex items-center gap-2 text-slate-500 font-bold"><User size={14} /> Author</span>
                <span className="text-slate-900 font-bold">{post.author}</span>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 space-y-4">
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Status</label>
                <div className="relative group">
                  <select 
                    value={status} 
                    onChange={(e) => setStatus(e.target.value as any)}
                    className="w-full appearance-none px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold outline-none cursor-pointer focus:border-blue-500 transition-colors"
                  >
                    <option value="Published">Published</option>
                    <option value="Draft">Draft</option>
                    <option value="Archived">Archived</option>
                  </select>
                  <ChevronDown size={14} className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400" />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Template Selection</label>
                <div className="relative group">
                  <select 
                    value={template} 
                    onChange={(e) => setTemplate(e.target.value)}
                    className="w-full appearance-none px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold outline-none cursor-pointer focus:border-blue-500 transition-colors"
                  >
                    <option value="Default Sidebar">Default Sidebar</option>
                    <option value="Hero Layout">Hero Layout</option>
                    <option value="Full Width">Full Width</option>
                    <option value="Marketing Landing">Marketing Landing</option>
                    <option value="Empty Canvas">Empty Canvas</option>
                  </select>
                  <Layout size={14} className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400" />
                </div>
              </div>
            </div>

            {!fullPage && (
              <button 
                onClick={handleSave}
                className="w-full py-3.5 bg-slate-900 text-white rounded-xl text-sm font-bold shadow-xl shadow-slate-200 hover:bg-slate-800 transition-all flex items-center justify-center gap-2 active:scale-95"
              >
                {saved ? <Check size={18} /> : <Save size={18} />}
                {saved ? 'Successfully Saved' : 'Save Changes'}
              </button>
            )}
          </div>

          {/* Categories & Tags Section */}
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-6">
            <h3 className="text-[10px] font-black uppercase tracking-widest text-slate-400">Taxonomies</h3>
            
            <div className="space-y-5">
               <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Category</span>
                    <button 
                        onClick={() => setIsAddingCategory(!isAddingCategory)}
                        className="text-[10px] font-bold text-blue-600 hover:underline flex items-center gap-1"
                    >
                        {isAddingCategory ? 'Cancel' : <><Plus size={10} /> New</>}
                    </button>
                  </div>
                  
                  {isAddingCategory ? (
                    <div className="flex gap-2 animate-in slide-in-from-top-1 duration-200">
                        <input 
                            type="text" 
                            value={newCategoryName}
                            onChange={(e) => setNewCategoryName(e.target.value)}
                            placeholder="New category..."
                            className="flex-1 px-3 py-2 bg-white border border-blue-200 rounded-lg text-xs font-medium outline-none shadow-sm focus:ring-2 focus:ring-blue-50"
                            autoFocus
                        />
                        <button 
                            onClick={handleAddCategory}
                            className="p-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 shadow-md transition-all active:scale-90"
                        >
                            <Check size={14} />
                        </button>
                    </div>
                  ) : (
                    <div className="relative group">
                      <select 
                          value={category}
                          onChange={(e) => setCategory(e.target.value)}
                          className="w-full appearance-none px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold outline-none cursor-pointer focus:border-blue-500 transition-colors"
                      >
                          <option value="Fintech">Fintech</option>
                          <option value="Updates">Updates</option>
                          <option value="Design">Design</option>
                          <option value="Guides">Guides</option>
                          <option value="General">General</option>
                          {!['Fintech','Updates','Design','Guides','General'].includes(category) && (
                              <option value={category}>{category}</option>
                          )}
                      </select>
                      <ChevronDown size={14} className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400" />
                    </div>
                  )}
               </div>

               <div className="space-y-3 pt-4 border-t border-slate-100">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Tags & Keywords</span>
                  
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <Tag size={12} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input 
                          type="text" 
                          value={newTag}
                          onChange={(e) => setNewTag(e.target.value)}
                          onKeyDown={(e) => e.key === 'Enter' && addTag()}
                          placeholder="Add new tag..."
                          className="w-full pl-8 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium outline-none focus:bg-white focus:ring-2 focus:ring-blue-50 transition-all"
                      />
                    </div>
                    <button 
                        onClick={addTag}
                        className="p-2 bg-slate-100 text-slate-600 rounded-lg hover:bg-slate-200 transition-all"
                    >
                        <Plus size={16} />
                    </button>
                  </div>

                  <div className="flex flex-wrap gap-2 pt-1">
                    {tags.length > 0 ? tags.map(tag => (
                      <span key={tag} className="group flex items-center gap-1.5 px-3 py-1.5 bg-slate-50 text-slate-600 text-[10px] font-bold rounded-lg border border-slate-200 transition-all hover:bg-blue-50 hover:border-blue-200 hover:text-blue-700">
                        <Hash size={10} className="opacity-50" />
                        {tag}
                        <button onClick={() => removeTag(tag)} className="opacity-0 group-hover:opacity-100 transition-opacity hover:text-red-600 ml-1">
                            <X size={10} />
                        </button>
                      </span>
                    )) : (
                        <p className="text-[10px] text-slate-400 italic">Assign tags for better organization...</p>
                    )}
                  </div>
               </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PostEditor;
