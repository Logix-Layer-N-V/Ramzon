
import React, { useState, useContext } from 'react';
import { Search, Filter, HandCoins, ArrowDownCircle, MoreHorizontal, Download, ExternalLink } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { mockPayments, mockClients } from '../lib/mock-data';
import { LanguageContext } from '../App';

const PaymentsPage: React.FC = () => {
  const { t } = useContext(LanguageContext);
  const navigate = useNavigate();
  const [search, setSearch] = useState('');

  const filteredPayments = mockPayments.filter(p => {
    const client = mockClients.find(c => c.id === p.clientId);
    return client?.company.toLowerCase().includes(search.toLowerCase()) || 
           p.reference.toLowerCase().includes(search.toLowerCase());
  });

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-500 pb-10">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">{t('payments')}</h1>
          <p className="text-sm font-medium text-slate-500 italic">History of all incoming transactions and settlements</p>
        </div>
        <div className="flex gap-2">
            <button className="bg-slate-900 text-white px-5 py-2.5 rounded-xl text-sm font-black hover:bg-slate-800 transition-all flex items-center gap-2 shadow-xl active:scale-95">
                Export Statement
            </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between gap-4 bg-slate-50/20">
          <div className="flex-1 max-sm relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search by client or reference..." 
              className="w-full pl-9 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold outline-none focus:ring-2 focus:ring-emerald-100 transition-all shadow-sm"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <button className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-xl text-[10px] font-black uppercase tracking-widest bg-white text-slate-600 hover:bg-slate-50 transition-all">
            <Filter size={14} /> Filter Status
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm border-collapse">
            <thead className="bg-slate-50 border-b border-slate-100 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">
              <tr>
                <th className="px-6 py-4">Transaction / Client</th>
                <th className="px-6 py-4">Method</th>
                <th className="px-6 py-4">Date</th>
                <th className="px-6 py-4 text-right">Amount</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredPayments.map((p) => {
                const client = mockClients.find(c => c.id === p.clientId);
                return (
                  <tr 
                    key={p.id} 
                    onClick={() => navigate(`/payments/${p.id}`)}
                    className="hover:bg-slate-50/50 transition-colors group cursor-pointer"
                  >
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center shadow-inner group-hover:scale-110 transition-transform">
                          <ArrowDownCircle size={18} />
                        </div>
                        <div className="min-w-0">
                          <p className="font-black text-slate-900 truncate leading-tight">{client?.company || 'Unknown Client'}</p>
                          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tight">{p.reference}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 font-bold text-slate-600">{p.method}</td>
                    <td className="px-6 py-4 font-bold text-slate-400">{p.date}</td>
                    <td className="px-6 py-4 text-right font-black text-emerald-600 italic text-base">
                      +€{p.amount.toLocaleString()}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex justify-end gap-1 opacity-0 group-hover:opacity-100 transition-all">
                        <button 
                          onClick={(e) => { e.stopPropagation(); }}
                          className="p-2 text-slate-400 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
                        >
                          <Download size={16} />
                        </button>
                        <button 
                          onClick={(e) => { e.stopPropagation(); }}
                          className="p-2 text-slate-400 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
                        >
                          <ExternalLink size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default PaymentsPage;
