
import React, { useState } from 'react';
import { Search, Plus, ClipboardList, Send, CheckCircle2, MoreVertical, ArrowRight, FileText, Check, Pencil } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { mockEstimates } from '../lib/mock-data';
import { Estimate } from '../types';

const QuotesPage: React.FC = () => {
  const navigate = useNavigate();
  const [estimates, setEstimates] = useState<Estimate[]>(mockEstimates);

  const handleApprove = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setEstimates(prev => prev.map(e => e.id === id ? { ...e, status: 'Accepted' } : e));
  };

  const handleConvert = (e: React.MouseEvent, estimate: Estimate) => {
    e.stopPropagation();
    navigate('/invoices/new', { state: { fromEstimate: estimate } });
  };

  const handleEdit = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    // Navigeer naar de bewerk-pagina (route moet bestaan in App.tsx)
    navigate(`/estimates/edit/${id}`);
  };

  const goToDetail = (id: string) => {
    navigate(`/estimates/${id}`);
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-500">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight italic uppercase">Estimates</h1>
          <p className="text-sm font-bold text-brand-primary/60 italic">Start your estimate here with existing client or create new client</p>
        </div>
        <button 
          onClick={() => navigate('/estimates/new')}
          className="bg-slate-900 text-white px-5 py-2.5 rounded-xl text-sm font-black hover:bg-slate-800 transition-all flex items-center gap-2 shadow-xl shadow-slate-200 active:scale-95"
        >
          <Plus size={18} /> Nieuwe Offerte
        </button>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-8 border-b border-slate-100 bg-slate-50/10 flex flex-col md:flex-row gap-6 justify-between items-center text-center md:text-left">
          <div className="space-y-1">
            <h2 className="text-3xl font-black text-slate-900 italic">€{estimates.reduce((a,b) => a + b.total, 0).toLocaleString()}</h2>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Totale Waarde in Pijplijn</p>
          </div>
          <div className="flex gap-4">
             <div className="px-4 py-2 bg-emerald-50 text-emerald-700 rounded-xl text-[9px] font-black uppercase tracking-widest border border-emerald-100 shadow-sm">
               {estimates.filter(e => e.status === 'Accepted').length} Akkoord
             </div>
             <div className="px-4 py-2 bg-blue-50 text-blue-700 rounded-xl text-[9px] font-black uppercase tracking-widest border border-blue-100 shadow-sm">
               {estimates.filter(e => e.status === 'Sent').length} Verzonden
             </div>
          </div>
        </div>

        <div className="divide-y divide-slate-50">
          {estimates.map((q) => (
            <div 
              key={q.id} 
              onClick={() => goToDetail(q.id)}
              className="p-6 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:bg-slate-50/80 transition-all group cursor-pointer border-l-4 border-l-transparent hover:border-l-brand-primary"
            >
              <div className="flex items-center gap-4">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-colors shadow-inner group-hover:scale-110 transition-transform ${
                  q.status === 'Accepted' ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-400'
                }`}>
                  <ClipboardList size={24} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-black text-slate-900 group-hover:text-brand-primary transition-colors text-base italic uppercase">{q.clientName}</span>
                    <span className={`px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-widest border ${
                      q.status === 'Accepted' ? 'bg-emerald-500 text-white border-emerald-600' : 'bg-slate-100 text-slate-500 border-slate-200'
                    }`}>{q.status}</span>
                  </div>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">{q.estimateNumber} • {q.date}</p>
                </div>
              </div>

              <div className="flex items-center justify-between md:justify-end gap-6">
                <div className="text-right mr-4">
                  <p className="text-lg font-black text-slate-900 italic tracking-tight">€{q.total.toLocaleString()}</p>
                  <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest">Offertebedrag</p>
                </div>

                <div className="flex items-center gap-2">
                  <button 
                    onClick={(e) => handleEdit(e, q.id)}
                    className="p-3 bg-white border border-slate-200 text-slate-400 hover:text-brand-primary hover:border-brand-primary rounded-xl transition-all shadow-sm group/btn"
                    title="Bewerk Offerte"
                  >
                    <Pencil size={16} />
                  </button>
                  
                  {q.status === 'Sent' && (
                    <button 
                      onClick={(e) => handleApprove(e, q.id)}
                      className="px-5 py-2.5 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-emerald-500 hover:text-white transition-all flex items-center gap-2 shadow-sm"
                    >
                      <Check size={14} /> Approve
                    </button>
                  )}
                  {q.status === 'Accepted' && (
                    <button 
                      onClick={(e) => handleConvert(e, q)}
                      className="px-5 py-2.5 bg-brand-primary text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:opacity-90 transition-all flex items-center gap-2 shadow-xl shadow-brand-primary/20 animate-pulse"
                    >
                      <FileText size={14} /> Convert to Invoice
                    </button>
                  )}
                  <div className="p-2 text-slate-200 group-hover:text-slate-900 group-hover:translate-x-1 transition-all">
                    <ArrowRight size={22} />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default QuotesPage;
