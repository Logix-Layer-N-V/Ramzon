
import React from 'react';
import { Search, Plus, Package, Box, Ruler, Info, ArrowUpRight } from 'lucide-react';
import { mockWoodProducts } from '../lib/mock-data';
import { useNavigate } from 'react-router-dom';

const ProductsPage: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-500">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">Wood Catalog</h1>
          <p className="text-sm font-medium text-slate-500 italic">Manage timber dimensions, houtsoorten and inventory</p>
        </div>
        <button 
          onClick={() => navigate('/products/new')}
          className="bg-slate-900 text-white px-5 py-2.5 rounded-xl text-sm font-black hover:bg-slate-800 transition-all flex items-center gap-2 shadow-xl active:scale-95"
        >
          <Plus size={18} /> Add Product
        </button>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-100 bg-slate-50/20 flex items-center justify-between gap-4">
           <div className="flex-1 max-w-sm relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search wood species or size..." 
              className="w-full pl-9 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold outline-none shadow-sm"
            />
          </div>
          <div className="flex gap-2">
            <button className="px-4 py-2 bg-white border border-slate-200 rounded-xl text-[10px] font-black uppercase tracking-widest text-slate-500 hover:text-slate-900">Categories</button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 border-b border-slate-100 text-[10px] font-black text-slate-400 uppercase tracking-widest">
              <tr>
                <th className="px-6 py-4">Houtsoort / Product</th>
                <th className="px-6 py-4">Afmetingen (mm)</th>
                <th className="px-6 py-4 text-center">Unit</th>
                <th className="px-6 py-4 text-center">Stock</th>
                <th className="px-6 py-4 text-right">Price per Unit</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {mockWoodProducts.map((p) => (
                <tr key={p.id} className="hover:bg-slate-50/50 transition-colors cursor-pointer group">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-400 group-hover:bg-amber-100 group-hover:text-amber-800 transition-colors">
                        <Package size={20} />
                      </div>
                      <div>
                        <div className="font-black text-slate-900">{p.name}</div>
                        <div className="text-[10px] font-black text-emerald-600 uppercase tracking-widest italic">{p.woodType}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2 font-mono text-xs font-bold text-slate-500 bg-slate-50 px-3 py-1 rounded-lg w-fit">
                      <Ruler size={12} />
                      {p.thickness} x {p.width} x {p.length}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-center font-black text-slate-400 italic">{p.unit}</td>
                  <td className="px-6 py-4 text-center">
                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-black ${
                      p.stock > 10 ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'
                    }`}>
                      {p.stock} {p.unit}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right font-black text-slate-900 italic">€{p.pricePerUnit}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ProductsPage;
