
import React from 'react';
import { ArrowLeft, Wallet, Tag, DollarSign, Calendar, Save, Trash2, Plus } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const CreateExpensePage: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center justify-between">
        <button onClick={() => navigate('/expenses')} className="flex items-center gap-2 text-slate-500 hover:text-slate-900 font-bold">
          <ArrowLeft size={18} /> Back to Expenses
        </button>
        <button className="bg-red-600 text-white px-8 py-2.5 rounded-xl font-black text-sm shadow-xl shadow-red-100 active:scale-95 transition-all">
          <Save size={18} /> Log Expense
        </button>
      </div>

      <div className="max-w-2xl mx-auto bg-white p-10 rounded-[40px] border border-slate-200 shadow-sm space-y-8">
        <div className="flex items-center gap-4">
           <div className="w-14 h-14 bg-red-50 text-red-600 rounded-2xl flex items-center justify-center shadow-inner">
             <Wallet size={28} />
           </div>
           <div>
             <h2 className="text-2xl font-black text-slate-900 tracking-tight">Record New Expense</h2>
             <p className="text-slate-400 font-bold uppercase tracking-widest text-[10px]">Cost Tracking</p>
           </div>
        </div>

        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
             <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                  <DollarSign size={12} /> Amount (€)
                </label>
                <input type="number" placeholder="0.00" className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-lg font-black outline-none focus:bg-white transition-all shadow-inner" />
             </div>
             <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                  <Calendar size={12} /> Date
                </label>
                <input type="date" defaultValue={new Date().toISOString().split('T')[0]} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold outline-none" />
             </div>
          </div>

          <div className="space-y-1.5">
             <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
               <Tag size={12} /> Category
             </label>
             <select className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold outline-none">
               <option>Inventory / Wood Stock</option>
               <option>Logistics & Shipping</option>
               <option>Rent & Utilities</option>
               <option>Marketing</option>
               <option>Tools & Machinery</option>
             </select>
          </div>

          <div className="space-y-1.5">
             <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
               Description
             </label>
             <input type="text" placeholder="e.g. Fuel for truck #02" className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold outline-none" />
          </div>
        </div>

        <div className="pt-6 border-t border-slate-50 flex items-center gap-4">
           <button className="flex items-center gap-2 text-xs font-bold text-slate-400 hover:text-red-600 transition-colors">
             <Trash2 size={14} /> Discard Draft
           </button>
        </div>
      </div>
    </div>
  );
};

export default CreateExpensePage;
