
import React from 'react';
import { ArrowLeft, Plus, ClipboardList, Send, Calculator, Save } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const CreateQuotePage: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center justify-between">
        <button onClick={() => navigate('/quotes')} className="flex items-center gap-2 text-slate-500 hover:text-slate-900 font-bold">
          <ArrowLeft size={18} /> Back to Quotes
        </button>
        <button className="bg-slate-900 text-white px-8 py-2.5 rounded-xl font-black text-sm shadow-xl flex items-center gap-2 active:scale-95 transition-all">
          <Send size={18} /> Send Proposal
        </button>
      </div>

      <div className="max-w-4xl mx-auto bg-white p-12 rounded-[48px] border border-slate-200 shadow-sm space-y-10">
        <div className="flex flex-col items-center text-center gap-4">
          <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-3xl flex items-center justify-center shadow-inner">
            <ClipboardList size={32} />
          </div>
          <div>
            <h2 className="text-3xl font-black text-slate-900 tracking-tight">Timber Price Quote</h2>
            <p className="text-slate-500 font-medium italic">Create a detailed proposal for Wood supply</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Prospective Client</label>
            <input type="text" placeholder="Enter company name..." className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold focus:bg-white transition-all outline-none" />
          </div>
          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Quote Valid Until</label>
            <input type="date" className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold" />
          </div>
        </div>

        <div className="p-8 border-2 border-dashed border-slate-100 rounded-3xl flex flex-col items-center justify-center gap-4 bg-slate-50/20">
          <Calculator size={40} className="text-slate-200" />
          <p className="text-slate-400 font-bold italic">No wood dimensions added yet.</p>
          <button className="px-6 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold shadow-lg">Add Wood Species Item</button>
        </div>

        <div className="pt-10 border-t border-slate-100 flex justify-between items-center">
          <p className="text-xs font-bold text-slate-400 italic">StaticPress • Ramzon N.V. Quote Engine</p>
          <div className="flex gap-4">
            <button className="px-6 py-2 border border-slate-200 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-50">Save Draft</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreateQuotePage;
