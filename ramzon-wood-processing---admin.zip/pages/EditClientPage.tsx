
import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Building, Mail, Phone, MapPin, Save, Hash, Info, User, AlertCircle } from 'lucide-react';
import { mockClients } from '../lib/mock-data';

const EditClientPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [client, setClient] = useState(mockClients.find(c => c.id === id));
  const [email, setEmail] = useState(client?.email || '');
  const [emailError, setEmailError] = useState(false);

  if (!client) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] text-slate-400">
        <User size={48} className="mb-4 opacity-20" />
        <h2 className="text-xl font-bold">Klant niet gevonden</h2>
        <button onClick={() => navigate('/clients')} className="mt-4 px-4 py-2 bg-slate-900 text-white rounded-xl font-bold text-sm">
          Terug naar CRM
        </button>
      </div>
    );
  }

  const handleEmailChange = (val: string) => {
    setEmail(val);
    // Check of email al bestaat bij een ANDERE klant dan degene die we nu bewerken
    const exists = mockClients.some(c => c.email.toLowerCase() === val.toLowerCase() && c.id !== id);
    setEmailError(exists);
  };

  const handleSave = () => {
    if (emailError) return;
    navigate(`/clients/${id}`);
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20">
      <div className="flex items-center justify-between">
        <button onClick={() => navigate(`/clients/${id}`)} className="flex items-center gap-2 text-slate-500 hover:text-slate-900 font-semibold text-sm transition-all">
          <ArrowLeft size={16} /> Annuleren
        </button>
        <button 
          onClick={handleSave}
          disabled={emailError}
          className={`px-8 py-2.5 rounded-xl font-bold text-xs shadow-md transition-all flex items-center gap-2 ${
            emailError 
            ? 'bg-slate-200 text-slate-400 cursor-not-allowed' 
            : 'bg-brand-primary text-white active:scale-95 hover:bg-slate-800'
          }`}
        >
          <Save size={18} /> Wijzigingen Opslaan
        </button>
      </div>

      <div className="max-w-3xl mx-auto space-y-6">
        <div className="bg-white p-8 md:p-10 rounded-2xl border border-slate-200 shadow-sm space-y-8">
          <div className="flex items-center gap-4">
             <div className="w-12 h-12 bg-blue-50 text-brand-primary rounded-xl flex items-center justify-center shadow-inner">
               <User size={24} />
             </div>
             <div>
               <h2 className="text-xl font-bold text-slate-900 tracking-tight">Relatie Bewerken</h2>
               <p className="text-slate-400 font-bold uppercase tracking-wider text-[10px]">Klant ID: {client.id.toUpperCase()}</p>
             </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-1.5 md:col-span-2">
              <label className={`text-[10px] font-bold uppercase tracking-widest flex items-center gap-2 ${emailError ? 'text-red-500' : 'text-slate-500'}`}>
                <Mail size={12} /> E-mailadres (Unieke Sleutel)
              </label>
              <div className="relative">
                <input 
                  type="email" 
                  value={email}
                  onChange={(e) => handleEmailChange(e.target.value)}
                  className={`w-full px-4 py-2.5 border rounded-xl text-sm font-semibold outline-none transition-all ${
                    emailError 
                    ? 'bg-red-50 border-red-200 focus:ring-2 focus:ring-red-100' 
                    : 'bg-slate-50 border-slate-200 focus:ring-2 focus:ring-brand-accent-light focus:bg-white'
                  }`} 
                />
                {emailError && (
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 text-red-500 flex items-center gap-1.5 animate-in fade-in zoom-in-95">
                    <AlertCircle size={16} />
                    <span className="text-[10px] font-black uppercase tracking-tight">E-mail al in gebruik bij andere klant</span>
                  </div>
                )}
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-2">
                <Building size={12} /> Bedrijfsnaam
              </label>
              <input 
                type="text" 
                defaultValue={client.company}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold outline-none focus:ring-2 focus:ring-brand-accent-light focus:bg-white transition-all" 
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-2">
                <Hash size={12} /> BTW Nummer
              </label>
              <input 
                type="text" 
                defaultValue={client.vatNumber}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold outline-none focus:ring-2 focus:ring-brand-accent-light focus:bg-white transition-all" 
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-2">
                <User size={12} /> Contactpersoon
              </label>
              <input 
                type="text" 
                defaultValue={client.name}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold outline-none focus:ring-2 focus:ring-brand-accent-light focus:bg-white transition-all" 
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-2">
                <Phone size={12} /> Telefoonnummer
              </label>
              <input 
                type="text" 
                defaultValue={client.phone}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold outline-none focus:ring-2 focus:ring-brand-accent-light focus:bg-white transition-all" 
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-2">
              <MapPin size={12} /> Vestigingsadres
            </label>
            <textarea 
              rows={3} 
              defaultValue={client.address}
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold outline-none focus:ring-2 focus:ring-brand-accent-light focus:bg-white transition-all resize-none" 
            />
          </div>

          <div className="p-4 bg-amber-50/50 rounded-xl border border-amber-100 flex gap-4 items-start">
            <Info size={20} className="text-amber-600 shrink-0" />
            <p className="text-[11px] font-semibold text-slate-500 leading-relaxed italic">
              Het wijzigen van het e-mailadres kan invloed hebben op hoe de klant inlogt op een eventueel klantportaal.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EditClientPage;
