
import React, { useState, useRef, useEffect } from 'react';
import { 
  BarChart3, 
  Download, 
  TrendingUp, 
  FileText, 
  Calendar, 
  Filter, 
  ChevronDown,
  Receipt,
  ClipboardList,
  Wallet,
  Scale,
  Search,
  MoreHorizontal,
  Play,
  RotateCcw,
  Sparkles,
  CalendarDays,
  Target,
  ArrowRight,
  Clock,
  Settings2,
  Check
} from 'lucide-react';

type ReportType = 'sales' | 'estimates' | 'invoices' | 'payments' | 'profit_loss';
type DateMode = 'presets' | 'custom';

const FinanceReportsPage: React.FC = () => {
  const currentYear = new Date().getFullYear();
  
  // Intelligence Model State
  const [reportType, setReportType] = useState<ReportType>('sales');
  const [isModelDropdownOpen, setIsModelDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Date Filtering States
  const [dateMode, setDateMode] = useState<DateMode>('presets');
  const [selectedDay, setSelectedDay] = useState<string>('Alle');
  const [selectedMonth, setSelectedMonth] = useState<string>('Alle maanden');
  const [selectedYear, setSelectedYear] = useState<string>(currentYear.toString());
  const [customStartDate, setCustomStartDate] = useState('');
  const [customEndDate, setCustomEndDate] = useState('');

  // Execution State
  const [isRunning, setIsRunning] = useState(false);
  const [appliedReportType, setAppliedReportType] = useState<ReportType>('sales');

  const days = ['Alle', 'ma', 'di', 'wo', 'do', 'vr', 'za', 'zo'];
  const months = ['Alle maanden', 'jan', 'feb', 'maa', 'apr', 'mei', 'jun', 'jul', 'aug', 'sep', 'okt', 'nov', 'dec'];
  const years = Array.from({ length: currentYear - 1980 + 1 }, (_, i) => (currentYear - i).toString());

  const reportOptions = [
    { id: 'sales', label: 'Sales Performance', icon: BarChart3, color: 'text-blue-500', bg: 'bg-blue-50', desc: 'Revenue analytics and growth' },
    { id: 'estimates', label: 'Estimates & Quotes', icon: ClipboardList, color: 'text-purple-500', bg: 'bg-purple-50', desc: 'Pipeline and proposal tracking' },
    { id: 'invoices', label: 'Invoice Ledger', icon: Receipt, color: 'text-emerald-500', bg: 'bg-emerald-50', desc: 'Accounts receivable status' },
    { id: 'payments', label: 'Payment History', icon: Wallet, color: 'text-amber-500', bg: 'bg-amber-50', desc: 'Settlement and cashflow logs' },
    { id: 'profit_loss', label: 'Winst & Verlies (P&L)', icon: Scale, color: 'text-brand-primary', bg: 'bg-slate-50', desc: 'Full financial health summary' },
  ];

  const currentModel = reportOptions.find(o => o.id === reportType) || reportOptions[0];

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsModelDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleRunReport = () => {
    setIsRunning(true);
    setTimeout(() => {
      setAppliedReportType(reportType);
      setIsRunning(false);
    }, 800);
  };

  const revenueData = [
    { m: 'Jan', v: 65 }, { m: 'Feb', v: 82 }, { m: 'Mar', v: 45 }, 
    { m: 'Apr', v: 91 }, { m: 'May', v: 76 }, { m: 'Jun', v: 88 }, 
    { m: 'Jul', v: 52 }, { m: 'Aug', v: 95 }, { m: 'Sep', v: 61 }, 
    { m: 'Oct', v: 84 }, { m: 'Nov', v: 73 }, { m: 'Dec', v: 90 }
  ];

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20">
      {/* Header section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Finance Intelligence</h1>
          <p className="text-sm font-semibold text-slate-500">Enterprise Analytical Suite v4.2</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={() => window.open('#/reports/finance/print', '_blank')}
            className="bg-slate-900 text-white px-4 py-2 rounded-xl text-xs font-semibold hover:bg-slate-800 transition-all flex items-center gap-2 shadow-xl active:scale-95"
          >
            <FileText size={16} /> Print Report
          </button>
          <button className="bg-white border border-slate-200 text-slate-600 px-4 py-2 rounded-xl text-xs font-semibold hover:bg-slate-50 transition-all flex items-center gap-2 shadow-sm active:scale-95">
            <Download size={16} /> Data Export
          </button>
        </div>
      </div>

      {/* INTELLIGENCE FILTER ENGINE */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-visible">
        <div className="p-6 md:p-8 space-y-8">
          
          {/* Row 1: Report Model Selection */}
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-8">
            <div className="space-y-3 flex-1 relative" ref={dropdownRef}>
              <div className="flex items-center gap-2">
                 <div className="w-1.5 h-1.5 rounded-full bg-brand-accent animate-pulse"></div>
                 <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Select Intelligence Model</h3>
              </div>
              
              {/* Premium Custom Dropdown */}
              <button 
                onClick={() => setIsModelDropdownOpen(!isModelDropdownOpen)}
                className="w-full lg:max-w-md flex items-center justify-between px-5 py-3 bg-slate-50 border border-slate-200 rounded-xl hover:border-brand-primary transition-all group"
              >
                <div className="flex items-center gap-4">
                  <div className={`p-2 rounded-lg ${currentModel.bg} ${currentModel.color} shadow-sm group-hover:scale-105 transition-transform`}>
                    <currentModel.icon size={20} />
                  </div>
                  <div className="text-left">
                    <p className="text-sm font-bold text-slate-900 leading-none">{currentModel.label}</p>
                    <p className="text-[10px] text-slate-400 font-semibold mt-1 uppercase tracking-tight">{currentModel.desc}</p>
                  </div>
                </div>
                <ChevronDown size={18} className={`text-slate-300 transition-transform duration-300 ${isModelDropdownOpen ? 'rotate-180 text-brand-primary' : ''}`} />
              </button>

              {/* Dropdown Menu */}
              {isModelDropdownOpen && (
                <div className="absolute top-full left-0 mt-2 w-full lg:max-w-md bg-white border border-slate-100 rounded-xl shadow-lg z-[100] p-2 animate-in fade-in zoom-in-95 duration-200">
                  {reportOptions.map((opt) => (
                    <button
                      key={opt.id}
                      onClick={() => { setReportType(opt.id as ReportType); setIsModelDropdownOpen(false); }}
                      className={`w-full flex items-center justify-between p-3 rounded-lg transition-all ${reportType === opt.id ? 'bg-brand-primary text-white' : 'hover:bg-slate-50'}`}
                    >
                      <div className="flex items-center gap-4">
                        <div className={`p-2 rounded-lg ${reportType === opt.id ? 'bg-white/10 text-brand-accent' : `${opt.bg} ${opt.color}`}`}>
                          <opt.icon size={18} />
                        </div>
                        <div className="text-left">
                          <p className={`text-xs font-bold ${reportType === opt.id ? 'text-white' : 'text-slate-900'}`}>{opt.label}</p>
                          <p className={`text-[9px] font-semibold ${reportType === opt.id ? 'text-white/60' : 'text-slate-400'}`}>{opt.desc}</p>
                        </div>
                      </div>
                      {reportType === opt.id && <Check size={16} className="text-brand-accent" />}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Date Mode Toggle */}
            <div className="space-y-3">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider text-right">Filtering Precision</h3>
              <div className="bg-slate-50 p-1 rounded-xl flex gap-1 border border-slate-100 shadow-inner">
                <button 
                  onClick={() => setDateMode('presets')}
                  className={`px-6 py-2 rounded-lg text-xs font-bold uppercase tracking-tight transition-all ${dateMode === 'presets' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                >
                  Standard Presets
                </button>
                <button 
                  onClick={() => setDateMode('custom')}
                  className={`px-6 py-2 rounded-lg text-xs font-bold uppercase tracking-tight transition-all ${dateMode === 'custom' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                >
                  Custom Range
                </button>
              </div>
            </div>
          </div>

          {/* Row 2: Temporal Grid / Custom Range Transition */}
          <div className="pt-8 border-t border-slate-50">
            {dateMode === 'presets' ? (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 animate-in fade-in slide-in-from-left-4 duration-500">
                {/* Day Selector */}
                <div className="lg:col-span-6 space-y-3">
                   <div className="flex items-center gap-2 text-slate-400">
                      <CalendarDays size={14} />
                      <span className="text-xs font-bold uppercase tracking-wider">Select Dynamic Day</span>
                   </div>
                   <div className="bg-slate-50 p-1 rounded-xl flex gap-1 shadow-inner border border-slate-100">
                      {days.map((day) => (
                        <button
                          key={day}
                          onClick={() => setSelectedDay(day)}
                          className={`flex-1 py-3 rounded-lg text-xs font-bold uppercase tracking-tight transition-all ${
                            selectedDay === day 
                              ? 'bg-brand-primary text-white shadow-md' 
                              : 'text-slate-400 hover:text-slate-600 hover:bg-white/50'
                          }`}
                        >
                          {day}
                        </button>
                      ))}
                   </div>
                </div>

                {/* Month Picker */}
                <div className="lg:col-span-3 space-y-3">
                   <div className="flex items-center gap-2 text-slate-400">
                      <Target size={14} />
                      <span className="text-xs font-bold uppercase tracking-wider">Target Month</span>
                   </div>
                   <div className="relative group">
                     <select 
                      value={selectedMonth}
                      onChange={(e) => setSelectedMonth(e.target.value)}
                      className="w-full appearance-none bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold outline-none group-hover:border-brand-primary transition-all cursor-pointer"
                     >
                       {months.map(m => <option key={m} value={m}>{m.toUpperCase()}</option>)}
                     </select>
                     <ChevronDown size={18} className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-300 group-hover:text-brand-primary" />
                   </div>
                </div>

                {/* Year Picker */}
                <div className="lg:col-span-3 space-y-3">
                   <div className="flex items-center gap-2 text-slate-400">
                      <Clock size={14} />
                      <span className="text-xs font-bold uppercase tracking-wider">Fiscal Year</span>
                   </div>
                   <div className="relative group">
                     <select 
                      value={selectedYear}
                      onChange={(e) => setSelectedYear(e.target.value)}
                      className="w-full appearance-none bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold outline-none group-hover:border-brand-primary transition-all cursor-pointer"
                     >
                       {years.map(y => <option key={y} value={y}>{y}</option>)}
                     </select>
                     <ChevronDown size={18} className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-300 group-hover:text-brand-primary" />
                   </div>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-in fade-in slide-in-from-right-4 duration-500">
                <div className="space-y-3">
                   <div className="flex items-center gap-2 text-slate-400">
                      <Calendar size={14} />
                      <span className="text-xs font-bold uppercase tracking-wider">Start Period Datum</span>
                   </div>
                   <div className="relative">
                      <input 
                        type="date" 
                        value={customStartDate}
                        onChange={(e) => setCustomStartDate(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-3 text-sm font-bold outline-none focus:ring-2 focus:ring-brand-accent-light focus:border-brand-primary transition-all"
                      />
                   </div>
                </div>
                <div className="space-y-3">
                   <div className="flex items-center gap-2 text-slate-400">
                      <ArrowRight size={14} />
                      <span className="text-xs font-bold uppercase tracking-wider">Eind Period Datum</span>
                   </div>
                   <div className="relative">
                      <input 
                        type="date" 
                        value={customEndDate}
                        onChange={(e) => setCustomEndDate(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-3 text-sm font-bold outline-none focus:ring-2 focus:ring-brand-accent-light focus:border-brand-primary transition-all"
                      />
                   </div>
                </div>
              </div>
            )}
          </div>

          {/* Action Row */}
          <div className="flex flex-col md:flex-row items-center justify-between gap-6 pt-8 border-t border-slate-50">
            <div className="flex items-center gap-3 text-slate-400 font-semibold text-xs">
              <div className="w-8 h-8 bg-slate-50 rounded-lg flex items-center justify-center shadow-inner">
                <Sparkles size={16} className="text-brand-accent" />
              </div>
              <span>Intelligence engine is tracking {dateMode === 'custom' ? 'a manual range' : `preset: ${selectedMonth} ${selectedYear}`}.</span>
            </div>
            <div className="flex gap-3 w-full md:w-auto">
              <button 
                onClick={() => { setReportType('sales'); setSelectedDay('Alle'); setDateMode('presets'); }}
                className="flex-1 md:flex-none px-6 py-3 text-slate-400 hover:text-red-500 font-bold text-xs uppercase tracking-wider transition-all flex items-center gap-2"
              >
                <RotateCcw size={14} /> Clear Engine
              </button>
              <button 
                onClick={handleRunReport}
                disabled={isRunning}
                className="flex-1 md:flex-none bg-slate-900 text-white px-10 py-3.5 rounded-xl text-xs font-bold uppercase tracking-wider shadow-md hover:bg-slate-800 active:scale-95 transition-all flex items-center justify-center gap-3 disabled:opacity-50"
              >
                {isRunning ? (
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                ) : (
                  <>
                    <Settings2 size={16} className="text-brand-accent" />
                    Apply Analytics
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { label: 'Intelligence Output', val: '€842.5k', trend: '+12%', color: 'bg-emerald-50', text: 'text-emerald-600', icon: TrendingUp },
          { label: 'Active Pipeline', val: '€124.2k', trend: '+4%', color: 'bg-red-50', text: 'text-red-600', icon: Clock },
          { label: 'Model Confidence', val: '98.2%', trend: 'Stable', color: 'bg-blue-50', text: 'text-blue-600', icon: Target },
        ].map((kpi, i) => (
          <div key={i} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm relative overflow-hidden group hover:shadow-md transition-all duration-300">
            <div className={`absolute top-0 right-0 w-24 h-24 ${kpi.color} rounded-full -translate-y-1/2 translate-x-1/2 opacity-20 group-hover:scale-125 transition-transform duration-700`}></div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">{kpi.label}</p>
            <div className="flex items-end justify-between">
               <p className="text-3xl font-bold text-slate-900 tracking-tight">{kpi.val}</p>
               <span className={`text-[10px] font-bold ${kpi.text} flex items-center gap-1.5 bg-white border border-slate-100 px-2.5 py-1 rounded-full shadow-sm`}>
                 {kpi.trend} <kpi.icon size={10} />
               </span>
            </div>
          </div>
        ))}
      </div>

      {/* Ledger Section */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="px-6 py-6 border-b border-slate-50 flex items-center justify-between bg-slate-50/10">
          <div className="flex items-center gap-4">
             <div className="w-10 h-10 rounded-xl bg-brand-primary text-white flex items-center justify-center shadow-md">
                <FileText size={20} />
             </div>
             <div>
                <h3 className="text-base font-bold text-slate-900 tracking-tight">{currentModel.label} Ledger</h3>
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-tight">Live data feed • {dateMode === 'custom' ? `${customStartDate} to ${customEndDate}` : `${selectedMonth} ${selectedYear}`}</p>
             </div>
          </div>
          <div className="relative hidden sm:block">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-300" />
            <input type="text" placeholder="Search ledger..." className="pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-xs font-semibold focus:ring-2 focus:ring-brand-accent-light outline-none" />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50/50 text-[10px] font-bold text-slate-400 uppercase tracking-widest border-b border-slate-100">
              <tr>
                <th className="px-6 py-4">Identity Reference</th>
                <th className="px-4 py-4">Target Entity</th>
                <th className="px-4 py-4 text-center">Temporal Index</th>
                <th className="px-4 py-4 text-right">Value Amount</th>
                <th className="px-6 py-4 text-right">Model Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {[1, 2, 3].map((_, idx) => (
                <tr key={idx} className="hover:bg-slate-50/80 transition-colors group cursor-pointer">
                  <td className="px-6 py-5 font-bold text-slate-900 text-sm">#TXN-9982-Z{idx}</td>
                  <td className="px-4 py-5">
                    <p className="text-sm font-bold text-slate-700">Royal Timber Logistics</p>
                    <p className="text-[10px] font-semibold text-slate-400 uppercase">Tier 1 Partner</p>
                  </td>
                  <td className="px-4 py-5 text-center font-semibold text-slate-400 tracking-tight">2024-03-12</td>
                  <td className="px-4 py-5 text-right font-bold text-slate-900 text-base">€14.280,00</td>
                  <td className="px-6 py-5 text-right">
                    <button className="p-2.5 bg-white border border-slate-100 rounded-lg text-slate-300 hover:text-slate-900 hover:shadow-sm transition-all">
                      <MoreHorizontal size={18} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        <div className="px-6 py-5 bg-slate-50/50 border-t border-slate-100 flex flex-col sm:flex-row justify-between items-center gap-4">
           <p className="text-xs font-semibold text-slate-400 uppercase tracking-tight italic">Synchronized with master database • Total records: 482</p>
           <div className="flex gap-2">
              <button className="px-4 py-2 bg-white border border-slate-200 rounded-lg text-[10px] font-bold uppercase text-slate-400">Previous</button>
              <button className="px-4 py-2 bg-white border border-slate-200 rounded-lg text-[10px] font-bold uppercase text-slate-900 shadow-sm">Next Intelligence Block</button>
           </div>
        </div>
      </div>
    </div>
  );
};

export default FinanceReportsPage;
