
import React from 'react';
import { useParams, Navigate } from 'react-router-dom';
import { mockPosts } from '../lib/mock-data';
import PostEditor from '../components/PostEditor';

interface PostEditorPageProps {
  type: 'post' | 'page';
}

const PostEditorPage: React.FC<PostEditorPageProps> = ({ type }) => {
  const { id } = useParams<{ id: string }>();
  const post = mockPosts.find(p => p.id === id);

  if (!post) {
    return <Navigate to={type === 'post' ? '/posts' : '/pages'} replace />;
  }

  return (
    <div className="py-2">
      <PostEditor post={post} fullPage={true} />
    </div>
  );
};

export default PostEditorPage;
