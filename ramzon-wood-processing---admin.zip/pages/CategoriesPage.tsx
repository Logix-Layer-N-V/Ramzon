
import React, { useState } from 'react';
import { Layers, Plus, Search, MoreVertical, Hash, FolderOpen } from 'lucide-react';

interface CategoriesPageProps {
  type: 'post' | 'page';
}

const CategoriesPage: React.FC<CategoriesPageProps> = ({ type }) => {
  const [categories, setCategories] = useState(
    type === 'post' 
      ? ['Fintech', 'Updates', 'Design', 'News', 'Engineering'] 
      : ['General', 'Information', 'Legal', 'Marketing']
  );

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-500">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            {type === 'post' ? 'Post Categories' : 'Page Categories'}
          </h1>
          <p className="text-slate-500 text-sm">Organize your {type}s into logical groups</p>
        </div>
        <button className="bg-slate-900 text-white px-5 py-2.5 rounded-lg text-sm font-bold hover:bg-slate-800 transition-all flex items-center gap-2 shadow-sm active:scale-95">
          <Plus size={16} /> Add Category
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Add New Category Form */}
        <div className="lg:col-span-4 bg-white p-6 rounded-xl border border-slate-200 shadow-sm h-fit space-y-4">
          <h3 className="font-bold text-slate-900 flex items-center gap-2">
            <Plus size={16} className="text-blue-600" /> New Category
          </h3>
          <div className="space-y-1.5">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Name</label>
            <input 
              type="text" 
              placeholder="e.g. Case Studies"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:ring-1 focus:ring-slate-900 outline-none transition-all"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Slug (Optional)</label>
            <input 
              type="text" 
              placeholder="case-studies"
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:ring-1 focus:ring-slate-900 outline-none transition-all"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Parent Category</label>
            <select className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:ring-1 focus:ring-slate-900 outline-none transition-all">
              <option>None</option>
              {categories.map(c => <option key={c}>{c}</option>)}
            </select>
          </div>
          <button className="w-full py-2.5 bg-slate-900 text-white rounded-lg text-sm font-bold shadow-sm hover:bg-slate-800 transition-all active:scale-95">
            Save Category
          </button>
        </div>

        {/* Categories List */}
        <div className="lg:col-span-8 bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden h-fit">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between gap-4 bg-slate-50/20">
            <div className="flex-1 max-w-sm relative">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input 
                type="text" 
                placeholder="Search categories..." 
                className="w-full pl-9 pr-4 py-2 bg-white border border-slate-200 rounded-lg text-sm text-slate-900 placeholder:text-slate-400 focus:ring-1 focus:ring-slate-900 outline-none transition-all shadow-sm font-medium"
              />
            </div>
          </div>
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 border-b border-slate-100 text-slate-500 font-bold uppercase tracking-widest text-[10px]">
              <tr>
                <th className="px-6 py-4">Name</th>
                <th className="px-6 py-4">Slug</th>
                <th className="px-6 py-4">Items</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {categories.map((cat, i) => (
                <tr key={cat} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <FolderOpen size={16} className="text-slate-300 group-hover:text-blue-600 transition-colors" />
                      <span className="font-bold text-slate-900">{cat}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 font-mono text-xs text-slate-400">{cat.toLowerCase().replace(/\s+/g, '-')}</td>
                  <td className="px-6 py-4">
                    <span className="px-2 py-0.5 bg-slate-100 rounded text-[10px] font-black text-slate-500">{Math.floor(Math.random() * 20) + 1}</span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button className="p-2 text-slate-400 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-all">
                      <MoreVertical size={16} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default CategoriesPage;
