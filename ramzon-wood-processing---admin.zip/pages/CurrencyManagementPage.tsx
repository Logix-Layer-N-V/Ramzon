
import React, { useState, useContext } from 'react';
import { 
  Globe2, 
  Plus, 
  Search, 
  TrendingUp, 
  Trash2, 
  MoreVertical, 
  Calendar,
  Save,
  CheckCircle2,
  X,
  History,
  ArrowUpDown
} from 'lucide-react';
import { LanguageContext } from '../App';

const CurrencyManagementPage: React.FC = () => {
  const { t, availableCurrencies, setAvailableCurrencies } = useContext(LanguageContext);
  const [activeTab, setActiveTab] = useState<'list' | 'tracking'>('tracking');
  const [showEntryForm, setShowEntryForm] = useState(false);
  const [showCurrencyForm, setShowCurrencyForm] = useState(false);

  // Daily tracking history - Each row is a date with multiple rates
  const [dailyRates, setDailyRates] = useState([
    { id: 'r1', date: '2024-03-15', usd: '38.45', srd: '1.00', eur: '41.80', usdt: '39.10' },
    { id: 'r2', date: '2024-03-14', usd: '38.52', srd: '1.00', eur: '41.95', usdt: '39.05' },
    { id: 'r3', date: '2024-03-13', usd: '38.40', srd: '1.00', eur: '41.75', usdt: '38.90' },
    { id: 'r4', date: '2024-03-12', usd: '38.35', srd: '1.00', eur: '41.60', usdt: '38.85' },
  ]);

  const [newEntry, setNewEntry] = useState({
    date: new Date().toISOString().split('T')[0],
    usd: '',
    srd: '1.00',
    eur: '',
    usdt: ''
  });

  const [newCurrency, setNewCurrency] = useState({
    code: '',
    name: '',
    symbol: '',
    status: 'Active'
  });

  const handleAddEntry = () => {
    if (!newEntry.usd || !newEntry.eur) return;
    const entry = {
      id: Math.random().toString(36).substr(2, 9),
      ...newEntry
    };
    setDailyRates([entry, ...dailyRates]);
    setShowEntryForm(false);
    setNewEntry({ date: new Date().toISOString().split('T')[0], usd: '', srd: '1.00', eur: '', usdt: '' });
  };

  const handleAddCurrency = () => {
    if (!newCurrency.code || !newCurrency.name) return;
    const currency = {
      id: Math.random().toString(36).substr(2, 9),
      ...newCurrency
    };
    setAvailableCurrencies([...availableCurrencies, currency]);
    setShowCurrencyForm(false);
    setNewCurrency({ code: '', name: '', symbol: '', status: 'Active' });
  };

  const removeCurrency = (id: string) => {
    setAvailableCurrencies(availableCurrencies.filter(c => c.id !== id));
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-500 pb-10">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight italic">Currency Control Center</h1>
          <p className="text-sm font-medium text-slate-500 italic">Centralized management for multi-currency operations and daily exchange logs</p>
        </div>
        <button 
          onClick={() => activeTab === 'tracking' ? setShowEntryForm(true) : setShowCurrencyForm(true)}
          className="bg-brand-primary text-white px-6 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest hover:opacity-90 transition-all flex items-center gap-2 shadow-xl active:scale-95"
        >
          <Plus size={16} /> {activeTab === 'tracking' ? 'New Daily Log' : 'Add Unit'}
        </button>
      </div>

      <div className="flex bg-white p-1.5 rounded-2xl border border-slate-200 shadow-sm w-fit">
        <button 
          onClick={() => setActiveTab('tracking')}
          className={`px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-[0.2em] transition-all flex items-center gap-3 ${activeTab === 'tracking' ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-400 hover:text-slate-900 hover:bg-slate-50'}`}
        >
          <TrendingUp size={14} /> Exchange Tracking
        </button>
        <button 
          onClick={() => setActiveTab('list')}
          className={`px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-[0.2em] transition-all flex items-center gap-3 ${activeTab === 'list' ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-400 hover:text-slate-900 hover:bg-slate-50'}`}
        >
          <Globe2 size={14} /> Available Units
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-9 space-y-6">
          <div className="bg-white rounded-[32px] border border-slate-200 shadow-sm overflow-hidden min-h-[500px]">
            {activeTab === 'tracking' ? (
              <>
                <div className="px-8 py-5 border-b border-slate-50 bg-slate-50/30 flex justify-between items-center">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-brand-primary">
                      <History size={16} />
                    </div>
                    <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest italic">Rate History Log</h3>
                  </div>
                  <div className="flex items-center gap-2 text-[10px] font-bold text-slate-400">
                    <Calendar size={14} /> March 2024 Report
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-sm">
                    <thead className="bg-slate-50 text-[10px] font-black uppercase tracking-[0.3em] text-slate-400 border-b border-slate-100">
                      <tr>
                        <th className="px-8 py-5">Datum / Update</th>
                        <th className="px-4 py-5 text-center">USD Rate</th>
                        <th className="px-4 py-5 text-center bg-slate-100/50">SRD (Base)</th>
                        <th className="px-4 py-5 text-center">EURO Rate</th>
                        <th className="px-4 py-5 text-center">USDT Rate</th>
                        <th className="px-8 py-5 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-50">
                      {dailyRates.map((row) => (
                        <tr key={row.id} className="hover:bg-slate-50 transition-colors group">
                          <td className="px-8 py-4">
                            <span className="font-bold text-slate-400 tracking-tighter">{row.date}</span>
                          </td>
                          <td className="px-4 py-4 text-center">
                            <span className="font-black text-slate-900 text-lg italic">{row.usd}</span>
                          </td>
                          <td className="px-4 py-4 text-center bg-slate-50/30 font-bold text-slate-400">
                            {row.srd}
                          </td>
                          <td className="px-4 py-4 text-center">
                            <span className="font-black text-brand-primary text-lg italic">{row.eur}</span>
                          </td>
                          <td className="px-4 py-4 text-center">
                            <span className="font-black text-orange-600 text-lg italic">{row.usdt}</span>
                          </td>
                          <td className="px-8 py-4 text-right">
                            <button className="p-2 text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all">
                              <Trash2 size={16} />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </>
            ) : (
              <>
                <div className="px-8 py-5 border-b border-slate-50 bg-slate-50/30 flex justify-between items-center">
                  <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest italic">Supported Billing Units</h3>
                  <button className="text-[10px] font-black text-brand-primary hover:underline uppercase tracking-widest">Global Standards</button>
                </div>
                <div className="p-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {availableCurrencies.map((c) => (
                    <div key={c.id} className="p-6 bg-slate-50 rounded-2xl border border-slate-100 flex items-center justify-between group hover:bg-white hover:shadow-lg transition-all">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-xl bg-white border border-slate-100 shadow-sm flex items-center justify-center text-xl font-black text-slate-900">
                          {c.symbol}
                        </div>
                        <div>
                          <p className="font-black text-slate-900 leading-tight">{c.code}</p>
                          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tight">{c.name}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 bg-emerald-50 text-emerald-600 text-[8px] font-black uppercase tracking-widest rounded border border-emerald-100">
                          {c.status}
                        </span>
                        <button 
                          onClick={() => removeCurrency(c.id)}
                          className="p-1.5 text-slate-300 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
        </div>

        <div className="lg:col-span-3 space-y-6">
          <div className="bg-slate-900 p-8 rounded-[32px] text-white shadow-2xl relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-32 h-32 bg-brand-accent/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-2xl group-hover:bg-brand-accent/20 transition-all duration-700"></div>
            <div className="relative z-10 flex flex-col gap-6">
              <h4 className="text-brand-accent text-[10px] font-black uppercase tracking-[0.3em]">Accounting Intelligence</h4>
              <p className="text-lg font-bold leading-tight italic">
                Consistent exchange tracking ensures all USD wood sales are accurately reported in SRD bank statements.
              </p>
              <div className="h-px bg-white/10"></div>
              <div className="flex items-center gap-3">
                <CheckCircle2 size={18} className="text-emerald-400" />
                <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Gateway Verified Logs</span>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-[32px] border border-slate-200 shadow-sm space-y-4 border-l-4 border-l-brand-primary">
            <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Multi-Column Tracker</h4>
            <p className="text-xs text-slate-500 leading-relaxed font-medium">
              We track up to 4 major exchange pairs per day to maintain absolute precision in your international receivables.
            </p>
          </div>
        </div>
      </div>

      {/* Daily Entry Modal */}
      {showEntryForm && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-8 animate-in fade-in duration-300">
          <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-md" onClick={() => setShowEntryForm(false)}></div>
          <div className="bg-white w-full max-w-xl rounded-[40px] shadow-2xl z-10 flex flex-col overflow-hidden animate-in zoom-in-95 duration-300 border border-slate-100">
            <div className="px-8 py-6 border-b border-slate-50 flex items-center justify-between shrink-0 bg-slate-50/30">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-brand-primary rounded-xl flex items-center justify-center text-white shadow-lg">
                  <ArrowUpDown size={20} />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 tracking-tight italic">Log Daily Rates</h3>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Custom Tracking Input</p>
                </div>
              </div>
              <button 
                onClick={() => setShowEntryForm(false)}
                className="p-2.5 hover:bg-white border border-transparent hover:border-slate-200 rounded-2xl text-slate-400 hover:text-slate-950 transition-all shadow-sm"
              >
                <X size={20} />
              </button>
            </div>
            <div className="p-8 space-y-6">
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Update Datum</label>
                <input 
                  type="date" 
                  value={newEntry.date}
                  onChange={(e) => setNewEntry({...newEntry, date: e.target.value})}
                  className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-black focus:ring-2 focus:ring-brand-accent-light outline-none transition-all shadow-inner"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-blue-600 uppercase tracking-widest flex items-center gap-2">
                    <span className="w-1 h-1 bg-blue-600 rounded-full"></span> USD Rate
                  </label>
                  <input 
                    type="number" step="0.01" placeholder="0.00"
                    value={newEntry.usd}
                    onChange={(e) => setNewEntry({...newEntry, usd: e.target.value})}
                    className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-lg font-black outline-none focus:bg-white transition-all shadow-sm"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">SRD (Static)</label>
                  <input readOnly value="1.00" className="w-full px-5 py-3.5 bg-slate-100 border border-slate-200 rounded-2xl text-lg font-black outline-none cursor-not-allowed opacity-50" />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-emerald-600 uppercase tracking-widest flex items-center gap-2">
                    <span className="w-1 h-1 bg-emerald-600 rounded-full"></span> EURO Rate
                  </label>
                  <input 
                    type="number" step="0.01" placeholder="0.00"
                    value={newEntry.eur}
                    onChange={(e) => setNewEntry({...newEntry, eur: e.target.value})}
                    className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-lg font-black outline-none focus:bg-white transition-all shadow-sm"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-orange-600 uppercase tracking-widest flex items-center gap-2">
                    <span className="w-1 h-1 bg-orange-600 rounded-full"></span> USDT Rate
                  </label>
                  <input 
                    type="number" step="0.01" placeholder="0.00"
                    value={newEntry.usdt}
                    onChange={(e) => setNewEntry({...newEntry, usdt: e.target.value})}
                    className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-lg font-black outline-none focus:bg-white transition-all shadow-sm"
                  />
                </div>
              </div>

              <div className="pt-4 flex gap-3">
                <button 
                  onClick={() => setShowEntryForm(false)}
                  className="flex-1 py-4 border border-slate-200 text-slate-500 rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-slate-50 active:scale-95 transition-all"
                >
                  Discard
                </button>
                <button 
                  onClick={handleAddEntry}
                  className="flex-[2] py-4 bg-slate-900 text-white rounded-2xl text-xs font-black uppercase tracking-widest shadow-2xl shadow-slate-200 hover:bg-slate-800 active:scale-95 transition-all flex items-center justify-center gap-2"
                >
                  <Save size={18} /> Record Log Entry
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Currency Modal */}
      {showCurrencyForm && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-8 animate-in fade-in duration-300">
          <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-md" onClick={() => setShowCurrencyForm(false)}></div>
          <div className="bg-white w-full max-w-md rounded-[40px] shadow-2xl z-10 flex flex-col overflow-hidden animate-in zoom-in-95 duration-300 border border-slate-100">
            <div className="px-8 py-6 border-b border-slate-50 flex items-center justify-between shrink-0 bg-slate-50/30">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-brand-primary rounded-xl flex items-center justify-center text-white shadow-lg">
                  <Globe2 size={20} />
                </div>
                <h3 className="font-black text-slate-900 tracking-tight italic">Register Unit</h3>
              </div>
              <button onClick={() => setShowCurrencyForm(false)} className="p-2.5 hover:bg-white border border-transparent hover:border-slate-200 rounded-2xl text-slate-400 hover:text-slate-950">
                <X size={20} />
              </button>
            </div>
            <div className="p-8 space-y-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">ISO Code</label>
                <input 
                  type="text" placeholder="e.g. GBP"
                  value={newCurrency.code}
                  onChange={(e) => setNewCurrency({...newCurrency, code: e.target.value.toUpperCase()})}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold outline-none"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Name</label>
                <input 
                  type="text" placeholder="e.g. Pound Sterling"
                  value={newCurrency.name}
                  onChange={(e) => setNewCurrency({...newCurrency, name: e.target.value})}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold outline-none"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Symbol</label>
                <input 
                  type="text" placeholder="e.g. £"
                  value={newCurrency.symbol}
                  onChange={(e) => setNewCurrency({...newCurrency, symbol: e.target.value})}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold outline-none"
                />
              </div>
              <button 
                onClick={handleAddCurrency}
                className="w-full py-4 bg-slate-900 text-white rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-slate-800 transition-all mt-4"
              >
                Save Currency Unit
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CurrencyManagementPage;
