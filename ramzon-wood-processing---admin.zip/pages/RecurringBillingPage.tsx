
import React, { useContext } from 'react';
import { RefreshCw, Plus, Calendar, ArrowRight, TrendingUp, ShieldCheck } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { LanguageContext } from '../App';

const RecurringBillingPage: React.FC = () => {
  const { t } = useContext(LanguageContext);
  const navigate = useNavigate();

  const activeSubscriptions = [
    { id: 'sub1', client: 'Build-It Ltd', plan: 'Quarterly Teak Delivery', amount: 4500, nextDate: '2024-06-01', frequency: 'Every 3 Months' },
    { id: 'sub2', client: 'Sarah Miller', plan: 'Monthly Maintenance Fee', amount: 150, nextDate: '2024-04-15', frequency: 'Monthly' },
  ];

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-500 pb-10">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">{t('recurring')}</h1>
          <p className="text-sm font-medium text-slate-500 italic">Manage scheduled timber supplies and monthly retainers</p>
        </div>
        <button className="bg-emerald-600 text-white px-5 py-2.5 rounded-xl text-sm font-black hover:bg-emerald-700 transition-all flex items-center gap-2 shadow-xl active:scale-95">
          <Plus size={18} /> Create Plan
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-slate-900 p-8 rounded-[32px] text-white shadow-2xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-2xl"></div>
          <div className="relative z-10 flex items-start gap-5">
            <div className="p-3 bg-emerald-500 rounded-2xl shadow-lg">
                <TrendingUp size={24} />
            </div>
            <div>
                <p className="text-emerald-400 text-[10px] font-black uppercase tracking-[0.2em] mb-1">Projected MRR</p>
                <h4 className="text-3xl font-black text-white italic">€4,650.00</h4>
                <p className="text-slate-400 text-[10px] font-bold mt-2">Guaranteed monthly timber volume: 12.4m³</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-8 rounded-[32px] border border-slate-200 shadow-sm flex items-center justify-between">
            <div className="space-y-2">
                <p className="text-slate-400 text-[10px] font-black uppercase tracking-[0.2em]">Active Contracts</p>
                <h4 className="text-4xl font-black text-slate-900">12</h4>
                <div className="flex items-center gap-2 text-emerald-600 font-bold text-[10px]">
                    <ShieldCheck size={12} /> 100% SUCCESS RATE
                </div>
            </div>
            <RefreshCw size={48} className="text-slate-100 rotate-12" />
        </div>
      </div>

      <div className="bg-white rounded-[40px] border border-slate-200 shadow-sm overflow-hidden">
        <div className="px-8 py-6 border-b border-slate-50 flex justify-between items-center bg-slate-50/20">
          <h3 className="text-sm font-black uppercase tracking-widest text-slate-900">Active Billing Cycles</h3>
          <span className="text-[10px] font-bold text-slate-400 italic">2 automated processes active</span>
        </div>

        <div className="divide-y divide-slate-100">
          {activeSubscriptions.map((sub) => (
            <div 
              key={sub.id} 
              onClick={() => navigate(`/recurring/${sub.id}`)}
              className="p-8 flex flex-col md:flex-row md:items-center justify-between gap-6 hover:bg-slate-50/50 transition-colors cursor-pointer group"
            >
              <div className="flex items-center gap-6">
                <div className="w-14 h-14 bg-slate-100 rounded-[22px] flex items-center justify-center text-slate-400 group-hover:bg-emerald-50 transition-colors">
                  <Calendar size={24} />
                </div>
                <div>
                  <h4 className="text-lg font-black text-slate-900 leading-tight">{sub.client}</h4>
                  <p className="text-xs font-bold text-emerald-600 uppercase tracking-widest mt-0.5">{sub.plan}</p>
                  <p className="text-[10px] text-slate-400 font-bold italic mt-1">Cycle: {sub.frequency}</p>
                </div>
              </div>

              <div className="flex items-center gap-12 text-right">
                <div className="space-y-1">
                  <p className="text-xl font-black text-slate-900 italic">€{sub.amount.toLocaleString()}</p>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Next: {sub.nextDate}</p>
                </div>
                <div className="p-3 bg-white border border-slate-200 rounded-2xl group-hover:border-slate-900 group-hover:bg-slate-900 group-hover:text-white transition-all shadow-sm">
                  <ArrowRight size={20} />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default RecurringBillingPage;
