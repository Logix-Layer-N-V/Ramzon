
import React from 'react';
/* Added missing DollarSign icon import */
import { ArrowLeft, Package, Plus, Save, Ruler, Box, DollarSign } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const CreateProductPage: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center justify-between">
        <button onClick={() => navigate('/products')} className="flex items-center gap-2 text-slate-500 hover:text-slate-900 font-bold">
          <ArrowLeft size={18} /> Back to Catalog
        </button>
        <button className="bg-amber-600 text-white px-8 py-2.5 rounded-xl font-black text-sm shadow-xl shadow-amber-100 flex items-center gap-2 active:scale-95 transition-all">
          <Save size={18} /> Register Wood
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2 bg-white p-8 rounded-[32px] border border-slate-200 shadow-sm space-y-8">
          <div className="flex items-center gap-4 border-b border-slate-50 pb-6">
            <div className="w-12 h-12 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center">
              <Package size={24} />
            </div>
            <h2 className="text-2xl font-black text-slate-900 tracking-tight">New Wood Species</h2>
          </div>

          <div className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Wood Name</label>
              <input type="text" placeholder="e.g. Premium Teak Planks" className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold focus:bg-white outline-none transition-all" />
            </div>
            <div className="grid grid-cols-2 gap-4">
               <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Houtsoort</label>
                  <select className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold">
                    <option>Teak</option>
                    <option>Mahonie</option>
                    <option>Eiken</option>
                    <option>Grenen</option>
                  </select>
               </div>
               <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Unit</label>
                  <select className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold">
                    <option>m³</option>
                    <option>m²</option>
                    <option>lm</option>
                    <option>pcs</option>
                  </select>
               </div>
            </div>
          </div>

          <div className="space-y-4 pt-6 border-t border-slate-50">
            <h3 className="text-xs font-black uppercase tracking-[0.2em] text-slate-400 flex items-center gap-2">
              <Ruler size={14} /> Standard Dimensions (mm)
            </h3>
            <div className="grid grid-cols-3 gap-4">
              <input type="number" placeholder="Thickness" className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold outline-none" />
              <input type="number" placeholder="Width" className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold outline-none" />
              <input type="number" placeholder="Length" className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold outline-none" />
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-slate-50 p-6 rounded-[32px] border border-slate-200 shadow-inner space-y-6">
            <h3 className="text-xs font-black uppercase tracking-[0.2em] text-slate-400">Pricing & Inventory</h3>
            <div className="space-y-4">
               <div className="space-y-1.5">
                 <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Price per Unit (€)</label>
                 <div className="relative">
                   <DollarSign size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-300" />
                   <input type="number" placeholder="0.00" className="w-full pl-10 pr-4 py-3 bg-white border border-slate-200 rounded-xl text-sm font-black outline-none" />
                 </div>
               </div>
               <div className="space-y-1.5">
                 <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Starting Stock</label>
                 <div className="relative">
                   <Box size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-300" />
                   <input type="number" placeholder="0" className="w-full pl-10 pr-4 py-3 bg-white border border-slate-200 rounded-xl text-sm font-black outline-none" />
                 </div>
               </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreateProductPage;
