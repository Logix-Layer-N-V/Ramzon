
import React, { useState } from 'react';
import { Search, Filter, MoreHorizontal, ExternalLink, Layout as LayoutIcon, Link as LinkIcon, X, Pencil, Trash2, Eye, ChevronLeft, ChevronRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { mockPosts } from '../lib/mock-data';
import PostEditor from '../components/PostEditor';
import { Post } from '../types';

interface PagesPageProps {
  viewMode: 'modal' | 'page';
}

const PagesPage: React.FC<PagesPageProps> = ({ viewMode }) => {
  const navigate = useNavigate();
  const [selectedPageId, setSelectedPageId] = useState<string | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [openDropdownId, setOpenDropdownId] = useState<string | null>(null);
  
  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  
  // Filter only 'Page' type from mock data
  const allPages = mockPosts.filter(p => p.type === 'Page');
  
  // Calculate displayed pages
  const totalPagesCount = Math.ceil(allPages.length / rowsPerPage);
  const indexOfLastRow = currentPage * rowsPerPage;
  const indexOfFirstRow = indexOfLastRow - rowsPerPage;
  const currentRows = allPages.slice(indexOfFirstRow, indexOfLastRow);

  const handleOpenDetail = (id: string) => {
    setOpenDropdownId(null);
    if (viewMode === 'page') {
      navigate(`/pages/${id}`);
    } else {
      setSelectedPageId(id);
    }
  };

  const handleCreateNew = () => {
    if (viewMode === 'page') {
      // In a real app, you'd navigate to /pages/new
      navigate('/pages/new'); 
    } else {
      setIsCreating(true);
    }
  };

  const emptyPage: Post = {
    id: 'new-' + Math.random().toString(36).substr(2, 9),
    title: '',
    type: 'Page',
    category: 'General',
    tags: [],
    seoScore: 0,
    status: 'Draft',
    author: 'Alex Andria',
    date: new Date().toISOString().split('T')[0]
  };

  const selectedPage = isCreating ? emptyPage : mockPosts.find(p => p.id === selectedPageId);

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-500 relative pb-10">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Pages</h1>
          <p className="text-slate-500 text-sm">Create and manage static website pages</p>
        </div>
        <button 
          onClick={handleCreateNew}
          className="bg-slate-900 text-white px-5 py-2.5 rounded-lg text-sm font-bold hover:bg-slate-800 transition-all flex items-center gap-2 shadow-sm active:scale-95"
        >
          Create New Page
        </button>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between gap-4 bg-slate-50/30">
          <div className="flex-1 max-w-sm relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search pages..." 
              className="w-full pl-9 pr-4 py-2 bg-white border border-slate-200 rounded-lg text-sm text-slate-900 placeholder:text-slate-400 focus:ring-1 focus:ring-slate-900 outline-none transition-all shadow-sm font-medium"
            />
          </div>
          <div className="flex items-center gap-2">
            <button className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-lg text-xs font-bold bg-white text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition-all shadow-sm">
              <Filter size={14} /> All Templates
            </button>
          </div>
        </div>

        <div className="w-full">
          <table className="w-full text-left text-sm border-collapse">
            <thead className="bg-slate-50 border-b border-slate-100 text-slate-500 font-bold uppercase tracking-widest text-[10px]">
              <tr>
                <th className="px-6 py-4">Page Title</th>
                <th className="px-6 py-4">Template</th>
                <th className="px-6 py-4">Category</th>
                <th className="px-6 py-4">Menu Status</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {currentRows.map((page) => (
                <tr 
                  key={page.id} 
                  className="hover:bg-slate-50/80 transition-colors group cursor-pointer relative"
                  onClick={() => handleOpenDetail(page.id)}
                >
                  <td className="px-6 py-4">
                    <div className="flex flex-col">
                      <span className="font-bold text-slate-900 group-hover:text-blue-600 transition-colors leading-tight">{page.title}</span>
                      <span className="text-[11px] text-slate-400 font-bold mt-0.5">Slug: /{page.title.toLowerCase().replace(/\s+/g, '-')}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2 text-slate-600 font-medium">
                      <LayoutIcon size={14} className="text-slate-400" />
                      {page.title === 'Home' ? 'Hero Layout' : 'Default Sidebar'}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-slate-600 font-bold">{page.category}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <LinkIcon size={14} className={page.status === 'Published' ? 'text-green-500' : 'text-slate-300'} />
                      <span className="text-xs font-semibold text-slate-500">{page.status === 'Published' ? 'Linked to Main' : 'Unlinked'}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                      page.status === 'Published' ? 'bg-green-50 text-green-700' : 'bg-slate-100 text-slate-500'
                    }`}>
                      {page.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right relative overflow-visible">
                    <div className="flex justify-end gap-1" onClick={(e) => e.stopPropagation()}>
                      <button 
                        onClick={() => navigate('/preview')}
                        className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"
                        title="View Live Page"
                      >
                        <ExternalLink size={16} />
                      </button>
                      <button 
                        onClick={() => handleOpenDetail(page.id)}
                        className="p-2 text-slate-400 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-all"
                        title="Edit Page"
                      >
                        <Pencil size={16} />
                      </button>
                      <div className="relative">
                        <button 
                          onClick={() => setOpenDropdownId(openDropdownId === page.id ? null : page.id)}
                          className={`p-2 rounded-lg transition-all ${openDropdownId === page.id ? 'bg-slate-900 text-white' : 'text-slate-400 hover:text-slate-900 hover:bg-slate-100'}`}
                        >
                          <MoreHorizontal size={16} />
                        </button>
                        
                        {openDropdownId === page.id && (
                          <>
                            <div className="fixed inset-0 z-20" onClick={() => setOpenDropdownId(null)}></div>
                            <div className="absolute right-0 mt-2 w-48 bg-white border border-slate-100 rounded-xl shadow-2xl z-30 py-2 text-left animate-in fade-in zoom-in-95 duration-200">
                              <button 
                                onClick={() => handleOpenDetail(page.id)}
                                className="w-full px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-900 hover:bg-slate-50 flex items-center gap-3 transition-colors"
                              >
                                <Eye size={14} className="text-slate-400" /> View / Edit Details
                              </button>
                              <button className="w-full px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-900 hover:bg-slate-50 flex items-center gap-3 transition-colors">
                                <LinkIcon size={14} className="text-slate-400" /> Copy Preview Link
                              </button>
                              <div className="my-1 border-t border-slate-50"></div>
                              <button className="w-full px-4 py-2 text-xs font-bold text-red-600 hover:bg-red-50 flex items-center gap-3 transition-colors">
                                <Trash2 size={14} /> Move to Trash
                              </button>
                            </div>
                          </>
                        )}
                      </div>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Improved Pagination Footer */}
        <div className="px-6 py-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4 bg-slate-50/10">
          <div className="flex items-center gap-4">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Show rows</span>
            <select 
              value={rowsPerPage} 
              onChange={(e) => {
                setRowsPerPage(parseInt(e.target.value));
                setCurrentPage(1);
              }}
              className="px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-bold text-slate-600 outline-none hover:border-slate-300 transition-colors shadow-sm"
            >
              {[10, 20, 50, 100, 200].map(val => (
                <option key={val} value={val}>{val}</option>
              ))}
            </select>
            <span className="text-xs font-bold text-slate-400 tracking-tight">
              Showing {indexOfFirstRow + 1} to {Math.min(indexOfLastRow, allPages.length)} of {allPages.length}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button 
              disabled={currentPage === 1}
              onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
              className="p-2 border border-slate-200 rounded-lg text-slate-400 hover:text-slate-900 disabled:opacity-30 disabled:hover:text-slate-400 transition-all shadow-sm bg-white"
            >
              <ChevronLeft size={16} />
            </button>
            <div className="flex gap-1">
              {Array.from({ length: totalPagesCount }).map((_, i) => (
                <button
                  key={i + 1}
                  onClick={() => setCurrentPage(i + 1)}
                  className={`w-8 h-8 rounded-lg text-xs font-bold transition-all ${
                    currentPage === i + 1 
                      ? 'bg-slate-900 text-white shadow-md' 
                      : 'text-slate-600 hover:bg-slate-100 border border-transparent'
                  }`}
                >
                  {i + 1}
                </button>
              ))}
            </div>
            <button 
              disabled={currentPage === totalPagesCount}
              onClick={() => setCurrentPage(prev => Math.min(totalPagesCount, prev + 1))}
              className="p-2 border border-slate-200 rounded-lg text-slate-400 hover:text-slate-900 disabled:opacity-30 disabled:hover:text-slate-400 transition-all shadow-sm bg-white"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>
      </div>

      {/* Modal for detail view */}
      {selectedPage && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 md:p-8 animate-in fade-in duration-300">
          <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" onClick={() => { setSelectedPageId(null); setIsCreating(false); }}></div>
          <div className="bg-white w-full max-w-7xl h-[95vh] rounded-2xl shadow-2xl z-10 flex flex-col overflow-hidden animate-in zoom-in-95 duration-300">
            <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between shrink-0">
              <h3 className="font-bold text-slate-900 flex items-center gap-2">
                <LayoutIcon size={18} className="text-blue-600" />
                {isCreating ? 'Create New Page' : `Edit Page: ${selectedPage.title}`}
              </h3>
              <button 
                onClick={() => { setSelectedPageId(null); setIsCreating(false); }}
                className="p-2 hover:bg-slate-100 rounded-full transition-colors"
              >
                <X size={20} />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-6 bg-slate-50/30 no-scrollbar">
              <PostEditor post={selectedPage} onClose={() => { setSelectedPageId(null); setIsCreating(false); }} />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PagesPage;
