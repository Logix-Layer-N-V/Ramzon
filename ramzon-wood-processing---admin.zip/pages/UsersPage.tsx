
import React, { useState } from 'react';
import { Search, UserPlus, MoreVertical, Shield, User as UserIcon, Mail, Calendar, CheckCircle2, XCircle } from 'lucide-react';
import { mockUsers } from '../lib/mock-data';
import { User } from '../types';

const UsersPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'list' | 'roles'>('list');
  const [activeMenu, setActiveMenu] = useState<string | null>(null);

  const toggleUserMenu = (id: string) => {
    setActiveMenu(activeMenu === id ? null : id);
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">User Management</h1>
          <p className="text-slate-500">Manage team members and their access levels</p>
        </div>
        <button className="bg-slate-900 text-white px-5 py-2.5 rounded-xl text-sm font-bold hover:bg-slate-800 transition-all flex items-center gap-2 shadow-lg shadow-slate-200 active:scale-95">
          <UserPlus size={16} /> Add User
        </button>
      </div>

      <div className="flex border-b border-slate-200">
        <button 
          onClick={() => setActiveTab('list')}
          className={`px-6 py-3 text-sm font-bold transition-all border-b-2 ${activeTab === 'list' ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-400 hover:text-slate-600'}`}
        >
          User List
        </button>
        <button 
          onClick={() => setActiveTab('roles')}
          className={`px-6 py-3 text-sm font-bold transition-all border-b-2 ${activeTab === 'roles' ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-400 hover:text-slate-600'}`}
        >
          Roles & Permissions
        </button>
      </div>

      {activeTab === 'list' ? (
        <div className="bg-white rounded-[24px] border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/30">
            <div className="relative w-full max-w-sm">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input 
                type="text" 
                placeholder="Search by name or email..." 
                className="w-full pl-9 pr-4 py-2 bg-white border border-slate-300 rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:ring-2 focus:ring-blue-600 outline-none transition-all shadow-sm font-medium"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 border-b border-slate-100 text-slate-400 font-bold uppercase tracking-widest text-[10px]">
                <tr>
                  <th className="px-6 py-4">User</th>
                  <th className="px-6 py-4">Role</th>
                  <th className="px-6 py-4">Joined Date</th>
                  <th className="px-6 py-4">Status</th>
                  <th className="px-6 py-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {mockUsers.map((user) => (
                  <tr key={user.id} className="hover:bg-slate-50/50 transition-colors group">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-4">
                        <img src={user.avatar} className="w-10 h-10 rounded-2xl object-cover border border-slate-200 shadow-sm group-hover:scale-105 transition-transform" alt={user.name} />
                        <div className="flex flex-col">
                          <span className="font-bold text-slate-900 leading-tight group-hover:text-blue-600 transition-colors">{user.name}</span>
                          <span className="text-[11px] text-slate-400 font-bold mt-0.5">{user.email}</span>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <Shield size={14} className="text-blue-500" />
                        <span className="font-bold text-slate-700 tracking-tight">{user.role}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-slate-500 font-bold tracking-tighter">{user.joinedDate}</td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                        user.status === 'Active' 
                          ? 'bg-green-100 text-green-700' 
                          : 'bg-slate-100 text-slate-500'
                      }`}>
                        {user.status === 'Active' ? <CheckCircle2 size={10} /> : <XCircle size={10} />}
                        {user.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right relative">
                      <button 
                        onClick={() => toggleUserMenu(user.id)}
                        className="p-2.5 hover:bg-white border border-transparent hover:border-slate-200 rounded-xl text-slate-400 hover:text-slate-900 transition-all shadow-sm"
                      >
                        <MoreVertical size={18} />
                      </button>
                      
                      {activeMenu === user.id && (
                        <>
                          <div className="fixed inset-0 z-20" onClick={() => setActiveMenu(null)}></div>
                          <div className="absolute right-6 top-14 w-52 bg-white border border-slate-100 rounded-[20px] shadow-2xl z-30 py-2 text-left animate-in fade-in zoom-in-95 duration-200">
                            <button className="w-full px-4 py-2 text-[11px] font-black uppercase tracking-wider text-slate-600 hover:text-slate-900 hover:bg-slate-50 flex items-center gap-3 transition-colors">
                              <UserIcon size={14} className="text-slate-400" /> View Profile
                            </button>
                            <button className="w-full px-4 py-2 text-[11px] font-black uppercase tracking-wider text-slate-600 hover:text-slate-900 hover:bg-slate-50 flex items-center gap-3 transition-colors">
                              <Shield size={14} className="text-slate-400" /> Change Role
                            </button>
                            <button className="w-full px-4 py-2 text-[11px] font-black uppercase tracking-wider text-slate-600 hover:text-slate-900 hover:bg-slate-50 flex items-center gap-3 transition-colors">
                              <Mail size={14} className="text-slate-400" /> Email User
                            </button>
                            <div className="my-1.5 border-t border-slate-100 mx-2"></div>
                            <button className="w-full px-4 py-2 text-[11px] font-black uppercase tracking-wider text-red-600 hover:bg-red-50 flex items-center gap-3 transition-colors">
                              Deactivate
                            </button>
                          </div>
                        </>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { role: 'Admin', desc: 'Full access to all settings and content management.', users: 1 },
            { role: 'Editor', desc: 'Can publish and manage posts including those of other users.', users: 2 },
            { role: 'Viewer', desc: 'Can only view posts and dashboard metrics.', users: 1 },
          ].map((r) => (
            <div key={r.role} className="bg-white p-8 rounded-[32px] border border-slate-200 shadow-sm hover:border-blue-200 hover:shadow-xl hover:-translate-y-1 transition-all group">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center shadow-inner group-hover:scale-110 transition-transform">
                  <Shield size={24} />
                </div>
                <h3 className="font-black text-lg text-slate-900 tracking-tight">{r.role}</h3>
              </div>
              <p className="text-sm text-slate-500 mb-8 leading-relaxed font-medium">{r.desc}</p>
              <div className="flex items-center justify-between mt-auto pt-6 border-t border-slate-50">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">{r.users} MEMBER{r.users > 1 ? 'S' : ''}</span>
                <button className="text-xs font-black text-blue-600 hover:text-blue-700 hover:underline tracking-tight">Manage</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default UsersPage;
