
import React, { useState, useEffect } from 'react';
import { ArrowLeft, Save, Plus, Trash2, Receipt, Users, Ruler, Package, DollarSign, Calculator, Send, Check, Sparkles } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import { mockClients, mockWoodProducts } from '../lib/mock-data';
import { Estimate } from '../types';

const CreateInvoicePage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  
  const [selectedClient, setSelectedClient] = useState('');
  const [items, setItems] = useState([{ id: '1', woodType: '', thickness: 0, width: 0, length: 0, qty: 1, unit: 'm³' as any, price: 0 }]);
  const [saved, setSaved] = useState(false);
  const [isConverted, setIsConverted] = useState(false);

  // Check of we data van een estimate hebben gekregen
  useEffect(() => {
    const state = location.state as { fromEstimate?: Estimate };
    if (state?.fromEstimate) {
      const est = state.fromEstimate;
      setSelectedClient(est.clientId);
      setIsConverted(true);
      // Map de estimate items naar factuur items
      if (est.items && est.items.length > 0) {
        setItems(est.items.map(i => ({
          id: i.id,
          woodType: i.description,
          thickness: 0, width: 0, length: 0,
          qty: i.quantity,
          unit: 'pcs',
          price: i.unitPrice
        })));
      }
    }
  }, [location.state]);

  const addItem = () => {
    setItems([...items, { id: Math.random().toString(), woodType: '', thickness: 0, width: 0, length: 0, qty: 1, unit: 'm³', price: 0 }]);
  };

  const removeItem = (id: string) => {
    setItems(items.filter(item => item.id !== id));
  };

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => navigate('/invoices'), 1500);
  };

  const subtotal = items.reduce((acc, item) => acc + (item.price * item.qty), 0);
  const tax = subtotal * 0.21;
  const total = subtotal + tax;

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20">
      <div className="flex items-center justify-between">
        <button onClick={() => navigate('/invoices')} className="flex items-center gap-2 text-slate-500 hover:text-slate-900 font-bold transition-all">
          <ArrowLeft size={18} /> Terug naar Facturen
        </button>
        <div className="flex gap-2">
          <button onClick={handleSave} className="bg-emerald-600 text-white px-8 py-2.5 rounded-xl font-black text-sm shadow-xl shadow-emerald-100 flex items-center gap-2 active:scale-95 transition-all">
            {saved ? <Check size={18} /> : <Save size={18} />}
            {saved ? 'Verwerken...' : 'Factuur Definitief Maken'}
          </button>
        </div>
      </div>

      {isConverted && (
        <div className="bg-brand-accent-light border border-brand-accent/30 p-4 rounded-2xl flex items-center gap-4 animate-bounce">
          <Sparkles className="text-brand-accent shrink-0" size={24} />
          <p className="text-xs font-black text-brand-primary uppercase tracking-widest">
            Data succesvol overgenomen van Offerte {(location.state as any)?.fromEstimate?.estimateNumber}
          </p>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-8 space-y-6">
          <div className="bg-white p-8 rounded-[32px] border border-slate-200 shadow-sm space-y-8">
            <div className="flex items-center gap-4 border-b border-slate-50 pb-6">
              <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center">
                <Receipt size={24} />
              </div>
              <h2 className="text-2xl font-black text-slate-900 tracking-tight">Nieuwe Factuur</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                  <Users size={12} /> Selecteer Klant
                </label>
                <select 
                  value={selectedClient}
                  onChange={(e) => setSelectedClient(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold focus:ring-2 focus:ring-emerald-100 outline-none transition-all appearance-none"
                >
                  <option value="">-- Kies een Klant --</option>
                  {mockClients.map(c => <option key={c.id} value={c.id}>{c.company} ({c.name})</option>)}
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                  Factuurdatum
                </label>
                <input type="date" defaultValue={new Date().toISOString().split('T')[0]} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold" />
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Producten & Diensten</h3>
                <button onClick={addItem} className="text-emerald-600 text-xs font-black flex items-center gap-1 hover:underline">
                  <Plus size={14} /> Voeg Regel Toe
                </button>
              </div>

              <div className="space-y-3">
                {items.map((item, idx) => (
                  <div key={item.id} className="p-4 bg-slate-50/50 rounded-2xl border border-slate-100 flex flex-wrap lg:flex-nowrap items-end gap-3 animate-in slide-in-from-top-2 duration-300">
                    <div className="flex-1 min-w-[150px] space-y-1.5">
                      <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Omschrijving</label>
                      <input 
                        type="text" 
                        value={item.woodType}
                        onChange={(e) => {
                          const n = [...items]; n[idx].woodType = e.target.value; setItems(n);
                        }}
                        placeholder="Bijv. Teak Planken" 
                        className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs font-bold outline-none" 
                      />
                    </div>
                    <div className="w-16 space-y-1.5">
                      <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Aantal</label>
                      <input type="number" value={item.qty} onChange={(e) => {
                        const n = [...items]; n[idx].qty = parseFloat(e.target.value) || 0; setItems(n);
                      }} className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs font-bold outline-none" />
                    </div>
                    <div className="w-28 space-y-1.5">
                      <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Prijs p.st. (€)</label>
                      <input type="number" value={item.price} onChange={(e) => {
                        const n = [...items]; n[idx].price = parseFloat(e.target.value) || 0; setItems(n);
                      }} className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs font-bold outline-none" />
                    </div>
                    <button onClick={() => removeItem(item.id)} className="p-2 text-slate-300 hover:text-red-600 transition-colors">
                      <Trash2 size={16} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="lg:col-span-4 space-y-6">
          <div className="bg-slate-900 p-8 rounded-[32px] text-white shadow-2xl space-y-8 sticky top-24">
            <h3 className="text-xs font-black uppercase tracking-[0.2em] text-emerald-400">Overzicht</h3>
            
            <div className="space-y-4 pt-4">
              <div className="flex justify-between items-center text-sm font-bold opacity-60">
                <span>Subtotaal</span>
                <span>€{subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center text-sm font-bold opacity-60">
                <span>BTW (21%)</span>
                <span>€{tax.toFixed(2)}</span>
              </div>
              <div className="h-px bg-white/10 my-4"></div>
              <div className="flex justify-between items-center">
                <span className="text-lg font-black italic">Totaalbedrag</span>
                <span className="text-3xl font-black text-emerald-400">€{total.toFixed(2)}</span>
              </div>
            </div>

            <div className="space-y-3 pt-8">
              <button className="w-full py-3 bg-white text-slate-900 rounded-xl text-xs font-black uppercase tracking-widest shadow-xl hover:bg-emerald-50 transition-all flex items-center justify-center gap-2">
                <Send size={14} /> Verzend via E-mail
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreateInvoicePage;
