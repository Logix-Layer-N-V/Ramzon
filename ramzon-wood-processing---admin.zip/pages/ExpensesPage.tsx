
import React from 'react';
import { Search, Plus, Wallet, ShoppingCart, Truck, CreditCard, Filter } from 'lucide-react';
import { mockExpenses } from '../lib/mock-data';
import { useNavigate } from 'react-router-dom';

const ExpensesPage: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-500">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">Expenses</h1>
          <p className="text-sm font-medium text-slate-500 italic">Track overhead, logistics and inventory costs</p>
        </div>
        <button 
          onClick={() => navigate('/expenses/new')}
          className="bg-red-600 text-white px-5 py-2.5 rounded-xl text-sm font-black hover:bg-red-700 transition-all flex items-center gap-2 shadow-xl shadow-red-100 active:scale-95"
        >
          <Plus size={18} /> Add Expense
        </button>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-100 bg-slate-50/20 flex items-center justify-between gap-4">
          <div className="flex-1 max-w-sm relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search costs..." 
              className="w-full pl-9 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold outline-none"
            />
          </div>
          <button className="px-4 py-2 bg-white border border-slate-200 rounded-xl text-[10px] font-black uppercase tracking-widest text-slate-500">Last 30 Days</button>
        </div>

        <div className="divide-y divide-slate-100">
          {mockExpenses.map((ex) => (
            <div 
              key={ex.id} 
              onClick={() => navigate(`/expenses/${ex.id}`)}
              className="px-8 py-4 flex items-center justify-between hover:bg-slate-50/50 transition-colors cursor-pointer group"
            >
              <div className="flex items-center gap-4">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-transform group-hover:scale-110 ${
                  ex.category === 'Logistics' ? 'bg-blue-50 text-blue-600' : 'bg-orange-50 text-orange-600'
                }`}>
                  {ex.category === 'Logistics' ? <Truck size={20} /> : <ShoppingCart size={20} />}
                </div>
                <div>
                  <p className="text-sm font-black text-slate-900">{ex.description}</p>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{ex.category} • {ex.date}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-black text-slate-900">€{ex.amount.toLocaleString()}</p>
                <span className={`text-[8px] font-black uppercase tracking-widest ${
                  ex.status === 'Paid' ? 'text-emerald-600' : 'text-red-500'
                }`}>{ex.status}</span>
              </div>
            </div>
          ))}
        </div>
        
        <div className="p-6 bg-slate-50/50 border-t border-slate-100 flex justify-between items-center">
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Total Outgoing</p>
          <p className="text-xl font-black text-slate-900 italic">€12,450</p>
        </div>
      </div>
    </div>
  );
};

export default ExpensesPage;
