
import React from 'react';
import { Users, MousePointer2, Globe, Smartphone, ArrowUpRight, ArrowDownRight, MoreHorizontal } from 'lucide-react';

const TrafficInsightsPage: React.FC = () => {
  const topCountries = [
    { name: 'Netherlands', sessions: '12,450', trend: '+12%', flag: '🇳🇱' },
    { name: 'United States', sessions: '8,320', trend: '+5%', flag: '🇺🇸' },
    { name: 'Germany', sessions: '4,100', trend: '-2%', flag: '🇩🇪' },
    { name: 'United Kingdom', sessions: '3,850', trend: '+8%', flag: '🇬🇧' },
  ];

  const topPages = [
    { path: '/', views: '24,500', time: '1m 24s' },
    { path: '/products', views: '12,300', time: '2m 10s' },
    { path: '/blog/modern-cms', views: '8,450', time: '4m 15s' },
    { path: '/pricing', views: '5,200', time: '0m 45s' },
  ];

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Traffic Insights</h1>
          <p className="text-slate-500">Understand visitor behavior and demographic trends</p>
        </div>
        <div className="flex gap-2">
          <select className="bg-white border border-slate-200 text-xs font-bold p-2.5 rounded-xl shadow-sm outline-none">
            <option>Last 30 Days</option>
            <option>Last 7 Days</option>
            <option>Today</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
          <div className="flex justify-between items-center mb-4">
            <div className="p-2 bg-blue-50 text-blue-600 rounded-xl">
              <Users size={20} />
            </div>
            <span className="text-xs font-bold text-green-600 flex items-center gap-1">
              +14% <ArrowUpRight size={14} />
            </span>
          </div>
          <p className="text-3xl font-black text-slate-900">42.8k</p>
          <p className="text-sm font-bold text-slate-500">Unique Visitors</p>
        </div>
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
          <div className="flex justify-between items-center mb-4">
            <div className="p-2 bg-purple-50 text-purple-600 rounded-xl">
              <MousePointer2 size={20} />
            </div>
            <span className="text-xs font-bold text-green-600 flex items-center gap-1">
              +8.2% <ArrowUpRight size={14} />
            </span>
          </div>
          <p className="text-3xl font-black text-slate-900">124k</p>
          <p className="text-sm font-bold text-slate-500">Total Clicks</p>
        </div>
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
          <div className="flex justify-between items-center mb-4">
            <div className="p-2 bg-orange-50 text-orange-600 rounded-xl">
              <Globe size={20} />
            </div>
            <span className="text-xs font-bold text-red-600 flex items-center gap-1">
              -2.1% <ArrowDownRight size={14} />
            </span>
          </div>
          <p className="text-3xl font-black text-slate-900">1.8m</p>
          <p className="text-sm font-bold text-slate-500">Avg. Session Duration</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Visitors Chart Simulation */}
        <div className="bg-white p-8 rounded-[32px] border border-slate-200 shadow-sm">
          <h3 className="text-sm font-black uppercase tracking-widest text-slate-400 mb-8">Daily Visitors</h3>
          <div className="h-64 flex items-end justify-between gap-2">
            {Array.from({ length: 15 }).map((_, i) => (
              <div key={i} className="flex-1 flex flex-col gap-1 items-center h-full justify-end group">
                <div className="w-full bg-blue-100 rounded-t-lg transition-all group-hover:bg-blue-600" style={{ height: `${Math.random() * 60 + 20}%` }}></div>
                <div className="w-full bg-slate-100 rounded-b-lg" style={{ height: `${Math.random() * 15}%` }}></div>
              </div>
            ))}
          </div>
          <div className="flex justify-between mt-4 text-[10px] font-bold text-slate-400">
            <span>May 15</span>
            <span>May 30</span>
          </div>
        </div>

        {/* Demographics - Top Countries */}
        <div className="bg-white p-8 rounded-[32px] border border-slate-200 shadow-sm">
          <h3 className="text-sm font-black uppercase tracking-widest text-slate-400 mb-8">Top Demographics</h3>
          <div className="space-y-6">
            {topCountries.map((c) => (
              <div key={c.name} className="flex items-center gap-4">
                <span className="text-2xl">{c.flag}</span>
                <div className="flex-1">
                  <p className="text-sm font-black text-slate-900">{c.name}</p>
                  <div className="w-full h-1.5 bg-slate-100 rounded-full mt-1 overflow-hidden">
                    <div className="h-full bg-blue-600 rounded-full" style={{ width: `${Math.random() * 40 + 40}%` }}></div>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-black text-slate-900">{c.sessions}</p>
                  <p className={`text-[10px] font-bold ${c.trend.startsWith('+') ? 'text-green-600' : 'text-red-600'}`}>{c.trend}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-[32px] border border-slate-200 shadow-sm overflow-hidden">
        <div className="px-8 py-6 border-b border-slate-50 flex justify-between items-center">
          <h3 className="text-sm font-black uppercase tracking-widest text-slate-400">Popular Content</h3>
          <button className="text-xs font-bold text-blue-600">Download Report</button>
        </div>
        <table className="w-full text-left">
          <thead className="bg-slate-50 text-[10px] font-black uppercase tracking-widest text-slate-400">
            <tr>
              <th className="px-8 py-4">Page Path</th>
              <th className="px-8 py-4 text-center">Page Views</th>
              <th className="px-8 py-4 text-center">Avg. Time</th>
              <th className="px-8 py-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50 text-sm font-bold text-slate-700">
            {topPages.map((page) => (
              <tr key={page.path} className="hover:bg-slate-50 transition-colors">
                <td className="px-8 py-4 text-blue-600">{page.path}</td>
                <td className="px-8 py-4 text-center">{page.views}</td>
                <td className="px-8 py-4 text-center">{page.time}</td>
                <td className="px-8 py-4 text-right">
                  <button className="p-2 text-slate-400 hover:text-slate-900">
                    <MoreHorizontal size={18} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default TrafficInsightsPage;
