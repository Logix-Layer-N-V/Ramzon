
import React, { useContext, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  Printer, 
  Download, 
  Send, 
  Building, 
  Calendar, 
  CheckCircle2, 
  Receipt,
  ClipboardList,
  Wallet,
  CreditCard,
  MoreVertical,
  Clock,
  ExternalLink
} from 'lucide-react';
import { LanguageContext } from '../App';
import { mockInvoices, mockEstimates, mockPayments, mockCredits, mockClients, mockExpenses } from '../lib/mock-data';

interface DocumentDetailPageProps {
  type: 'invoices' | 'estimates' | 'payments' | 'credits' | 'recurring' | 'expenses' | 'reports';
}

const DocumentDetailPage: React.FC<DocumentDetailPageProps> = ({ type }) => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { companyName, companyLogo, companyAddress, companyEmail, companyPhone, companyWebsite, companyBTW, companyKKF } = useContext(LanguageContext);

  // Fetch standard data based on type
  const docData = useMemo(() => {
    switch (type) {
      case 'invoices': return mockInvoices.find(i => i.id === id);
      case 'estimates': return mockEstimates.find(e => e.id === id);
      case 'payments': return mockPayments.find(p => p.id === id);
      case 'credits': return mockCredits.find(c => c.id === id);
      case 'expenses': return mockExpenses.find(e => e.id === id);
      case 'recurring': return { 
        id: 'rec1', 
        clientName: 'Build-It Ltd', 
        date: '2024-03-01', 
        totalAmount: 4500, 
        status: 'Active', 
        plan: 'Quarterly Teak Delivery',
        items: [{ description: 'Quarterly Teak Supply Retainer', quantity: 1, unitPrice: 4500, amount: 4500 }]
      };
      case 'reports': return {
        id: 'rep1',
        date: new Date().toLocaleDateString(),
        title: 'Financial Performance Report',
        items: [
          { description: 'Total Revenue', quantity: 1, unitPrice: 142850, amount: 142850 },
          { description: 'Total Expenses', quantity: 1, unitPrice: 8400, amount: 8400 },
          { description: 'Net Profit', quantity: 1, unitPrice: 134450, amount: 134450 }
        ],
        totalAmount: 134450
      };
      default: return null;
    }
  }, [type, id]);

  const client = useMemo(() => {
    if (!docData) return null;
    const clientId = (docData as any).clientId;
    if (clientId) return mockClients.find(c => c.id === clientId);
    // Fallback for types without explicit clientId in mock
    if (type === 'recurring') return mockClients.find(c => c.company === 'Build-It Ltd');
    return null;
  }, [docData, type]);

  if (!docData) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] text-slate-400">
        <Receipt size={48} className="mb-4 opacity-20" />
        <h2 className="text-xl font-bold">Document niet gevonden</h2>
        <button onClick={() => navigate(-1)} className="mt-4 px-4 py-2 bg-slate-900 text-white rounded-xl font-bold text-sm">
          Terug
        </button>
      </div>
    );
  }

  const getDocTitle = () => {
    switch (type) {
      case 'invoices': return (docData as any).invoiceNumber;
      case 'estimates': return (docData as any).estimateNumber;
      case 'payments': return 'Betaalbewijs';
      case 'credits': return 'Creditnota';
      case 'expenses': return 'Uitgavebewijs';
      case 'recurring': return 'Recurring Plan';
      case 'reports': return (docData as any).title;
      default: return 'Document';
    }
  };

  const getDocIcon = () => {
    switch (type) {
      case 'invoices': return Receipt;
      case 'estimates': return ClipboardList;
      case 'payments': return Wallet;
      case 'expenses': return Wallet;
      case 'recurring': return Clock;
      default: return CreditCard;
    }
  };

  const Icon = getDocIcon();

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20">
      {/* Action Header */}
      <div className="flex items-center justify-between">
        <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-slate-500 hover:text-slate-900 font-bold text-xs uppercase tracking-widest transition-all">
          <ArrowLeft size={16} /> Terug naar overzicht
        </button>
        <div className="flex gap-3">
          <button className="p-3 bg-white border border-slate-200 rounded-xl text-slate-400 hover:text-slate-900 transition-all shadow-sm">
            <Printer size={18} />
          </button>
          <button className="p-3 bg-white border border-slate-200 rounded-xl text-slate-400 hover:text-slate-900 transition-all shadow-sm">
            <Download size={18} />
          </button>
          <button className="bg-brand-primary text-white px-6 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest shadow-xl hover:bg-slate-800 transition-all flex items-center gap-2 active:scale-95">
            <Send size={16} /> Verzend Kopie
          </button>
        </div>
      </div>

      {/* Main Document Body */}
      <div className="max-w-[850px] mx-auto bg-white border border-slate-900 shadow-2xl overflow-hidden p-8 space-y-6 font-sans text-slate-900">
        
        {/* Branding Header */}
        <div className="flex justify-between items-start">
          <div className="w-1/3">
            <div className="w-48 h-24 flex items-center justify-center overflow-hidden">
              {companyLogo ? (
                <img src={companyLogo} className="w-full h-full object-contain" alt="Ramzon Logo" />
              ) : (
                <div className="text-2xl font-black text-brand-primary italic">RAMZON N.V.</div>
              )}
            </div>
            <div className="mt-2 space-y-0.5 text-[9px] font-bold text-slate-900 uppercase">
              <p className="flex items-center gap-1"><span className="text-brand-primary">📍</span> {companyAddress}</p>
              <p className="flex items-center gap-1"><span className="text-brand-primary">📞</span> {companyPhone}</p>
              <p className="flex items-center gap-1"><span className="text-brand-primary">✉️</span> {companyEmail}</p>
            </div>
          </div>
          
          <div className="flex-1 text-center pt-4">
            <h1 className="text-6xl font-black text-slate-900 tracking-tighter italic" style={{ fontFamily: 'serif' }}>
              {type === 'invoices' ? 'Invoice' : 
               type === 'estimates' ? 'Estimate' : 
               type === 'payments' ? 'Payment' : 
               type === 'credits' ? 'Credit' : 
               type === 'expenses' ? 'Expense' : 
               type === 'recurring' ? 'Recurring' : 'Report'}
            </h1>
          </div>

          <div className="w-1/3">
            <div className="bg-slate-100 border border-slate-300 p-4 min-h-[120px] rounded-sm">
              <h3 className="text-xs font-black text-center mb-4 uppercase tracking-wider">
                {type === 'expenses' ? 'Vendor Information' : 
                 type === 'reports' ? 'Report Parameters' : 'Customer Information'}
              </h3>
              <div className="text-center space-y-1">
                {type === 'reports' ? (
                  <>
                    <p className="text-sm font-bold">Full Financial Audit</p>
                    <p className="text-xs text-slate-600">Period: Q1 2024</p>
                  </>
                ) : type === 'expenses' ? (
                  <>
                    <p className="text-sm font-bold">{(docData as any).category || 'General Vendor'}</p>
                    <p className="text-xs text-slate-600">{(docData as any).description}</p>
                  </>
                ) : (
                  <>
                    <p className="text-sm font-bold">{client?.company || client?.name || 'Dinesh Abhelak'}</p>
                    <p className="text-xs text-slate-600">{client?.phone || '+597 8594052'}</p>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Metadata Row */}
        <div className="border-y border-slate-900 grid grid-cols-6 divide-x divide-slate-900 text-center">
          <div className="py-1">
            <p className="text-[10px] font-bold border-b border-slate-200 mb-1">Date</p>
            <p className="text-xs font-bold">{(docData as any).date || '01-Sept-2021'}</p>
          </div>
          <div className="py-1">
            <p className="text-[10px] font-bold border-b border-slate-200 mb-1">{type.slice(0, -1).toUpperCase()} #</p>
            <p className="text-xs font-bold">{getDocTitle() || '166'}</p>
          </div>
          <div className="py-1">
            <p className="text-[10px] font-bold border-b border-slate-200 mb-1">Terms</p>
            <p className="text-xs font-bold">COD</p>
          </div>
          <div className="py-1 bg-slate-100">
            <p className="text-[10px] font-bold border-b border-slate-200 mb-1">Due Date</p>
            <p className="text-xs font-bold">{(docData as any).dueDate || (docData as any).date}</p>
          </div>
          <div className="py-1">
            <p className="text-[10px] font-bold border-b border-slate-200 mb-1">Rep</p>
            <p className="text-xs font-bold">SS</p>
          </div>
          <div className="py-1">
            <p className="text-[10px] font-bold border-b border-slate-200 mb-1">Project</p>
            <p className="text-xs font-bold">-</p>
          </div>
        </div>

        {/* Items Table */}
        <div className="border border-slate-900 min-h-[500px] flex flex-col">
          <table className="w-full text-left border-collapse">
            <thead className="border-b border-slate-900">
              <tr className="divide-x divide-slate-900 text-[11px] font-black uppercase">
                <th className="py-1 px-2 w-[40%]">Description</th>
                <th className="py-1 px-2 text-center w-[12%]">Measurem...</th>
                <th className="py-1 px-2 text-center w-[8%]">Qu...</th>
                <th className="py-1 px-2 text-center w-[8%]">U/M</th>
                <th className="py-1 px-2 text-center w-[12%]">Wood</th>
                <th className="py-1 px-2 text-right w-[10%]">Rate</th>
                <th className="py-1 px-2 text-right w-[10%]">Amount</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-transparent">
              {((docData as any).items || (type === 'expenses' ? [
                { description: (docData as any).description, measurement: '', quantity: 1, um: 'LOT', wood: '', rate: (docData as any).amount, amount: (docData as any).amount }
              ] : type === 'reports' ? [
                { description: 'Total Revenue', measurement: '', quantity: 1, um: 'EUR', wood: '', rate: 142850, amount: 142850 },
                { description: 'Total Expenses', measurement: '', quantity: 1, um: 'EUR', wood: '', rate: 8400, amount: 8400 }
              ] : [
                { description: 'Hout drogen', measurement: '', quantity: 3.75, um: 'CBM', wood: 'KOP-Kopi', rate: 80.00, amount: 300.00 },
                { description: 'Vloerhout her-schaven en profileren', measurement: '', quantity: 135, um: 'M²', wood: '', rate: 8.00, amount: 1080.00 }
              ])).map((item: any, idx: number) => (
                <tr key={idx} className="divide-x divide-slate-900 text-xs font-medium">
                  <td className="py-2 px-2">{item.description}</td>
                  <td className="py-2 px-2 text-center">{item.measurement || ''}</td>
                  <td className="py-2 px-2 text-center">{item.quantity}</td>
                  <td className="py-2 px-2 text-center">{item.um || 'PCS'}</td>
                  <td className="py-2 px-2 text-center">{item.wood || ''}</td>
                  <td className="py-2 px-2 text-right">{item.rate?.toFixed(2) || item.unitPrice?.toFixed(2)}</td>
                  <td className="py-2 px-2 text-right">{(item.amount || (item.quantity * item.unitPrice))?.toFixed(2)}</td>
                </tr>
              ))}
              {/* Vertical lines filler */}
              <tr className="flex-1 divide-x divide-slate-900 h-[400px]">
                <td className="border-none"></td>
                <td className="border-none"></td>
                <td className="border-none"></td>
                <td className="border-none"></td>
                <td className="border-none"></td>
                <td className="border-none"></td>
                <td className="border-none"></td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* BTW Line */}
        <div className="border border-slate-900 grid grid-cols-12 divide-x divide-slate-900">
          <div className="col-span-10 py-1 px-4 text-xs font-black text-center uppercase tracking-wider">
            BTW tnv RAMZON NV # {companyBTW || '2000012965'} (10.0%)
          </div>
          <div className="col-span-2 py-1 px-2 text-right text-xs font-bold">
            USD 0.00
          </div>
        </div>

        {/* Footer Section */}
        <div className="grid grid-cols-12 border border-slate-900 divide-x divide-slate-900">
          {/* Notes */}
          <div className="col-span-9 p-4 text-[9px] font-bold space-y-1 leading-tight">
            <p>1-Office Hours: mon-fri 08:00-12:00/13:00-17:00).</p>
            <p>2-Hakrinbank N.V SRD 20.633.15.56 II EURO 20.695.94.66 II US$ 20.802.82.73 SWIFT HAKRSRPA.</p>
            <p className="pl-2">For Banking transfers the transfercertificate is required.</p>
            <p className="pl-2">All bank and transfer costs are for the account of the buyer.</p>
            <p>3-All wood products exclude: supply, finishing, glass, locksmithing</p>
            <p>4-All measurements in MM II Size tolerances: ± 5mm</p>
            <p>5-Exceeding the stated delivery time, those not lend parties the right to terminate the contract,</p>
            <p className="pl-2">to refuse payment or otherwise fail to fulfill his / her obligations.</p>
            <p>6-We are not responsible for products that have not been collected within 30 days of completion.</p>
            <p>7-Open balances are to be paid in full immediately before the items are collected.</p>
            <p>8-No refund on cancellation, regardless of reason.</p>
            <p>9-The warranty is on the product.</p>
            <p>Not on any additional costs such as transportation and labor costs.</p>
            <p>Ask for the warranty condition.</p>
          </div>
          
          {/* Totals */}
          <div className="col-span-3 flex flex-col divide-y divide-slate-900">
            <div className="flex-1 p-3 flex justify-between items-center">
              <span className="text-xs font-black uppercase">Total</span>
              <span className="text-xs font-bold">USD {((docData as any).totalAmount || (docData as any).total || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
            </div>
            <div className="flex-1 p-3 flex justify-between items-center">
              <span className="text-xs font-black uppercase">Payments</span>
              <span className="text-xs font-bold">USD -272.00</span>
            </div>
            <div className="flex-1 p-3 flex justify-between items-center bg-slate-50">
              <span className="text-xs font-black uppercase">Balance</span>
              <span className="text-xs font-bold">USD {(((docData as any).totalAmount || (docData as any).total || 0) - 272).toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DocumentDetailPage;
