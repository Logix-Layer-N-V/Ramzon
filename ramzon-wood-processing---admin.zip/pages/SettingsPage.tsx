
import React, { useContext, useState, useRef } from 'react';
import { 
  Settings, 
  Layout, 
  Monitor, 
  Save, 
  Check, 
  Globe, 
  Languages, 
  Palette, 
  Paintbrush, 
  Building2, 
  UploadCloud, 
  Coins, 
  Info,
  DollarSign,
  MapPin,
  Phone,
  Mail,
  Link as LinkIcon,
  Hash,
  Percent,
  Plus,
  Trash2,
  X,
  Clock,
  Timer,
  CalendarDays,
  ChevronDown,
  Pencil,
  ArrowRight,
  ClipboardList,
  Receipt,
  Wallet,
  CreditCard
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { LanguageContext, TaxRate } from '../App';
import { Language } from '../lib/translations';

interface SettingsPageProps {
  viewMode: 'modal' | 'page';
  setViewMode: (mode: 'modal' | 'page') => void;
}

const SettingsPage: React.FC<SettingsPageProps> = ({ viewMode, setViewMode }) => {
  const navigate = useNavigate();
  const { 
    lang, setLang, t, theme: currentTheme, setTheme, 
    multiCurrency, setMultiCurrency, availableCurrencies,
    companyName, setCompanyName, companyLogo, setCompanyLogo,
    companyAddress, setCompanyAddress,
    companyPhone, setCompanyPhone,
    companyEmail, setCompanyEmail,
    companyWebsite, setCompanyWebsite,
    companyKKF, setCompanyKKF,
    companyBTW, setCompanyBTW,
    taxRates, setTaxRates
  } = useContext(LanguageContext);
  
  const [saved, setSaved] = useState(false);
  const [showTaxForm, setShowTaxForm] = useState(false);
  const [newTax, setNewTax] = useState({ name: '', percentage: 0 });
  const [editingTaxId, setEditingTaxId] = useState<string | null>(null);
  const [editTaxData, setEditTaxData] = useState({ name: '', percentage: 0 });

  // Date/Time Settings State
  const [timezone, setTimezone] = useState('Europe/Amsterdam');
  const [dateFormat, setDateFormat] = useState('DD-MM-YYYY');
  const [timeFormat, setTimeFormat] = useState('24h');
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setCompanyLogo(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const addTaxRate = () => {
    if (!newTax.name) return;
    const rate: TaxRate = {
      id: Math.random().toString(36).substr(2, 9),
      name: newTax.name,
      percentage: newTax.percentage,
      isDefault: taxRates.length === 0
    };
    setTaxRates([...taxRates, rate]);
    setNewTax({ name: '', percentage: 0 });
    setShowTaxForm(false);
  };

  const startEditing = (rate: TaxRate) => {
    setEditingTaxId(rate.id);
    setEditTaxData({ name: rate.name, percentage: rate.percentage });
  };

  const saveEdit = (id: string) => {
    setTaxRates(taxRates.map(tr => tr.id === id ? { ...tr, name: editTaxData.name, percentage: editTaxData.percentage } : tr));
    setEditingTaxId(null);
  };

  const removeTaxRate = (id: string) => {
    setTaxRates(taxRates.filter(t => t.id !== id));
  };

  const languageOptions: { id: Language; label: string; flag: string }[] = [
    { id: 'en', label: 'English', flag: '🇺🇸' },
    { id: 'nl', label: 'Nederlands', flag: '🇳🇱' },
    { id: 'es', label: 'Español', flag: '🇪🇸' },
    { id: 'fr', label: 'Français', flag: '🇫🇷' },
    { id: 'zh', label: '中文 (Chinese)', flag: '🇨🇳' }
  ];

  const themeOptions = [
    { id: 'default', label: 'Logix Lab Standard', colors: ['bg-blue-900', 'bg-lime-400'], tagline: 'Navy & Lime' },
    { id: 'emerald', label: t('emeraldTheme'), colors: ['bg-emerald-800', 'bg-emerald-200'], tagline: 'Trust & Nature' },
    { id: 'indigo', label: t('indigoTheme'), colors: ['bg-indigo-900', 'bg-indigo-400'], tagline: 'Modern Clean' }
  ];

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-500 pb-24">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-black tracking-tight text-slate-900 italic">{t('settings')}</h1>
          <p className="text-sm font-medium text-slate-500 italic">Beheer organisatieprofiel en systeemconfiguraties</p>
        </div>
        <button 
          onClick={handleSave}
          className="bg-slate-900 text-white px-8 py-3 rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-slate-800 transition-all flex items-center gap-2 shadow-2xl shadow-slate-200 active:scale-95"
        >
          {saved ? <Check size={18} /> : <Save size={18} />}
          {saved ? 'Settings Updated' : 'Wijzigingen Toepassen'}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-8 space-y-8">
          
          {/* Detailed Company Settings */}
          <div className="bg-white p-8 rounded-[40px] border border-slate-200 shadow-sm space-y-8 relative overflow-hidden">
            <div className="flex justify-between items-start">
              <h3 className="font-black text-xl text-slate-900 tracking-tight flex items-center gap-3 italic">
                <Building2 size={24} className="text-brand-primary" /> {t('companySettings')}
              </h3>
              <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 bg-slate-50 px-3 py-1.5 rounded-full border border-slate-100">Identity Profile</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
              <div className="md:col-span-4 space-y-4">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">{t('uploadLogo')}</label>
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="aspect-square w-full bg-slate-50 border-2 border-dashed border-slate-200 rounded-[32px] flex flex-col items-center justify-center cursor-pointer hover:bg-slate-100 hover:border-brand-primary transition-all group relative overflow-hidden shadow-inner"
                >
                  {companyLogo ? (
                    <img src={companyLogo} alt="Logo Preview" className="w-full h-full object-contain p-6" />
                  ) : (
                    <>
                      <UploadCloud size={40} className="text-slate-300 group-hover:text-brand-primary transition-colors mb-3" />
                      <span className="text-[10px] font-bold text-slate-400 text-center px-6">DRAG & DROP LOGO HERE</span>
                    </>
                  )}
                  <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleLogoChange} />
                </div>
                {companyLogo && (
                  <button onClick={(e) => { e.stopPropagation(); setCompanyLogo(null); }} className="w-full text-[10px] font-black text-red-500 hover:underline uppercase tracking-widest">Remove Artwork</button>
                )}
              </div>

              <div className="md:col-span-8 grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="md:col-span-2 space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{t('companyName')}</label>
                  <input 
                    type="text" 
                    value={companyName}
                    onChange={(e) => setCompanyName(e.target.value)}
                    className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-black focus:ring-4 focus:ring-brand-accent-light outline-none transition-all shadow-sm"
                  />
                </div>
                
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                    <MapPin size={12} /> {t('address')}
                  </label>
                  <input 
                    type="text" 
                    value={companyAddress}
                    onChange={(e) => setCompanyAddress(e.target.value)}
                    className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-bold outline-none shadow-sm"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                    <Phone size={12} /> {t('phone')}
                  </label>
                  <input 
                    type="text" 
                    value={companyPhone}
                    onChange={(e) => setCompanyPhone(e.target.value)}
                    className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-bold outline-none shadow-sm"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                    <Mail size={12} /> {t('email')}
                  </label>
                  <input 
                    type="email" 
                    value={companyEmail}
                    onChange={(e) => setCompanyEmail(e.target.value)}
                    className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-bold outline-none shadow-sm"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                    <LinkIcon size={12} /> {t('website')}
                  </label>
                  <input 
                    type="text" 
                    value={companyWebsite}
                    onChange={(e) => setCompanyWebsite(e.target.value)}
                    className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-bold outline-none shadow-sm"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                    <Hash size={12} /> {t('kkf')}
                  </label>
                  <input 
                    type="text" 
                    value={companyKKF}
                    onChange={(e) => setCompanyKKF(e.target.value)}
                    className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-bold outline-none shadow-sm"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                    <Percent size={12} /> {t('btw')}
                  </label>
                  <input 
                    type="text" 
                    value={companyBTW}
                    onChange={(e) => setCompanyBTW(e.target.value)}
                    className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-bold outline-none shadow-sm"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Date & Time Settings */}
          <div className="bg-white p-8 rounded-[40px] border border-slate-200 shadow-sm space-y-8">
            <div className="flex justify-between items-start">
              <h3 className="font-black text-xl text-slate-900 tracking-tight flex items-center gap-3 italic">
                <Clock size={24} className="text-brand-primary" /> Datum & Tijd
              </h3>
              <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 bg-slate-50 px-3 py-1.5 rounded-full">Temporal Config</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Tijdzone</label>
                <div className="relative">
                  <select 
                    value={timezone}
                    onChange={(e) => setTimezone(e.target.value)}
                    className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-black outline-none appearance-none"
                  >
                    <option value="Europe/Amsterdam">Europe/Amsterdam</option>
                    <option value="America/Paramaribo">America/Paramaribo</option>
                    <option value="UTC">UTC (Global)</option>
                  </select>
                  <ChevronDown size={14} className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400" />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Datum Notatie</label>
                <div className="relative">
                  <select 
                    value={dateFormat}
                    onChange={(e) => setDateFormat(e.target.value)}
                    className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-black outline-none appearance-none"
                  >
                    <option value="DD-MM-YYYY">DD-MM-YYYY</option>
                    <option value="YYYY-MM-DD">YYYY-MM-DD (ISO)</option>
                    <option value="MM/DD/YYYY">MM/DD/YYYY</option>
                  </select>
                  <ChevronDown size={14} className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400" />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Tijd Weergave</label>
                <div className="relative">
                  <select 
                    value={timeFormat}
                    onChange={(e) => setTimeFormat(e.target.value)}
                    className="w-full px-5 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-black outline-none appearance-none"
                  >
                    <option value="24h">24 Uur (14:00)</option>
                    <option value="12h">12 Uur (02:00 PM)</option>
                  </select>
                  <ChevronDown size={14} className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400" />
                </div>
              </div>
            </div>
          </div>

          {/* Tax Settings Section */}
          <div className="bg-white p-8 rounded-[40px] border border-slate-200 shadow-sm space-y-6">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shadow-inner">
                  <Percent size={20} />
                </div>
                <div>
                  <h3 className="font-black text-lg text-slate-900 tracking-tight italic">{t('taxSettings')}</h3>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t('manageTaxRates')}</p>
                </div>
              </div>
              <button 
                onClick={() => { setShowTaxForm(!showTaxForm); setEditingTaxId(null); }}
                className="p-2.5 bg-slate-900 text-white rounded-xl shadow-lg hover:bg-slate-800 transition-all active:scale-90"
              >
                {showTaxForm ? <X size={18} /> : <Plus size={18} />}
              </button>
            </div>

            {showTaxForm && (
              <div className="p-6 bg-slate-50 border border-slate-100 rounded-3xl grid grid-cols-1 md:grid-cols-3 gap-4 animate-in slide-in-from-top-2 duration-300">
                <div className="space-y-1.5">
                  <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{t('taxName')}</label>
                  <input 
                    type="text" placeholder="e.g. BTW High"
                    value={newTax.name}
                    onChange={(e) => setNewTax({...newTax, name: e.target.value})}
                    className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-bold outline-none"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{t('percentage')}</label>
                  <input 
                    type="number" placeholder="21"
                    value={newTax.percentage}
                    onChange={(e) => setNewTax({...newTax, percentage: parseFloat(e.target.value) || 0})}
                    className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-bold outline-none"
                  />
                </div>
                <div className="flex items-end">
                  <button 
                    onClick={addTaxRate}
                    className="w-full py-2.5 bg-emerald-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-emerald-700 shadow-lg active:scale-95"
                  >
                    Rate Registreren
                  </button>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {taxRates.map((rate) => (
                <div 
                  key={rate.id} 
                  onClick={() => editingTaxId !== rate.id && startEditing(rate)}
                  className={`p-5 rounded-3xl flex items-center justify-between group transition-all border cursor-pointer ${editingTaxId === rate.id ? 'bg-white border-emerald-300 shadow-xl' : 'bg-slate-50 border-slate-100 hover:bg-white hover:shadow-lg hover:border-emerald-200'}`}
                >
                  {editingTaxId === rate.id ? (
                    <div className="flex flex-col gap-3 w-full" onClick={(e) => e.stopPropagation()}>
                      <div className="grid grid-cols-2 gap-3">
                         <div className="space-y-1">
                            <label className="text-[8px] font-black text-slate-400 uppercase">Naam</label>
                            <input 
                              value={editTaxData.name}
                              onChange={(e) => setEditTaxData({...editTaxData, name: e.target.value})}
                              className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-bold"
                              autoFocus
                            />
                         </div>
                         <div className="space-y-1">
                            <label className="text-[8px] font-black text-slate-400 uppercase">Percentage</label>
                            <input 
                              type="number"
                              value={editTaxData.percentage}
                              onChange={(e) => setEditTaxData({...editTaxData, percentage: parseFloat(e.target.value) || 0})}
                              className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-bold"
                            />
                         </div>
                      </div>
                      <div className="flex gap-2 justify-end">
                        <button onClick={() => setEditingTaxId(null)} className="px-3 py-1 text-[10px] font-bold text-slate-400 hover:text-slate-600 uppercase">Annuleer</button>
                        <button onClick={() => saveEdit(rate.id)} className="px-4 py-1.5 bg-emerald-600 text-white rounded-lg text-[10px] font-black uppercase shadow-md hover:bg-emerald-700 transition-all">Opslaan</button>
                      </div>
                    </div>
                  ) : (
                    <>
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-white border border-slate-100 rounded-2xl flex items-center justify-center text-xl font-black text-slate-900 shadow-sm group-hover:scale-105 transition-transform">
                          {rate.percentage}%
                        </div>
                        <div>
                          <p className="font-black text-slate-900 leading-tight uppercase text-xs">{rate.name}</p>
                          {rate.isDefault && <span className="text-[8px] font-black text-emerald-600 uppercase tracking-[0.2em] italic">Primair Toegepast</span>}
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        <div className="p-2 text-slate-400 hover:text-brand-primary transition-all">
                          <Pencil size={16} />
                        </div>
                        <button 
                          onClick={(e) => { e.stopPropagation(); removeTaxRate(rate.id); }}
                          className="p-2 text-slate-300 hover:text-red-500 transition-all"
                          title="Verwijderen"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </>
                  )}
                </div>
              ))}
            </div>

            {/* Workflow Quick Links Section - "Van hier uit kan je naar..." */}
            <div className="pt-6 border-t border-slate-50">
               <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4">Gebruik in Workflow</h4>
               <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <button 
                    onClick={() => navigate('/estimates')}
                    className="p-4 bg-slate-50 border border-slate-100 rounded-2xl flex flex-col items-center gap-2 hover:bg-white hover:border-brand-primary hover:shadow-lg transition-all group"
                  >
                    <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center text-slate-400 group-hover:text-brand-primary shadow-sm"><ClipboardList size={16} /></div>
                    <span className="text-[10px] font-black uppercase tracking-wider text-slate-600 group-hover:text-slate-900">Offerte</span>
                  </button>
                  <button 
                    onClick={() => navigate('/invoices')}
                    className="p-4 bg-slate-50 border border-slate-100 rounded-2xl flex flex-col items-center gap-2 hover:bg-white hover:border-brand-primary hover:shadow-lg transition-all group"
                  >
                    <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center text-slate-400 group-hover:text-brand-primary shadow-sm"><Receipt size={16} /></div>
                    <span className="text-[10px] font-black uppercase tracking-wider text-slate-600 group-hover:text-slate-900">Facturen</span>
                  </button>
                  <button 
                    onClick={() => navigate('/payments')}
                    className="p-4 bg-slate-50 border border-slate-100 rounded-2xl flex flex-col items-center gap-2 hover:bg-white hover:border-brand-primary hover:shadow-lg transition-all group"
                  >
                    <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center text-slate-400 group-hover:text-brand-primary shadow-sm"><Wallet size={16} /></div>
                    <span className="text-[10px] font-black uppercase tracking-wider text-slate-600 group-hover:text-slate-900">Betaling</span>
                  </button>
                  <button 
                    onClick={() => navigate('/credits')}
                    className="p-4 bg-slate-50 border border-slate-100 rounded-2xl flex flex-col items-center gap-2 hover:bg-white hover:border-brand-primary hover:shadow-lg transition-all group"
                  >
                    <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center text-slate-400 group-hover:text-brand-primary shadow-sm"><CreditCard size={16} /></div>
                    <span className="text-[10px] font-black uppercase tracking-wider text-slate-600 group-hover:text-slate-900">Credit Nota</span>
                  </button>
               </div>
               <p className="text-[9px] text-slate-400 font-bold mt-4 italic text-center">De BTW-configuratie wordt in deze volgorde toegepast op de documenten.</p>
            </div>
          </div>

          {/* Color Scheme Selector */}
          <div className="bg-white p-8 rounded-[40px] border border-slate-200 shadow-sm space-y-6">
            <div className="flex justify-between items-start">
              <h3 className="font-black text-xl text-slate-900 flex items-center gap-3 italic">
                <Paintbrush size={22} className="text-brand-accent" /> {t('colorScheme')}
              </h3>
              <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 bg-slate-50 px-3 py-1.5 rounded-full">User Interface</span>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {themeOptions.map((theme) => (
                <button
                  key={theme.id}
                  onClick={() => setTheme(theme.id)}
                  className={`p-6 rounded-[32px] border-2 transition-all text-left flex flex-col gap-6 group ${
                    currentTheme === theme.id 
                      ? 'border-brand-primary bg-brand-accent-light/30 shadow-xl' 
                      : 'border-slate-50 hover:border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex -space-x-3">
                      <div className={`w-10 h-10 rounded-full border-4 border-white shadow-lg ${theme.colors[0]}`}></div>
                      <div className={`w-10 h-10 rounded-full border-4 border-white shadow-lg ${theme.colors[1]}`}></div>
                    </div>
                    {currentTheme === theme.id && <div className="w-4 h-4 rounded-full bg-brand-primary border-4 border-brand-accent"></div>}
                  </div>
                  <div>
                    <p className="text-sm font-black text-slate-900 leading-tight italic">{theme.label}</p>
                    <p className="text-[9px] text-slate-400 font-black uppercase tracking-widest mt-1">{theme.tagline}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="lg:col-span-4 space-y-8">
           <div className="bg-slate-900 p-8 rounded-[48px] text-white shadow-2xl relative overflow-hidden group min-h-[300px] flex flex-col justify-between">
             <div className="absolute top-0 right-0 w-48 h-48 bg-brand-accent/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-[80px]"></div>
             <div className="relative z-10">
               <div className="w-12 h-12 bg-brand-accent rounded-2xl flex items-center justify-center mb-8 text-slate-900 shadow-xl shadow-brand-accent/20"><Globe size={24} /></div>
               <h4 className="text-brand-accent text-[10px] font-black uppercase tracking-[0.4em] mb-4">Lokalisatie actief</h4>
               <p className="text-lg font-bold leading-tight italic text-slate-200">
                 Huidige taal: <span className="text-brand-accent">{languageOptions.find(l => l.id === lang)?.label}</span>. 
                 Wijzigen ververst alle labels wereldwijd.
               </p>
             </div>
             
             <div className="relative z-10 grid grid-cols-1 gap-2">
                {languageOptions.slice(0,3).map(opt => (
                   <button 
                    key={opt.id} 
                    onClick={() => setLang(opt.id)}
                    className={`px-4 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest border transition-all ${lang === opt.id ? 'bg-white text-slate-900 border-white' : 'bg-white/5 text-slate-400 border-white/10 hover:bg-white/10'}`}
                   >
                     {opt.flag} {opt.label}
                   </button>
                ))}
             </div>
           </div>

           <div className="bg-white p-8 rounded-[40px] border border-slate-200 shadow-sm border-l-8 border-l-brand-primary">
             <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center shadow-inner"><Paintbrush size={20} /></div>
                <h3 className="font-black text-xs text-slate-900 uppercase tracking-widest">Branding Engine</h3>
             </div>
             <p className="text-xs text-slate-500 font-medium leading-relaxed italic">
               Organisatiegegevens die hier zijn ingesteld, worden automatisch gebruikt als het standaard afzenderprofiel op alle PDF-exporten.
               Zorg voor nauwkeurigheid voor wettelijke naleving (BTW & KKF).
             </p>
           </div>
           
           <div className="bg-emerald-600 p-8 rounded-[40px] text-white shadow-2xl relative overflow-hidden group">
              <div className="absolute inset-0 bg-gradient-to-br from-emerald-500 to-emerald-700 opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
              <div className="relative z-10">
                 <div className="flex items-center gap-3 mb-4">
                    <div className="w-8 h-8 rounded-lg bg-white/20 backdrop-blur-sm flex items-center justify-center"><Percent size={16} /></div>
                    <span className="text-[10px] font-black uppercase tracking-widest">Tax Compliance</span>
                 </div>
                 <h4 className="text-xl font-black italic tracking-tight mb-2">Geautomatiseerde Berekeningen</h4>
                 <p className="text-xs text-emerald-100 font-medium leading-relaxed opacity-90">
                   Beheer verschillende belastingniveaus voor binnenlandse en internationale houtexport. Het systeem gebruikt standaard uw primaire tarief.
                 </p>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;
