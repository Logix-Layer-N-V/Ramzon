
import React, { useState, useContext } from 'react';
import { Search, Filter, Plus, CreditCard, MoreHorizontal, FileText, CheckCircle2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { mockCredits, mockClients } from '../lib/mock-data';
import { LanguageContext } from '../App';

const CreditsPage: React.FC = () => {
  const { t } = useContext(LanguageContext);
  const navigate = useNavigate();
  const [search, setSearch] = useState('');

  const filteredCredits = mockCredits.filter(c => {
    const client = mockClients.find(cl => cl.id === c.clientId);
    return client?.company.toLowerCase().includes(search.toLowerCase()) || 
           c.reason.toLowerCase().includes(search.toLowerCase());
  });

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-500 pb-10">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">{t('credits')}</h1>
          <p className="text-sm font-medium text-slate-500 italic">Manage client balance adjustments and returns</p>
        </div>
        <button className="bg-slate-900 text-white px-5 py-2.5 rounded-xl text-sm font-black hover:bg-slate-800 transition-all flex items-center gap-2 shadow-xl active:scale-95">
          <Plus size={18} /> New Credit Note
        </button>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between gap-4 bg-slate-50/20">
          <div className="flex-1 max-sm relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search credits or clients..." 
              className="w-full pl-9 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold outline-none focus:ring-2 focus:ring-emerald-100 transition-all shadow-sm"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div className="flex gap-2">
            <button className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-xl text-[10px] font-black uppercase tracking-widest bg-white text-slate-600 hover:bg-slate-50 transition-all">
              <Filter size={14} /> Filter Status
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm border-collapse">
            <thead className="bg-slate-50 border-b border-slate-100 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">
              <tr>
                <th className="px-6 py-4">Client / Reason</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Issue Date</th>
                <th className="px-6 py-4 text-right">Amount</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredCredits.map((c) => {
                const client = mockClients.find(cl => cl.id === c.clientId);
                return (
                  <tr 
                    key={c.id} 
                    onClick={() => navigate(`/credits/${c.id}`)}
                    className="hover:bg-slate-50/50 transition-colors group cursor-pointer"
                  >
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center shadow-inner group-hover:scale-110 transition-transform">
                          <CreditCard size={18} />
                        </div>
                        <div className="min-w-0">
                          <p className="font-black text-slate-900 truncate leading-tight">{client?.company || 'Unknown'}</p>
                          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tight line-clamp-1 italic">{c.reason}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[9px] font-black uppercase tracking-widest border ${
                        c.status === 'Available' ? 'bg-emerald-50 text-emerald-700 border-emerald-100' : 'bg-slate-50 text-slate-400 border-slate-100'
                      }`}>
                        {c.status === 'Available' && <CheckCircle2 size={10} />} {c.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 font-bold text-slate-400 tracking-tight">{c.date}</td>
                    <td className="px-6 py-4 text-right font-black text-blue-600 italic">
                      €{c.amount.toLocaleString()}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex justify-end gap-1 opacity-0 group-hover:opacity-100 transition-all">
                        <button 
                          onClick={(e) => { e.stopPropagation(); }}
                          className="p-2 text-slate-400 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
                        >
                          <FileText size={16} />
                        </button>
                        <button 
                          onClick={(e) => { e.stopPropagation(); }}
                          className="p-2 text-slate-400 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
                        >
                          <MoreHorizontal size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default CreditsPage;
