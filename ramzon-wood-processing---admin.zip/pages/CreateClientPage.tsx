
import React, { useState } from 'react';
import { ArrowLeft, User, Building, Mail, Phone, MapPin, Save, Hash, Info, AlertCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { mockClients } from '../lib/mock-data';

const CreateClientPage: React.FC = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [emailError, setEmailError] = useState(false);

  const handleEmailChange = (val: string) => {
    setEmail(val);
    // Check of email al bestaat in de mock data
    const exists = mockClients.some(c => c.email.toLowerCase() === val.toLowerCase());
    setEmailError(exists && val.length > 0);
  };

  const handleSave = () => {
    if (emailError) return;
    // In een echte app: API call naar backend
    navigate('/clients');
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20">
      <div className="flex items-center justify-between">
        <button onClick={() => navigate('/clients')} className="flex items-center gap-2 text-slate-500 hover:text-slate-900 font-semibold text-sm transition-all">
          <ArrowLeft size={16} /> Terug naar CRM
        </button>
        <button 
          onClick={handleSave}
          disabled={emailError || !email}
          className={`px-8 py-2.5 rounded-xl font-bold text-xs shadow-md transition-all flex items-center gap-2 ${
            emailError || !email 
            ? 'bg-slate-200 text-slate-400 cursor-not-allowed' 
            : 'bg-brand-primary text-white active:scale-95 hover:bg-slate-800'
          }`}
        >
          <Save size={18} /> Relatie Opslaan
        </button>
      </div>

      <div className="max-w-3xl mx-auto space-y-6">
        <div className="bg-white p-8 md:p-10 rounded-2xl border border-slate-200 shadow-sm space-y-8">
          <div className="flex items-center gap-4">
             <div className="w-12 h-12 bg-blue-50 text-brand-primary rounded-xl flex items-center justify-center shadow-inner">
               <User size={24} />
             </div>
             <div>
               <h2 className="text-xl font-bold text-slate-900 tracking-tight">Nieuwe Zakelijke Account</h2>
               <p className="text-slate-400 font-bold uppercase tracking-wider text-[10px]">Stamgegevens CRM</p>
             </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-1.5 md:col-span-2">
              <label className={`text-[10px] font-bold uppercase tracking-widest flex items-center gap-2 ${emailError ? 'text-red-500' : 'text-slate-500'}`}>
                <Mail size={12} /> E-mailadres (KEY ID)
              </label>
              <div className="relative">
                <input 
                  type="email" 
                  placeholder="klant@bedrijf.nl" 
                  value={email}
                  onChange={(e) => handleEmailChange(e.target.value)}
                  className={`w-full px-4 py-2.5 border rounded-xl text-sm font-semibold outline-none transition-all ${
                    emailError 
                    ? 'bg-red-50 border-red-200 focus:ring-2 focus:ring-red-100' 
                    : 'bg-slate-50 border-slate-200 focus:ring-2 focus:ring-brand-accent-light focus:bg-white'
                  }`} 
                />
                {emailError && (
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 text-red-500 flex items-center gap-1.5 animate-in fade-in zoom-in-95">
                    <AlertCircle size={16} />
                    <span className="text-[10px] font-black uppercase tracking-tight">E-mail is al in gebruik</span>
                  </div>
                )}
              </div>
              <p className="text-[10px] text-slate-400 font-semibold italic">Het e-mailadres is de unieke sleutel voor dit account.</p>
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-2">
                <Building size={12} /> Bedrijfsnaam
              </label>
              <input type="text" placeholder="Bijv. Amsterdam Houtbewerking" className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold outline-none focus:ring-2 focus:ring-brand-accent-light focus:bg-white transition-all" />
            </div>
            
            <div className="space-y-1.5">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-2">
                <Hash size={12} /> BTW Nummer
              </label>
              <input type="text" placeholder="NL8829..." className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold outline-none focus:ring-2 focus:ring-brand-accent-light focus:bg-white transition-all" />
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-2">
                <User size={12} /> Contactpersoon
              </label>
              <input type="text" placeholder="Volledige naam..." className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold outline-none focus:ring-2 focus:ring-brand-accent-light focus:bg-white transition-all" />
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-2">
                <Phone size={12} /> Telefoonnummer
              </label>
              <input type="text" placeholder="+597..." className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold outline-none focus:ring-2 focus:ring-brand-accent-light focus:bg-white transition-all" />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-2">
              <MapPin size={12} /> Vestigingsadres
            </label>
            <textarea rows={3} placeholder="Volledig adres voor facturatie..." className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold outline-none focus:ring-2 focus:ring-brand-accent-light focus:bg-white transition-all resize-none" />
          </div>

          <div className="p-4 bg-blue-50/50 rounded-xl border border-blue-100 flex gap-4 items-start">
            <Info size={20} className="text-brand-primary shrink-0" />
            <p className="text-[11px] font-semibold text-slate-500 leading-relaxed italic">
              Het CRM staat geen dubbele e-mailadressen toe om integriteitsfouten in de facturatie te voorkomen.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreateClientPage;
