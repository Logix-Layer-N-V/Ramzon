
import React, { useState } from 'react';
import { ArrowRight, CheckCircle2, Globe, Shield, Zap, Layout, Sparkles, Star, Heart, ArrowLeft } from 'lucide-react';

type SubPage = 'home' | 'products' | 'solutions' | 'pricing' | 'resources';

const SitePreviewPage: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<SubPage>('home');

  const renderContent = () => {
    switch (currentPage) {
      case 'products':
        return (
          <div className="px-10 py-20 animate-in fade-in slide-in-from-right-4 duration-500">
            <h2 className="text-4xl font-black text-slate-900 mb-8 tracking-tighter">Our Product Suite</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="p-8 bg-blue-50 rounded-3xl border border-blue-100">
                <div className="w-12 h-12 bg-blue-600 text-white rounded-xl flex items-center justify-center mb-6 shadow-lg shadow-blue-200">
                  <Zap size={24} />
                </div>
                <h3 className="text-2xl font-black mb-4">Metafi Edge</h3>
                <p className="text-slate-600 font-medium">Global CDN and edge computing platform for maximum performance.</p>
              </div>
              <div className="p-8 bg-slate-50 rounded-3xl border border-slate-100">
                <div className="w-12 h-12 bg-slate-900 text-white rounded-xl flex items-center justify-center mb-6 shadow-lg shadow-slate-200">
                  <Layout size={24} />
                </div>
                <h3 className="text-2xl font-black mb-4">StaticPress CMS</h3>
                <p className="text-slate-600 font-medium">The core platform you're using right now. Purely static, purely fast.</p>
              </div>
            </div>
          </div>
        );
      case 'solutions':
        return (
          <div className="px-10 py-20 animate-in fade-in slide-in-from-right-4 duration-500">
            <h2 className="text-4xl font-black text-slate-900 mb-8 tracking-tighter text-center">Tailored Solutions</h2>
            <div className="max-w-3xl mx-auto space-y-12">
              <div className="flex gap-6 items-start">
                <div className="p-4 bg-green-50 text-green-600 rounded-2xl shrink-0"><CheckCircle2 size={32} /></div>
                <div>
                  <h3 className="text-2xl font-black mb-2">For Enterprise</h3>
                  <p className="text-slate-600 font-medium">Scale to millions of visitors without worrying about server infrastructure or maintenance windows.</p>
                </div>
              </div>
              <div className="flex gap-6 items-start">
                <div className="p-4 bg-purple-50 text-purple-600 rounded-2xl shrink-0"><Star size={32} /></div>
                <div>
                  <h3 className="text-2xl font-black mb-2">For Agencies</h3>
                  <p className="text-slate-600 font-medium">Manage multiple client sites from one unified dashboard with simplified billing and deployment.</p>
                </div>
              </div>
            </div>
          </div>
        );
      case 'pricing':
        return (
          <div className="px-10 py-20 animate-in fade-in slide-in-from-right-4 duration-500">
            <h2 className="text-4xl font-black text-slate-900 mb-12 tracking-tighter text-center">Simple, Transparent Pricing</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
              <div className="p-8 border border-slate-200 rounded-3xl text-center space-y-6">
                <h3 className="font-bold text-slate-500 uppercase tracking-widest text-xs">Starter</h3>
                <p className="text-5xl font-black text-slate-900">$0</p>
                <ul className="text-slate-600 text-sm font-medium space-y-3 pb-6">
                  <li>Up to 3 Projects</li>
                  <li>10GB Bandwidth</li>
                  <li>Community Support</li>
                </ul>
                <button className="w-full py-3 border-2 border-slate-200 rounded-xl font-bold">Get Started</button>
              </div>
              <div className="p-8 bg-slate-900 text-white rounded-3xl text-center space-y-6 shadow-2xl scale-105">
                <h3 className="font-bold text-blue-400 uppercase tracking-widest text-xs">Platinum</h3>
                <p className="text-5xl font-black">$29</p>
                <ul className="text-slate-400 text-sm font-medium space-y-3 pb-6">
                  <li>Unlimited Projects</li>
                  <li>Unlimited Bandwidth</li>
                  <li>24/7 Priority Support</li>
                </ul>
                <button className="w-full py-3 bg-blue-600 text-white rounded-xl font-bold shadow-lg shadow-blue-500/20">Go Platinum</button>
              </div>
              <div className="p-8 border border-slate-200 rounded-3xl text-center space-y-6">
                <h3 className="font-bold text-slate-500 uppercase tracking-widest text-xs">Business</h3>
                <p className="text-5xl font-black">$99</p>
                <ul className="text-slate-600 text-sm font-medium space-y-3 pb-6">
                  <li>Dedicated Support</li>
                  <li>Custom Integration</li>
                  <li>White Labeling</li>
                </ul>
                <button className="w-full py-3 border-2 border-slate-200 rounded-xl font-bold">Contact Sales</button>
              </div>
            </div>
          </div>
        );
      case 'home':
      default:
        return (
          <>
            {/* Hero */}
            <section className="px-10 py-20 text-center max-w-4xl mx-auto space-y-8 animate-in fade-in duration-700">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-50 text-blue-600 rounded-full text-xs font-black uppercase tracking-widest border border-blue-100">
                <Sparkles size={14} /> New Launch: v2.0 is live
              </div>
              <h1 className="text-6xl font-black text-slate-900 tracking-tighter leading-[1.05]">
                Everything you need to run <span className="text-blue-600">business online.</span>
              </h1>
              <p className="text-xl text-slate-500 font-medium leading-relaxed max-w-2xl mx-auto">
                StaticPress gives you the power to build, scale, and manage your content with unparalleled speed and simplicity. 
              </p>
              <div className="flex items-center justify-center gap-4 pt-4">
                <button className="bg-slate-900 text-white px-8 py-4 rounded-2xl font-black shadow-2xl shadow-slate-200 flex items-center gap-2 hover:bg-slate-800 transition-all group">
                  Start Building <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
                </button>
                <button className="bg-white border-2 border-slate-100 px-8 py-4 rounded-2xl font-black text-slate-600 hover:border-slate-200 transition-all">
                  Watch Demo
                </button>
              </div>
            </section>

            {/* Features */}
            <section className="px-10 py-24 bg-slate-50 border-y border-slate-100">
              <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-12">
                <div className="space-y-4">
                  <div className="w-14 h-14 bg-white rounded-2xl shadow-xl flex items-center justify-center text-blue-600">
                    <Zap size={28} />
                  </div>
                  <h3 className="text-2xl font-black text-slate-900 tracking-tight">Lightning Fast</h3>
                  <p className="text-slate-500 font-medium leading-relaxed">Static export ensures your site loads instantly across the globe with zero server lag.</p>
                </div>
                <div className="space-y-4">
                  <div className="w-14 h-14 bg-white rounded-2xl shadow-xl flex items-center justify-center text-green-600">
                    <Shield size={28} />
                  </div>
                  <h3 className="text-2xl font-black text-slate-900 tracking-tight">Unbreakable Security</h3>
                  <p className="text-slate-500 font-medium leading-relaxed">No database at runtime means no SQL injections. Your content is perfectly safe.</p>
                </div>
                <div className="space-y-4">
                  <div className="w-14 h-14 bg-white rounded-2xl shadow-xl flex items-center justify-center text-purple-600">
                    <Layout size={28} />
                  </div>
                  <h3 className="text-2xl font-black text-slate-900 tracking-tight">Modern UI</h3>
                  <p className="text-slate-500 font-medium leading-relaxed">Build beautiful layouts with our intuitive block builder and professional themes.</p>
                </div>
              </div>
            </section>
          </>
        );
    }
  };

  return (
    <div className="bg-white rounded-[32px] shadow-2xl overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-700 h-full flex flex-col">
      {/* Browser Chrome Header */}
      <div className="bg-slate-100 px-6 py-3 border-b border-slate-200 flex items-center gap-4 shrink-0">
        <div className="flex gap-1.5">
          <div className="w-3 h-3 rounded-full bg-red-400"></div>
          <div className="w-3 h-3 rounded-full bg-yellow-400"></div>
          <div className="w-3 h-3 rounded-full bg-green-400"></div>
        </div>
        <div className="flex gap-2 mr-2">
          <button 
            onClick={() => setCurrentPage('home')}
            className="p-1.5 bg-white border border-slate-200 rounded-lg text-slate-400 hover:text-slate-900 hover:border-slate-300 transition-all shadow-sm"
          >
            <ArrowLeft size={14} />
          </button>
        </div>
        <div className="flex-1 bg-white rounded-full py-1.5 px-4 flex items-center gap-2 border border-slate-200 shadow-sm overflow-hidden">
          <Globe size={14} className="text-slate-400 shrink-0" />
          <span className="text-xs font-bold text-slate-500 truncate">
            https://your-metafi-site.com/{currentPage !== 'home' ? currentPage : 'preview'}
          </span>
        </div>
      </div>

      {/* Simulated Frontend Content */}
      <div className="flex-1 overflow-y-auto no-scrollbar scroll-smooth">
        {/* Nav */}
        <nav className="px-10 py-6 flex justify-between items-center sticky top-0 bg-white/80 backdrop-blur-md z-10 border-b border-slate-50">
          <button onClick={() => setCurrentPage('home')} className="flex items-center gap-2 group">
            <div className="w-8 h-8 bg-slate-900 rounded-xl flex items-center justify-center text-white font-black text-xs transition-transform group-hover:rotate-12">M</div>
            <span className="font-black text-xl tracking-tighter">Metafi</span>
          </button>
          <div className="hidden md:flex items-center gap-8 text-sm font-bold text-slate-600">
            <button 
              onClick={() => setCurrentPage('products')} 
              className={`transition-colors ${currentPage === 'products' ? 'text-blue-600' : 'hover:text-slate-900'}`}
            >
              Products
            </button>
            <button 
              onClick={() => setCurrentPage('solutions')} 
              className={`transition-colors ${currentPage === 'solutions' ? 'text-blue-600' : 'hover:text-slate-900'}`}
            >
              Solutions
            </button>
            <button 
              onClick={() => setCurrentPage('pricing')} 
              className={`transition-colors ${currentPage === 'pricing' ? 'text-blue-600' : 'hover:text-slate-900'}`}
            >
              Pricing
            </button>
            <button 
              onClick={() => setCurrentPage('home')} 
              className={`transition-colors ${currentPage === 'resources' ? 'text-blue-600' : 'hover:text-slate-900'}`}
            >
              Resources
            </button>
          </div>
          <button className="bg-slate-900 text-white px-5 py-2.5 rounded-full text-sm font-bold shadow-lg shadow-slate-200 hover:scale-105 active:scale-95 transition-all">
            Get Started
          </button>
        </nav>

        {renderContent()}

        {/* Bottom CTA */}
        <section className="px-10 py-24 text-center">
           <div className="max-w-5xl mx-auto bg-blue-600 rounded-[48px] p-16 text-white space-y-8 shadow-2xl shadow-blue-200 relative overflow-hidden">
             <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl"></div>
             <h2 className="text-4xl font-black tracking-tight">Ready to transform your workflow?</h2>
             <p className="text-blue-100 text-lg font-medium max-w-xl mx-auto">Join over 10,000 creators who are building the future of the web with StaticPress.</p>
             <button className="bg-white text-blue-600 px-10 py-4 rounded-2xl font-black shadow-xl hover:bg-blue-50 transition-all hover:scale-105 active:scale-95">
               Create Account
             </button>
           </div>
        </section>

        {/* Footer */}
        <footer className="px-10 py-12 border-t border-slate-100 flex flex-col md:flex-row justify-between items-center gap-8 bg-white">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-slate-900 rounded-lg flex items-center justify-center text-white font-black text-[10px]">M</div>
            <span className="font-black text-sm tracking-tighter">Metafi © 2024</span>
          </div>
          <div className="flex gap-8 text-xs font-bold text-slate-400">
            <a href="#" className="hover:text-slate-900 transition-colors">Privacy</a>
            <a href="#" className="hover:text-slate-900 transition-colors">Terms</a>
            <a href="#" className="hover:text-slate-900 transition-colors">Cookies</a>
            <a href="#" className="hover:text-slate-900 transition-colors">Support</a>
          </div>
        </footer>
      </div>
    </div>
  );
};

export default SitePreviewPage;
