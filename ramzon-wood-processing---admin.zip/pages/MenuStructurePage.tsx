
import React, { useState } from 'react';
import { 
  ListTree, 
  Plus, 
  ChevronDown, 
  ChevronRight, 
  Move, 
  X, 
  Save, 
  ExternalLink, 
  Settings2,
  Files,
  FileText,
  Layers,
  MousePointer2,
  Check,
  // Fix: Added missing Sparkles import from lucide-react
  Sparkles
} from 'lucide-react';
import { mockPosts } from '../lib/mock-data';

const MenuStructurePage: React.FC = () => {
  const [menuItems, setMenuItems] = useState([
    { id: 'm1', label: 'Home', type: 'Page', path: '/' },
    { id: 'm2', label: 'Products', type: 'Page', path: '/products' },
    { id: 'm3', label: 'Fintech Insights', type: 'Category', path: '/category/fintech' },
    { id: 'm4', label: 'Company', type: 'Page', path: '/about' },
  ]);

  const [activeAccordion, setActiveAccordion] = useState<string | null>('pages');
  const [saved, setSaved] = useState(false);

  const pages = mockPosts.filter(p => p.type === 'Page');
  const articles = mockPosts.filter(p => p.type === 'Article');
  // Fixed: Added explicit string[] cast to ensure cat is not unknown
  const categories = Array.from(new Set(mockPosts.map(p => p.category))) as string[];

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const addItemToMenu = (label: string, type: string, path: string) => {
    const id = Math.random().toString(36).substr(2, 9);
    setMenuItems([...menuItems, { id, label, type, path }]);
  };

  const removeItem = (id: string) => {
    setMenuItems(menuItems.filter(item => item.id !== id));
  };

  const SelectionAccordion = ({ id, label, icon: Icon, children }: any) => (
    <div className="border border-slate-200 rounded-xl overflow-hidden bg-white shadow-sm transition-all">
      <button 
        onClick={() => setActiveAccordion(activeAccordion === id ? null : id)}
        className="w-full flex items-center justify-between px-4 py-3 bg-white hover:bg-slate-50 transition-colors"
      >
        <div className="flex items-center gap-3 text-slate-700 font-bold text-sm">
          <Icon size={16} className="text-slate-400" />
          {label}
        </div>
        <ChevronDown size={14} className={`text-slate-400 transition-transform ${activeAccordion === id ? 'rotate-180' : ''}`} />
      </button>
      {activeAccordion === id && (
        <div className="p-3 bg-slate-50/30 border-t border-slate-100 space-y-2 animate-in slide-in-from-top-1 duration-200">
          {children}
        </div>
      )}
    </div>
  );

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-500 pb-20">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Menu Structure</h1>
          <p className="text-slate-500 text-sm">Organize your website navigation and primary links</p>
        </div>
        <div className="flex gap-2">
          <button className="bg-white border border-slate-200 text-slate-600 px-5 py-2.5 rounded-xl text-sm font-bold hover:bg-slate-50 transition-all shadow-sm">
            Manage Locations
          </button>
          <button 
            onClick={handleSave}
            className="bg-slate-900 text-white px-6 py-2.5 rounded-xl text-sm font-bold hover:bg-slate-800 transition-all flex items-center gap-2 shadow-xl shadow-slate-200 active:scale-95"
          >
            {saved ? <Check size={16} /> : <Save size={16} />}
            {saved ? 'Menu Saved' : 'Save Menu'}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left column: Add items to menu */}
        <div className="lg:col-span-4 space-y-4">
          <SelectionAccordion id="pages" label="Pages" icon={Files}>
            <div className="space-y-1">
              {pages.map(page => (
                <div key={page.id} className="flex items-center justify-between p-2 rounded-lg bg-white border border-slate-100 hover:border-blue-300 transition-colors group">
                  <span className="text-xs font-bold text-slate-600 truncate mr-2">{page.title}</span>
                  <button 
                    onClick={() => addItemToMenu(page.title, 'Page', `/${page.title.toLowerCase().replace(/\s+/g, '-')}`)}
                    className="p-1 bg-slate-50 text-slate-400 hover:bg-blue-600 hover:text-white rounded-md transition-all shadow-sm"
                  >
                    <Plus size={14} />
                  </button>
                </div>
              ))}
            </div>
            <button className="w-full mt-2 py-2 text-[10px] font-black uppercase tracking-widest text-blue-600 hover:underline">View All Pages</button>
          </SelectionAccordion>

          <SelectionAccordion id="posts" label="Posts" icon={FileText}>
            <div className="space-y-1">
              {articles.map(post => (
                <div key={post.id} className="flex items-center justify-between p-2 rounded-lg bg-white border border-slate-100 hover:border-blue-300 transition-colors">
                  <span className="text-xs font-bold text-slate-600 truncate mr-2">{post.title}</span>
                  <button 
                    onClick={() => addItemToMenu(post.title, 'Article', `/blog/${post.title.toLowerCase().replace(/\s+/g, '-')}`)}
                    className="p-1 bg-slate-50 text-slate-400 hover:bg-blue-600 hover:text-white rounded-md transition-all shadow-sm"
                  >
                    <Plus size={14} />
                  </button>
                </div>
              ))}
            </div>
          </SelectionAccordion>

          <SelectionAccordion id="categories" label="Categories" icon={Layers}>
             <div className="space-y-1">
              {categories.map(cat => (
                <div key={cat} className="flex items-center justify-between p-2 rounded-lg bg-white border border-slate-100 hover:border-blue-300 transition-colors">
                  <span className="text-xs font-bold text-slate-600 truncate mr-2">{cat}</span>
                  <button 
                    onClick={() => addItemToMenu(cat, 'Category', `/category/${cat.toLowerCase()}`)}
                    className="p-1 bg-slate-50 text-slate-400 hover:bg-blue-600 hover:text-white rounded-md transition-all shadow-sm"
                  >
                    <Plus size={14} />
                  </button>
                </div>
              ))}
            </div>
          </SelectionAccordion>

          <SelectionAccordion id="custom" label="Custom Links" icon={MousePointer2}>
             <div className="space-y-3">
               <div className="space-y-1">
                 <label className="text-[9px] font-black uppercase tracking-widest text-slate-400">URL</label>
                 <input type="text" placeholder="https://" className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs outline-none focus:ring-1 focus:ring-blue-500" />
               </div>
               <div className="space-y-1">
                 <label className="text-[9px] font-black uppercase tracking-widest text-slate-400">Link Text</label>
                 <input type="text" placeholder="Custom Label" className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs outline-none focus:ring-1 focus:ring-blue-500" />
               </div>
               <button className="w-full py-2 bg-slate-900 text-white rounded-lg text-xs font-bold">Add Link to Menu</button>
             </div>
          </SelectionAccordion>
        </div>

        {/* Right column: Menu canvas */}
        <div className="lg:col-span-8 space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col min-h-[500px]">
            <div className="px-6 py-4 bg-slate-50/50 border-b border-slate-100 flex justify-between items-center">
               <div className="flex items-center gap-2">
                 <ListTree size={16} className="text-blue-600" />
                 <h3 className="font-black text-sm text-slate-900">Main Navigation Menu</h3>
               </div>
               <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Sorting Enabled</span>
               </div>
            </div>

            <div className="p-8 flex flex-col gap-3 relative">
              <div className="absolute left-10 top-0 bottom-0 w-px bg-slate-100"></div>
              
              {menuItems.map((item, idx) => (
                <div key={item.id} className="group relative flex flex-col animate-in slide-in-from-left-4 duration-300" style={{ animationDelay: `${idx * 50}ms` }}>
                  <div className="flex items-center gap-4 bg-white border border-slate-200 rounded-xl p-4 shadow-sm hover:shadow-md transition-all relative z-10 group-hover:border-blue-200">
                    <div className="p-1.5 text-slate-200 group-hover:text-slate-900 cursor-grab active:cursor-grabbing transition-colors shrink-0">
                      <Move size={16} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-0.5">
                        <p className="font-bold text-slate-900 leading-tight truncate">{item.label}</p>
                        <span className="px-1.5 py-0.5 bg-slate-100 text-slate-500 text-[8px] font-black uppercase tracking-widest rounded">{item.type}</span>
                      </div>
                      <p className="text-[10px] text-slate-400 font-mono italic truncate">{item.path}</p>
                    </div>
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                       <button className="p-2 text-slate-400 hover:text-slate-900 hover:bg-slate-50 rounded-lg transition-all"><Settings2 size={16} /></button>
                       <button className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"><ExternalLink size={16} /></button>
                       <div className="w-px h-6 bg-slate-100 mx-1"></div>
                       <button onClick={() => removeItem(item.id)} className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"><X size={16} /></button>
                    </div>
                  </div>
                  
                  {/* Visual Drop zone indicator between items */}
                  <div className="h-4 w-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="w-2 h-2 rounded-full bg-blue-400"></div>
                    <div className="flex-1 h-px bg-blue-100 ml-2"></div>
                  </div>
                </div>
              ))}

              {menuItems.length === 0 && (
                <div className="py-20 flex flex-col items-center justify-center text-slate-300 gap-4">
                   <ListTree size={48} className="opacity-10" />
                   <p className="font-bold">Your menu is empty.</p>
                   <p className="text-xs font-medium max-w-xs text-center">Add items from the left sidebar to start building your site's navigation.</p>
                </div>
              )}
            </div>

            <div className="mt-auto p-6 bg-slate-50/30 border-t border-slate-100 flex items-center justify-between">
               <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Total Items: {menuItems.length}</p>
               <div className="flex items-center gap-4">
                  <button className="text-xs font-bold text-red-600 hover:underline">Clear All</button>
                  <button onClick={handleSave} className="px-4 py-2 bg-slate-900 text-white rounded-lg text-xs font-bold shadow-md active:scale-95 transition-all">
                    Update Menu Structure
                  </button>
               </div>
            </div>
          </div>

          <div className="bg-blue-600 p-8 rounded-3xl text-white shadow-2xl shadow-blue-200 relative overflow-hidden group">
             <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-2xl"></div>
             <div className="relative z-10 flex items-start gap-4">
                <div className="p-3 bg-white/10 rounded-2xl backdrop-blur-sm">
                   <Sparkles size={24} className="text-blue-200" />
                </div>
                <div>
                   <h4 className="font-black text-lg tracking-tight mb-2">Smart Navigation Helper</h4>
                   <p className="text-blue-100 text-sm font-medium leading-relaxed opacity-90">
                     StaticPress can automatically suggest sub-menus based on your internal linking structure. Try the Word Assistant for better SEO labeling.
                   </p>
                </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MenuStructurePage;
