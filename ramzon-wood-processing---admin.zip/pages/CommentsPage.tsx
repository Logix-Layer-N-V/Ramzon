
import React from 'react';
import { MessageSquare, Check, X, Trash2, Reply, Search, Filter } from 'lucide-react';
import { mockComments } from '../lib/mock-data';

const CommentsPage: React.FC = () => {
  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Comments</h1>
          <p className="text-slate-500">Moderate and reply to user feedback</p>
        </div>
        <div className="flex gap-2">
           <button className="bg-white border border-slate-200 text-slate-900 px-5 py-2.5 rounded-xl text-sm font-bold hover:bg-slate-50 hover:border-slate-300 transition-all shadow-sm active:scale-95">
             Empty Spam
           </button>
        </div>
      </div>

      <div className="bg-white rounded-[24px] border border-slate-200 shadow-sm overflow-hidden">
        {/* Table Toolbar */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between gap-4 bg-slate-50/30">
          <div className="flex-1 max-w-sm relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search comments..." 
              className="w-full pl-9 pr-4 py-2 bg-white border border-slate-300 rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:ring-2 focus:ring-blue-600 outline-none transition-all shadow-sm font-medium"
            />
          </div>
          <div className="flex items-center gap-2">
            <button className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-xl text-xs font-bold bg-white text-slate-600 hover:text-slate-900 hover:bg-slate-50 hover:border-slate-300 transition-all shadow-sm">
              <Filter size={14} /> All Status
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 border-b border-slate-100 text-slate-400 font-bold uppercase tracking-widest text-[10px]">
              <tr>
                <th className="px-6 py-4 w-1/4">Author</th>
                <th className="px-6 py-4 w-1/3">Comment</th>
                <th className="px-6 py-4">In Response To</th>
                <th className="px-6 py-4">Submitted On</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {mockComments.map((comment) => (
                <tr key={comment.id} className={`hover:bg-slate-50/50 transition-colors group ${comment.status === 'Pending' ? 'bg-blue-50/20' : ''}`}>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-4">
                      <img src={comment.avatar} className="w-10 h-10 rounded-2xl object-cover border border-slate-200 shadow-sm group-hover:scale-110 transition-transform" alt={comment.author} />
                      <div className="flex flex-col min-w-0">
                        <span className="font-bold text-slate-900 truncate group-hover:text-blue-600 transition-colors">{comment.author}</span>
                        <span className={`text-[9px] font-black uppercase tracking-[0.1em] mt-0.5 ${
                          comment.status === 'Approved' ? 'text-green-600' : 
                          comment.status === 'Spam' ? 'text-red-600' : 'text-blue-600'
                        }`}>{comment.status}</span>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-slate-600 font-medium line-clamp-2 leading-relaxed italic group-hover:text-slate-900 transition-colors">"{comment.content}"</p>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-blue-600 font-bold hover:underline cursor-pointer group-hover:text-blue-700">{comment.postTitle}</span>
                  </td>
                  <td className="px-6 py-4 text-slate-400 font-bold tracking-tight">{comment.date}</td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      {comment.status !== 'Approved' && (
                        <button className="p-2.5 text-green-500 hover:bg-green-50 rounded-xl transition-all hover:scale-110" title="Approve">
                          <Check size={18} />
                        </button>
                      )}
                      <button className="p-2.5 text-blue-500 hover:bg-blue-50 rounded-xl transition-all hover:scale-110" title="Reply">
                        <Reply size={18} />
                      </button>
                      <button className="p-2.5 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all hover:scale-110" title="Delete">
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default CommentsPage;
