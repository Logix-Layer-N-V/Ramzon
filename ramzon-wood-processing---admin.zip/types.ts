
export type InvoiceStatus = 'Paid' | 'Pending' | 'Overdue' | 'Draft' | 'Cancelled';
export type EstimateStatus = 'Accepted' | 'Sent' | 'Draft' | 'Expired';

export interface Client {
  id: string;
  name: string;
  company: string;
  email: string;
  vatNumber: string;
  address: string;
  totalSpent: number;
  status: 'Active' | 'Inactive';
  phone?: string;
}

export interface Payment {
  id: string;
  clientId: string;
  amount: number;
  date: string;
  method: 'Bank Transfer' | 'Cash' | 'Credit Card';
  reference: string;
  status: 'Completed' | 'Refunded';
}

export interface Credit {
  id: string;
  clientId: string;
  amount: number;
  date: string;
  reason: string;
  status: 'Available' | 'Used';
}

export interface WoodProduct {
  id: string;
  name: string;
  woodType: string;
  thickness: number; // mm
  width: number;    // mm
  length: number;   // mm
  unit: 'm³' | 'm²' | 'lm' | 'pcs';
  pricePerUnit: number;
  stock: number;
}

export interface InvoiceItem {
  id: string;
  productId: string;
  description: string;
  quantity: number;
  dimensions?: { l: number; w: number; t: number };
  unitPrice: number;
  total: number;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  clientId: string;
  clientName: string;
  date: string;
  dueDate: string;
  items: InvoiceItem[];
  subtotal: number;
  taxRate: number;
  taxAmount: number;
  totalAmount: number;
  status: InvoiceStatus;
  notes?: string;
}

export interface Estimate {
  id: string;
  estimateNumber: string;
  clientId: string;
  clientName: string;
  date: string;
  items: InvoiceItem[];
  subtotal: number;
  taxRate: number;
  taxAmount: number;
  total: number;
  status: EstimateStatus;
  notes?: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'Admin' | 'Sales' | 'Accountant';
  status: 'Active' | 'Inactive';
  avatar: string;
  joinedDate: string;
}

export interface Expense {
  id: string;
  category: string;
  amount: number;
  date: string;
  description: string;
  status: 'Paid' | 'Unpaid';
}

export type PostStatus = 'Published' | 'Draft' | 'Archived';
export type PostType = 'Article' | 'Page';

export interface Post {
  id: string;
  title: string;
  type: PostType;
  category: string;
  tags: string[];
  seoScore: number;
  status: PostStatus;
  author: string;
  date: string;
  content?: string;
}

export interface MediaItem {
  id: string;
  name: string;
  url: string;
  size: string;
  type: string;
  date: string;
}

export interface Comment {
  id: string;
  author: string;
  avatar: string;
  content: string;
  status: 'Approved' | 'Pending' | 'Spam';
  postTitle: string;
  date: string;
}
